# Command Desk Web Frontend

This is the frontend-only web version of the existing Command Desk Flutter app.

## Preview

Run from this folder:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

Chrome or Edge is recommended for browser voice recognition.

## Connect your backend

Open `config.js` and change:

```js
backendBaseUrl: "https://your-api.example.com",
demoMode: false,
```

Expected hooks:

- `GET /agents`
- `POST /chat`

No backend is included.
