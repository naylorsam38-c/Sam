window.COMMAND_DESK_CONFIG = {
  backendBaseUrl: "",
  demoMode: true,
  endpoints: { agents: "/agents", chat: "/chat" },
  speechLanguage: "en-AU"
};
