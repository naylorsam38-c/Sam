# Nova Facial Animation Assets

The frontend now supports lightweight facial animation without changing the existing breathing effect.

Add these transparent PNG files to `assets/avatars/`:

- `nova_blink.png` — same dimensions and alignment as `nova.png`, with eyes naturally closed.
- `nova_mouth_1.png`
- `nova_mouth_2.png`
- `nova_mouth_3.png`
- `nova_mouth_4.png`

Each mouth frame must be the same complete Nova image, with only the mouth shape changed. Keep the head, body, lighting, crop, canvas size and alignment identical to `nova.png`.

Behaviour:

- Blink interval is random, approximately every 3.8–9 seconds.
- Blink duration is approximately 90–145 milliseconds.
- Blinking pauses while Nova is speaking.
- Mouth frames change every 85–160 milliseconds while the existing speaking state is active.
- Nova returns to the normal frame when speech stops.
- Breathing continues on the outer avatar wrapper and is not interrupted.
- Missing frames fail safely: Nova remains on the normal image.
- No other screen element receives animation.

The same naming convention can later be used for Halo and Gaia:
`halo_blink.png`, `halo_mouth_1.png`, etc.
