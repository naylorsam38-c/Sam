const C=window.COMMAND_DESK_CONFIG||{};
const avatars={nova:"Nova",halo:"Halo",gaia:"Gaia"};
const themes={
  gunmetal:{name:"Gunmetal",a:"#1a1c20",b:"#050607",c:"#b9c0c7",g:"rgba(94,104,114,.45)"},
  volcano:{name:"Volcano",a:"#251006",b:"#050201",c:"#ff7a22",g:"rgba(227,74,18,.5)"},
  platinum:{name:"Platinum",a:"#24272b",b:"#050607",c:"#e8ebef",g:"rgba(197,205,213,.48)"}
};
const workspaceInfo={
  email:{title:"Email",icon:"✉"},
  calendar:{title:"Calendar",icon:"□"},
  documents:{title:"Documents",icon:"▤"},
  browser:{title:"Browser",icon:"◎"},
  projects:{title:"Projects",icon:"◇"}
};
const sampleMessages=[
  {sender:"Alex Morgan",subject:"Updated project timeline",snippet:"I’ve attached the revised milestones and delivery dates.",time:"9:42",body:"Hi,\n\nI’ve attached the revised milestones and delivery dates. The main change is the testing window, which now begins next Monday.\n\nRegards,\nAlex"},
  {sender:"Accounts",subject:"Invoice 2048",snippet:"Your July invoice is ready for review.",time:"8:15",body:"Your July invoice is ready for review. Please let us know if any billing details need to be changed."},
  {sender:"Jordan Lee",subject:"Friday meeting",snippet:"Can we move the meeting to 2:30 pm?",time:"Yesterday",body:"Would 2:30 pm on Friday work instead? I need another thirty minutes before the meeting."},
  {sender:"Design Team",subject:"Command Desk interface",snippet:"The latest frontend notes have been added.",time:"Tue",body:"The latest frontend notes have been added. The home screen remains calm, with only the assistant animated."}
];
const $=s=>document.querySelector(s);
const E={
  clock:$("#clock"),date:$("#date"),avatarBase:$("#avatarBase"),avatarBlink:$("#avatarBlink"),
  avatarMouth:$("#avatarMouth"),avatarAccessibleName:$("#avatarAccessibleName"),
  state:$("#stateLabel"),agent:$("#agentLabel"),
  mic:$("#mic"),appearance:$("#appearance"),avatarBtn:$("#avatarBtn"),dialog:$("#appearanceDialog"),
  grid:$("#appearanceGrid"),apply:$("#apply"),transcript:$("#transcript"),close:$("#closeTranscript"),
  heard:$("#heard"),reply:$("#reply"),homeView:$("#homeView"),workspaceView:$("#workspaceView"),
  workspaceTitle:$("#workspaceTitle"),workspaceStatus:$("#workspaceStatus"),workspaceHome:$("#workspaceHome"),
  emailWorkspace:$("#emailWorkspace"),genericWorkspace:$("#genericWorkspace"),genericTitle:$("#genericTitle"),
  genericIcon:$("#genericIcon"),accountList:$("#accountList"),addAccount:$("#addAccount"),
  emptyAddAccount:$("#emptyAddAccount"),accountDialog:$("#accountDialog"),emptyAccounts:$("#emptyAccounts"),
  mailContent:$("#mailContent"),activeAccountName:$("#activeAccountName"),messageList:$("#messageList"),
  messagePreview:$("#messagePreview"),emailCommand:$("#emailCommand"),runEmailCommand:$("#runEmailCommand"),
  composeButton:$("#composeButton"),workspaceStatus:$("#workspaceStatus")
};
let S={
  avatar:localStorage.getItem("cd.avatar")||"nova",
  theme:localStorage.getItem("cd.theme")||"platinum",
  workspace:"home",mode:"idle",recognition:null,sa:null,st:null,
  accounts:JSON.parse(localStorage.getItem("cd.email.accounts")||"[]"),
  activeAccount:localStorage.getItem("cd.email.active")||null,
  blinkTimer:null,mouthTimer:null,availableFrames:{blink:false,mouth:[]}
};
function clock(){
  const n=new Date();
  E.clock.textContent=n.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",hour12:false});
  E.date.textContent=n.toLocaleDateString("en-AU",{weekday:"short",day:"numeric",month:"short"}).toUpperCase();
}
clock();setInterval(clock,1000);
function appearance(a,t,save=true){
  S.avatar=a;S.theme=t;document.body.dataset.avatar=a;document.body.dataset.theme=t;
  E.avatarBase.src=`assets/avatars/${a}.png`;
  E.avatarAccessibleName.textContent=avatars[a];
  resetAvatarFrame();
  loadAvatarFrames(a);
  if(save){localStorage.setItem("cd.avatar",a);localStorage.setItem("cd.theme",t)}
}

function frameExists(src){
  return new Promise(resolve=>{
    const img=new Image();
    img.onload=()=>resolve(true);
    img.onerror=()=>resolve(false);
    img.src=src;
  });
}
async function loadAvatarFrames(avatar){
  stopBlinking();stopMouthAnimation();resetAvatarFrame();
  const blink=`assets/avatars/${avatar}_blink.png`;
  const mouthCandidates=[1,2,3,4].map(n=>`assets/avatars/${avatar}_mouth_${n}.png`);
  const blinkAvailable=await frameExists(blink);
  const mouthChecks=await Promise.all(mouthCandidates.map(frameExists));
  if(S.avatar!==avatar)return;
  S.availableFrames={
    blink:blinkAvailable,
    mouth:mouthCandidates.filter((_,i)=>mouthChecks[i])
  };
  if(blinkAvailable)E.avatarBlink.src=blink;
  if(S.availableFrames.mouth.length)E.avatarMouth.src=S.availableFrames.mouth[0];
  scheduleBlink();
  if(S.mode==="speaking")startMouthAnimation();
}
function showAvatarFrame(frame){
  [E.avatarBase,E.avatarBlink,E.avatarMouth].forEach(img=>img.classList.remove("active"));
  frame.classList.add("active");
}
function resetAvatarFrame(){
  showAvatarFrame(E.avatarBase);
}
function stopBlinking(){
  if(S.blinkTimer){clearTimeout(S.blinkTimer);S.blinkTimer=null}
}
function scheduleBlink(){
  stopBlinking();
  if(!S.availableFrames.blink||S.mode==="speaking")return;
  const delay=3800+Math.random()*5200;
  S.blinkTimer=setTimeout(()=>{
    if(S.mode!=="speaking"&&S.availableFrames.blink){
      showAvatarFrame(E.avatarBlink);
      setTimeout(()=>{
        resetAvatarFrame();
        scheduleBlink();
      },90+Math.random()*55);
    }else scheduleBlink();
  },delay);
}
function stopMouthAnimation(){
  if(S.mouthTimer){clearTimeout(S.mouthTimer);S.mouthTimer=null}
  resetAvatarFrame();
}
function startMouthAnimation(){
  stopBlinking();stopMouthAnimation();
  const frames=S.availableFrames.mouth;
  if(!frames.length)return;
  let previous=-1;
  const tick=()=>{
    if(S.mode!=="speaking"){stopMouthAnimation();scheduleBlink();return}
    let index=Math.floor(Math.random()*frames.length);
    if(frames.length>1&&index===previous)index=(index+1)%frames.length;
    previous=index;
    E.avatarMouth.src=frames[index];
    showAvatarFrame(E.avatarMouth);
    S.mouthTimer=setTimeout(tick,85+Math.random()*75);
  };
  tick();
}
function mode(m,label){
  S.mode=m;document.body.dataset.state=m;
  const text=label||{idle:"READY",listening:"LISTENING",thinking:"THINKING",speaking:"SPEAKING",working:"WORKING"}[m]||"READY";
  E.state.textContent=text;E.workspaceStatus.textContent=text;
  E.mic.classList.toggle("active",m==="listening");E.mic.textContent=m==="listening"?"■":"●";
  if(m==="speaking")startMouthAnimation();
  else{
    stopMouthAnimation();
    scheduleBlink();
  }
}
function openDialog(d){
  if(typeof d.showModal==="function")d.showModal();else d.setAttribute("open","");
}
function closeDialog(d){
  if(typeof d.close==="function")d.close();else d.removeAttribute("open");
}
function renderGrid(){
  E.grid.innerHTML="";
  Object.keys(avatars).forEach(a=>Object.keys(themes).forEach(t=>{
    const x=themes[t],b=document.createElement("button");
    b.type="button";b.className="option"+(S.sa===a&&S.st===t?" selected":"");
    b.style.setProperty("--pa",x.a);b.style.setProperty("--pb",x.b);
    b.style.setProperty("--pc",x.c);b.style.setProperty("--pg",x.g);
    b.innerHTML=`<img src="assets/avatars/${a}.png" alt="${avatars[a]}"><strong>${avatars[a]}</strong><small>${x.name}</small>`;
    b.onclick=()=>{S.sa=a;S.st=t;renderGrid()};E.grid.appendChild(b);
  }));
}
function openAppearance(){
  S.sa=S.avatar;S.st=S.theme;renderGrid();E.appearance.setAttribute("aria-expanded","true");openDialog(E.dialog);
}
E.appearance.onclick=openAppearance;
E.apply.onclick=e=>{e.preventDefault();appearance(S.sa,S.st);closeDialog(E.dialog);E.appearance.setAttribute("aria-expanded","false")};
E.dialog.addEventListener("close",()=>E.appearance.setAttribute("aria-expanded","false"));
E.avatarBtn.onclick=()=>E.mic.click();

function setWorkspace(name){
  S.workspace=name;
  document.querySelectorAll(".dock-item").forEach(b=>b.classList.toggle("active",b.dataset.workspace===name));
  if(name==="home"){
    E.workspaceView.classList.remove("active");E.homeView.classList.add("active");E.agent.textContent="HOME";
    mode("idle");return;
  }
  const info=workspaceInfo[name];
  E.homeView.classList.remove("active");E.workspaceView.classList.add("active");
  E.workspaceTitle.textContent=info.title;E.agent.textContent=info.title.toUpperCase();
  E.emailWorkspace.hidden=name!=="email";E.genericWorkspace.hidden=name==="email";
  if(name==="email"){renderAccounts();renderMail()}
  else{E.genericTitle.textContent=info.title;E.genericIcon.textContent=info.icon}
  mode("idle");
}
document.querySelectorAll(".dock-item").forEach(b=>b.onclick=()=>setWorkspace(b.dataset.workspace));
E.workspaceHome.onclick=()=>setWorkspace("home");

function accountInitial(provider){return provider==="iCloud"?"☁":provider.charAt(0).toUpperCase()}
function renderAccounts(){
  E.accountList.innerHTML="";
  S.accounts.forEach((account,index)=>{
    const b=document.createElement("button");
    b.className="account-item"+(account.id===S.activeAccount?" active":"");
    b.innerHTML=`<span class="account-badge">${accountInitial(account.provider)}</span><span class="account-meta"><strong>${account.label}</strong><small>${account.address}</small></span>`;
    b.onclick=()=>{S.activeAccount=account.id;localStorage.setItem("cd.email.active",account.id);renderAccounts();renderMail()};
    E.accountList.appendChild(b);
  });
}
function renderMail(){
  const account=S.accounts.find(a=>a.id===S.activeAccount)||S.accounts[0];
  if(account&&!S.activeAccount){S.activeAccount=account.id;localStorage.setItem("cd.email.active",account.id)}
  const has=Boolean(account);
  E.emptyAccounts.hidden=has;E.mailContent.hidden=!has;
  if(!has)return;
  E.activeAccountName.textContent=account.label;
  E.messageList.innerHTML="";
  sampleMessages.forEach((m,i)=>{
    const b=document.createElement("button");b.className="message-row";
    b.innerHTML=`<span class="sender-badge">${m.sender.charAt(0)}</span><span class="message-copy"><strong>${m.sender}</strong><span>${m.subject}</span><small>${m.snippet}</small></span><span class="message-time">${m.time}</span>`;
    b.onclick=()=>openMessage(m,b);E.messageList.appendChild(b);
  });
}
function openMessage(m,b){
  document.querySelectorAll(".message-row").forEach(x=>x.classList.remove("active"));b.classList.add("active");
  E.messagePreview.innerHTML=`<div class="preview-mail"><h3>${m.subject}</h3><div class="from">From ${m.sender}</div><div class="body">${m.body.replace(/\n/g,"<br>")}</div></div>`;
}
function addProvider(provider){
  const count=S.accounts.filter(a=>a.provider===provider).length+1;
  const account={id:`${provider.toLowerCase()}-${Date.now()}`,provider,label:count>1?`${provider} ${count}`:provider,address:`${provider.toLowerCase().replace(/\s/g,"")}@example.com`};
  S.accounts.push(account);S.activeAccount=account.id;
  localStorage.setItem("cd.email.accounts",JSON.stringify(S.accounts));localStorage.setItem("cd.email.active",account.id);
  renderAccounts();renderMail();closeDialog(E.accountDialog);mode("idle","ACCOUNT ADDED");
  setTimeout(()=>mode("idle"),1200);
}
E.addAccount.onclick=()=>openDialog(E.accountDialog);
E.emptyAddAccount.onclick=()=>openDialog(E.accountDialog);
document.querySelectorAll("[data-provider]").forEach(b=>b.onclick=()=>addProvider(b.dataset.provider));
E.composeButton.onclick=()=>{mode("working","DRAFTING");E.messagePreview.innerHTML='<div class="preview-mail"><h3>New message</h3><div class="from">Draft</div><div class="body">The Email assistant is preparing a new draft.</div></div>';setTimeout(()=>mode("idle","READY"),1100)};
function runEmailCommand(){
  const command=E.emailCommand.value.trim();if(!command)return;
  mode("working","WORKING");
  E.messagePreview.innerHTML=`<div class="preview-mail"><h3>Email assistant</h3><div class="from">Command received</div><div class="body">${command}<br><br><strong>Frontend preview:</strong> the request has been queued. The backend will perform the real email action once connected.</div></div>`;
  E.emailCommand.value="";setTimeout(()=>mode("idle","READY"),1300);
}
E.runEmailCommand.onclick=runEmailCommand;
E.emailCommand.addEventListener("keydown",e=>{if(e.key==="Enter")runEmailCommand()});

function transcript(open=true){E.transcript.classList.toggle("open",open);E.transcript.setAttribute("aria-hidden",String(!open))}
E.close.onclick=()=>transcript(false);
async function requestReply(msg){
  if(C.demoMode||!C.backendBaseUrl)throw Error("Not connected");
  const base=String(C.backendBaseUrl).replace(/\/$/,""),endpoint=String(C.endpoints?.chat||"/chat");
  const r=await fetch(base+(endpoint.startsWith("/")?endpoint:"/"+endpoint),{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({avatar:S.avatar,theme:S.theme,workspace:S.workspace,message:msg})
  });
  if(!r.ok)throw Error(`HTTP ${r.status}`);const d=await r.json();
  return String(d.reply??d.message??d.response??"");
}
function speak(txt){
  if(!("speechSynthesis"in window)||!txt){mode("idle");return}
  speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(txt);
  u.lang=C.speechLanguage||"en-AU";u.rate=.95;u.pitch=S.avatar==="halo"?.86:1;
  u.onstart=()=>mode("speaking");u.onend=()=>mode("idle");u.onerror=()=>mode("idle");
  speechSynthesis.speak(u);
}
async function submit(msg){
  msg=msg.trim();if(!msg){mode("idle");return}
  E.heard.textContent=msg;E.reply.textContent="";transcript(true);mode("thinking");
  try{const r=await requestReply(msg);E.reply.textContent=r;speak(r)}
  catch{E.reply.textContent="The assistant service is not connected yet. The frontend workspace remains available.";mode("idle")}
}
const R=window.SpeechRecognition||window.webkitSpeechRecognition;
if(R){
  S.recognition=new R();S.recognition.lang=C.speechLanguage||"en-AU";S.recognition.interimResults=true;S.recognition.continuous=false;
  S.recognition.onstart=()=>mode("listening");
  S.recognition.onresult=e=>{let t="";for(let i=e.resultIndex;i<e.results.length;i++)t+=e.results[i][0].transcript;E.heard.textContent=t;if(e.results[e.results.length-1].isFinal)submit(t)};
  S.recognition.onerror=()=>mode("idle");S.recognition.onend=()=>{if(S.mode==="listening")mode("idle")};
}
E.mic.onclick=()=>{
  if(S.mode==="speaking"){speechSynthesis.cancel();mode("idle");return}
  if(!S.recognition){E.heard.textContent="Voice recognition is not supported in this browser. Use Chrome or Edge.";transcript(true);return}
  if(S.mode==="listening"){S.recognition.stop();mode("idle")}
  else{E.heard.textContent="";E.reply.textContent="";S.recognition.start()}
};
appearance(S.avatar,S.theme,false);mode("idle");renderAccounts();renderMail();setWorkspace("home");
