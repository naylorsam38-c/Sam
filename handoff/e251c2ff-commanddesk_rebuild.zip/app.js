(()=>{
'use strict';
const C=window.COMMAND_DESK_CONFIG||{};
const base=(C.backendBaseUrl||'').replace(/\/$/,'');
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];

/* ---------- storage schema versioning (auto-wipes incompatible old data) ---------- */
const SCHEMA=5;
const K={schema:'cd.schema.version',apps:'cd.apps.v5',sessions:'cd.sessions.v5',messages:'cd.messages.v5',settings:'cd.settings.v5',placed:'cd.placed.v5'};
(function migrate(){
  const v=Number(localStorage.getItem(K.schema)||0);
  if(v!==SCHEMA){
    // wipe every old cd.* key so a structurally different build can't strand the user
    Object.keys(localStorage).filter(k=>k.startsWith('cd.')).forEach(k=>localStorage.removeItem(k));
    localStorage.setItem(K.schema,String(SCHEMA));
  }
})();
const parse=(k,f)=>{try{const v=localStorage.getItem(k);return v==null?f:(JSON.parse(v)??f)}catch{return f}};

/* ---------- state ---------- */
const S={
  agents:[],            // from backend /agents
  view:'home',          // 'home' | 'room'
  active:null,          // active non-hub agent id when in a room
  hubId:null,
  apps:parse(K.apps,{}),        // per-agent app lists
  sessions:parse(K.sessions,{}),// per-agent session_id (REAL backend contract)
  messages:parse(K.messages,{}),// per-agent transcript
  placed:parse(K.placed,null),  // ordered list of agent ids shown as tiles
  settings:parse(K.settings,{appearance:'dark',speech:false})
};

const E={
  body:document.body,
  homeView:$('#homeView'), roomView:$('#roomView'),
  homeDate:$('#homeDate'), roomDate:$('#roomDate'),
  homeMenuBtn:$('#homeMenuBtn'), homeMenu:$('#homeMenu'),
  nova:$('#nova'), novaStatus:$('#novaStatus'), connection:$('#connection'),
  tileGrid:$('#tileGrid'),
  homeTranscript:$('#homeTranscript'), homeForm:$('#homeForm'), homeInput:$('#homeInput'),
  backBtn:$('#backBtn'), switchBtn:$('#switchBtn'), switchMenu:$('#switchMenu'),
  skinBtn:$('#skinBtn'), skinMenu:$('#skinMenu'),
  roomName:$('#roomName'), roomState:$('#roomState'),
  appRow:$('#appRow'),
  roomTranscript:$('#roomTranscript'), roomForm:$('#roomForm'), roomInput:$('#roomInput'),
  homeMic:$('#homeMic'), roomMic:$('#roomMic'),
  pickerDialog:$('#pickerDialog'), pickerList:$('#pickerList'), pickerCustom:$('#pickerCustom'),
  appDialog:$('#appDialog'), appForm:$('#appForm'), appDialogTitle:$('#appDialogTitle'),
  viewer:$('#viewerDialog'), viewerTitle:$('#viewerTitle'), viewerClose:$('#viewerClose'),
  viewerExternal:$('#viewerExternal'), viewerFallback:$('#viewerFallback'),
  viewerFallbackOpen:$('#viewerFallbackOpen'), appFrame:$('#appFrame'),
  settingsDialog:$('#settingsDialog'), appearance:$('#appearance'), speechEnabled:$('#speechEnabled'),
  statusDialog:$('#statusDialog'), statusContent:$('#statusContent'),
  importFile:$('#importFile')
};

const id=()=>crypto.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const save=()=>{localStorage.setItem(K.apps,JSON.stringify(S.apps));localStorage.setItem(K.sessions,JSON.stringify(S.sessions));localStorage.setItem(K.messages,JSON.stringify(S.messages));localStorage.setItem(K.settings,JSON.stringify(S.settings));localStorage.setItem(K.placed,JSON.stringify(S.placed));};
function endpoint(name){const p=C.endpoints?.[name];if(!p)return null;return base+(p.startsWith('/')?p:'/'+p)}
const hubNames=(C.hubNames||['hub']).map(x=>String(x).toLowerCase());
const isHub=a=>a&&(hubNames.includes(String(a.id).toLowerCase())||hubNames.includes(String(a.name).toLowerCase()));
const agentById=aid=>S.agents.find(a=>a.id===aid);
const apps=aid=>S.apps[aid]||(S.apps[aid]=[]);
const msgs=aid=>S.messages[aid]||(S.messages[aid]=[]);
const BUSY=new Set(); // agent ids with a live in-flight request = that tile's own activity light

/* ---------- Nova face states ---------- */
function novaState(state,label){
  E.nova.className=`nova ${state}`;
  if(label){E.novaStatus.textContent=label; if(E.roomState)E.roomState.textContent=label;}
  if(['success','error'].includes(state))setTimeout(()=>novaState('idle','Ready'),1500);
}
/* Face engine: swaps mouth frames if the art exists (nova_mouth_1..4.png),
   otherwise a speech-synced jaw motion on the static portrait. Wiring is here
   now so dropping the art into assets/avatars/ later "just works". */
const FACE={ready:false,mouth:[],idx:0};
let talkTimer=null;
function initFace(){
  const names=Array.isArray(C.novaFrames)?C.novaFrames:[];
  if(names.length<2)return;              // no art listed -> static portrait + speech-synced motion
  buildFrames(names.map(n=>'assets/avatars/'+n));
}
function buildFrames(srcs){
  E.nova.classList.add('has-frames');
  const b=E.nova.querySelector('img');if(b)b.classList.add('base');
  FACE.mouth=srcs.map((s,i)=>{const im=document.createElement('img');im.src=s;im.className='frame'+(i===0?' active':'');E.nova.appendChild(im);return im;});
  FACE.ready=true;
}
function showFrame(i){if(FACE.ready)FACE.mouth.forEach((im,k)=>im.classList.toggle('active',k===i));}
function blink(){
  if(!E.nova.classList.contains('talking')){E.nova.classList.add('blink');setTimeout(()=>E.nova.classList.remove('blink'),130);}
  setTimeout(blink,3200+Math.random()*5000);
}
function startTalk(){
  if(talkTimer)return;
  E.nova.classList.add('talking');
  talkTimer=setInterval(()=>{
    if(FACE.ready){FACE.idx=(FACE.idx+1)%FACE.mouth.length;showFrame(FACE.idx);}
    else E.nova.classList.toggle('mouth-open');
  },130);
}
function stopTalk(){
  if(talkTimer){clearInterval(talkTimer);talkTimer=null;}
  E.nova.classList.remove('talking','mouth-open');
  if(FACE.ready)showFrame(0);
  novaState('idle','Ready');
}

/* ---------- iOS speech unlock: must fire inside a user gesture ----------
   Safari drops any speechSynthesis call not chained to a tap. We prime it
   synchronously on submit, so the later (async) reply can actually speak. */
let speechPrimed=false;
function primeSpeech(){
  if(speechPrimed||!('speechSynthesis'in window))return;
  try{const u=new SpeechSynthesisUtterance('');u.volume=0;speechSynthesis.speak(u);speechPrimed=true;}catch{}
}
function speak(text){
  if(!S.settings.speech||!('speechSynthesis'in window)){novaState('idle','Ready');return;}
  try{
    speechSynthesis.cancel();
    const u=new SpeechSynthesisUtterance(text);
    u.lang=C.speechLanguage||'en-AU';
    u.onstart=startTalk;u.onend=stopTalk;u.onerror=stopTalk;
    speechSynthesis.speak(u);
    setTimeout(()=>{if(speechSynthesis.speaking)startTalk();},140); // net for engines that skip onstart
  }catch{stopTalk();}
}

/* ---------- REAL backend chat (unchanged contract: session_id per agent) ---------- */
async function fetchJson(url,options={}){const r=await fetch(url,{credentials:'same-origin',...options});if(!r.ok)throw new Error(`${r.status}`);return r.json();}
async function chat(agent,message,sessionId){
  const url=endpoint('chat');if(!url)throw new Error('chat endpoint missing');
  const payload={avatar:'nova',theme:'platinum',agent,message,apps:apps(agent).map(a=>a.name)};
  if(sessionId)payload.session_id=sessionId;
  const d=await fetchJson(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  return {text:d.reply||d.message||d.response||d.content||String(d),sessionId:d.session_id||d.sessionId||sessionId};
}

/* ---------- transcript rendering ---------- */
function renderTranscript(el,aid,emptyMsg){
  el.innerHTML='';
  const list=msgs(aid);
  if(!list.length){const n=document.createElement('div');n.className='msg system';n.textContent=emptyMsg;el.append(n);}
  else list.forEach(m=>{const d=document.createElement('div');d.className=`msg ${m.role||'assistant'}`;d.textContent=m.text;el.append(d);});
  el.scrollTop=el.scrollHeight;
}
function renderHomeTranscript(){renderTranscript(E.homeTranscript,S.hubId,'Nova is ready. Tell her what you need.');}
function renderRoomTranscript(){renderTranscript(E.roomTranscript,S.active,'This agent is ready.');}

/* ---------- send (home talks to hub, room talks to active agent) ---------- */
async function send(aid,text,onTranscript){
  msgs(aid).push({role:'user',text});onTranscript();save();
  BUSY.add(aid);renderTiles();          // this agent's tile lights up: it's working
  novaState('thinking','Thinking');
  try{
    const out=await chat(aid,text,S.sessions[aid]);
    S.sessions[aid]=out.sessionId;
    msgs(aid).push({role:'assistant',text:out.text});onTranscript();save();
    novaState('speaking','Speaking');
    speak(out.text);
    if(!S.settings.speech)setTimeout(()=>novaState('idle','Ready'),500);
  }catch{
    msgs(aid).push({role:'assistant',text:'Could not reach the backend.'});onTranscript();
    novaState('error','Connection error');
  }finally{
    BUSY.delete(aid);renderTiles();      // work done: light goes out
  }
}

/* ---------- tiles (blank agent squares + plus), under Nova ---------- */
function nonHubAgents(){return S.agents.filter(a=>!isHub(a));}
function ensurePlaced(){
  if(!Array.isArray(S.placed)){
    // default: first four non-hub agents get a blank tile
    S.placed=nonHubAgents().slice(0,4).map(a=>a.id);
    save();
  }
}
function renderTiles(){
  ensurePlaced();
  E.tileGrid.innerHTML='';
  S.placed.forEach(aid=>{
    const a=agentById(aid);if(!a)return;
    const b=document.createElement('button');b.type='button';b.className='tile';b.dataset.id=aid;
    const appList=apps(aid);
    const icons=appList.slice(0,3).map(x=>x.icon||x.name?.[0]||'•').join(' ');
    // blank until apps define it; show app icons once assigned
    b.innerHTML=`<span class="tile-face">${esc(icons)}</span>`;
    // per-tile activity indicator: lights whenever THAT agent has live work
    if(BUSY.has(aid))b.classList.add('busy');
    b.onclick=()=>enterRoom(aid);
    E.tileGrid.append(b);
  });
  // plus tile = add another agent (drops a new blank tile below)
  const rest=nonHubAgents().filter(a=>!S.placed.includes(a.id));
  const plus=document.createElement('button');plus.type='button';plus.className='tile plus';
  plus.innerHTML='<span class="tile-face">+</span>';
  plus.onclick=()=>{
    if(rest.length){S.placed.push(rest[0].id);save();renderTiles();}
    else novaState('idle','No more agents available');
  };
  E.tileGrid.append(plus);
}

/* ---------- views ---------- */
function showHome(){
  S.view='home';S.active=null;E.body.dataset.view='home';
  E.homeView.hidden=false;E.roomView.hidden=true;
  renderTiles();renderHomeTranscript();
  novaState('idle','Ready');
}
function enterRoom(aid){
  S.view='room';S.active=aid;E.body.dataset.view='room';
  E.homeView.hidden=true;E.roomView.hidden=false;
  const a=agentById(aid);
  E.roomName.textContent=a?.name||'Agent';
  renderAppRow();renderRoomTranscript();
  novaState('idle','Ready');
  closeMenus();
}

/* ---------- agent switcher (three-line menu, not a page-covering box) ---------- */
function buildSwitchMenu(){
  E.switchMenu.innerHTML='';
  S.placed.forEach(aid=>{
    const a=agentById(aid);if(!a)return;
    const btn=document.createElement('button');btn.type='button';
    btn.textContent=a.name+(aid===S.active?' ·':'');
    btn.onclick=()=>{enterRoom(aid);E.switchMenu.hidden=true;};
    E.switchMenu.append(btn);
  });
  const home=document.createElement('button');home.type='button';home.textContent='‹ Home (Nova)';
  home.onclick=()=>{showHome();E.switchMenu.hidden=true;};
  E.switchMenu.append(home);
}

/* ---------- apps in a room ---------- */
const PRESET_APPS=[
  {name:'Gmail',url:'https://mail.google.com',icon:'✉'},
  {name:'Calendar',url:'https://calendar.google.com',icon:'▦'},
  {name:'Drive',url:'https://drive.google.com',icon:'△'},
  {name:'Maps',url:'https://maps.google.com',icon:'◉'},
  {name:'Notes',url:'https://keep.google.com',icon:'▤'},
  {name:'Weather',url:'https://weather.com',icon:'☁'},
  {name:'News',url:'https://news.google.com',icon:'▣'},
  {name:'YouTube',url:'https://youtube.com',icon:'▶'}
];
function renderAppRow(){
  E.appRow.innerHTML='';
  apps(S.active).forEach((a,i)=>{
    const b=document.createElement('button');b.type='button';b.className='app-chip';
    b.innerHTML=`<span class="app-icon">${esc(a.icon||a.name?.[0]||'?')}</span><small>${esc(a.name)}</small>`;
    b.onclick=()=>openApp(a);
    b.oncontextmenu=e=>{e.preventDefault();if(confirm(`Remove ${a.name}?`)){apps(S.active).splice(i,1);save();renderAppRow();}};
    E.appRow.append(b);
  });
  const add=document.createElement('button');add.type='button';add.className='app-chip add';
  add.innerHTML='<span class="app-icon">+</span><small>Add</small>';
  add.onclick=openPicker;
  E.appRow.append(add);
}
function openPicker(){
  E.pickerList.innerHTML='';
  const existing=new Set(apps(S.active).map(a=>a.name));
  PRESET_APPS.forEach(p=>{
    const row=document.createElement('button');row.type='button';row.className='picker-row';
    row.innerHTML=`<span class="app-icon">${esc(p.icon)}</span><span>${esc(p.name)}</span>${existing.has(p.name)?'<em>added</em>':''}`;
    row.disabled=existing.has(p.name);
    row.onclick=()=>{apps(S.active).push({id:id(),...p});save();renderAppRow();renderTiles();E.pickerDialog.close();};
    E.pickerList.append(row);
  });
  E.pickerDialog.showModal();
}

/* ---------- app viewer (iframe; falls back to external when the app blocks embedding) ---------- */
function blockedEmbed(url){try{const h=new URL(url,location.href).hostname;return['accounts.google.com','mail.google.com','calendar.google.com','drive.google.com','google.com','youtube.com','icloud.com','notion.so','chatgpt.com','openai.com'].some(x=>h===x||h.endsWith('.'+x));}catch{return true;}}
let viewerApp=null;
function openExternal(a){const w=window.open(a.url,'_blank','noopener,noreferrer');if(!w)novaState('idle','Allow pop-ups to open this app');}
function openApp(a){
  viewerApp=a;novaState('success',`Opening ${a.name}`);
  if(blockedEmbed(a.url)){
    // honest: Gmail/Google refuse to load in an iframe. Show fallback + open externally.
    E.viewerTitle.textContent=a.name;E.appFrame.hidden=true;E.viewerFallback.hidden=false;E.viewer.showModal();
    return;
  }
  E.viewerTitle.textContent=a.name;E.appFrame.hidden=false;E.viewerFallback.hidden=true;E.appFrame.src=a.url;E.viewer.showModal();
}

/* ---------- menus ---------- */
function closeMenus(){E.homeMenu.hidden=true;E.switchMenu.hidden=true;E.skinMenu.hidden=true;}
function applySettings(){E.body.classList.remove('light','soft');if(S.settings.appearance!=='dark')E.body.classList.add(S.settings.appearance);}

/* ---------- load agents from REAL backend ---------- */
async function loadAgents(){
  try{
    const data=await fetchJson(endpoint('agents'));
    const list=Array.isArray(data)?data:(data.agents||data.items||[]);
    S.agents=list.map((a,i)=>typeof a==='string'?{id:a,name:a}:{id:a.id||a.slug||a.name||`agent-${i}`,name:a.name||a.label||a.id,role:a.role||a.description||''});
    if(!S.agents.length)throw new Error('empty');
    E.connection.textContent='Live agents connected';
  }catch{
    S.agents=[{id:'hub',name:'Nova'},{id:'research',name:'Research'},{id:'builder',name:'Builder'},{id:'tester',name:'Tester'},{id:'personal_assistant',name:'Assistant'},{id:'consolidator',name:'Consolidator'}];
    E.connection.textContent='Offline preview';
  }
  const hub=S.agents.find(isHub)||S.agents[0];
  S.hubId=hub.id;
  showHome();
}

/* ---------- date ---------- */
function updateDate(){const t=new Intl.DateTimeFormat('en-AU',{weekday:'short',day:'numeric',month:'short'}).format(new Date());E.homeDate.textContent=t;E.roomDate.textContent=t;}

/* ================= wiring ================= */
// home composer -> hub
E.homeForm.onsubmit=e=>{e.preventDefault();primeSpeech();const t=E.homeInput.value.trim();if(!t)return;E.homeInput.value='';E.homeInput.style.height='auto';send(S.hubId,t,renderHomeTranscript);};
// room composer -> active agent
E.roomForm.onsubmit=e=>{e.preventDefault();primeSpeech();const t=E.roomInput.value.trim();if(!t)return;E.roomInput.value='';E.roomInput.style.height='auto';send(S.active,t,renderRoomTranscript);};
[E.homeInput,E.roomInput].forEach(inp=>inp.addEventListener('input',()=>{inp.style.height='auto';inp.style.height=Math.min(inp.scrollHeight,120)+'px';}));

E.backBtn.onclick=()=>showHome();
E.switchBtn.onclick=()=>{buildSwitchMenu();E.switchMenu.hidden=!E.switchMenu.hidden;E.skinMenu.hidden=true;};
E.skinBtn.onclick=()=>{E.skinMenu.hidden=!E.skinMenu.hidden;E.switchMenu.hidden=true;};
E.skinMenu.onclick=e=>{const s=e.target.dataset.skin;if(!s)return;S.settings.appearance=s;save();applySettings();E.skinMenu.hidden=true;};

E.homeMenuBtn.onclick=()=>{E.homeMenu.hidden=!E.homeMenu.hidden;};
E.homeMenu.onclick=e=>{const action=e.target.dataset.menu;if(!action)return;E.homeMenu.hidden=true;
  if(action==='theme'){E.appearance.value=S.settings.appearance;E.speechEnabled.checked=!!S.settings.speech;E.settingsDialog.showModal();}
  if(action==='notifications'){if(!('Notification'in window))novaState('idle','Notifications unsupported');else Notification.requestPermission().then(p=>novaState('idle',`Notifications: ${p}`));}
  if(action==='export')exportData();
  if(action==='import')E.importFile.click();
  if(action==='about')showStatus();
};
document.addEventListener('click',e=>{if(!e.target.closest('.bar')&&!e.target.closest('.dropdown'))closeMenus();});

// picker + custom app
E.pickerCustom.onclick=()=>{E.pickerDialog.close();E.appForm.reset();E.appDialogTitle.textContent='Custom app';E.appDialog.showModal();};
$('#saveApp').onclick=e=>{e.preventDefault();if(!E.appForm.reportValidity())return;const d=new FormData(E.appForm);const next={id:id(),name:String(d.get('name')).trim(),url:String(d.get('url')).trim(),icon:String(d.get('icon')||String(d.get('name'))[0]).trim()};apps(S.active).push(next);save();E.appDialog.close();renderAppRow();renderTiles();};

// viewer
E.viewerClose.onclick=()=>{E.appFrame.src='about:blank';E.viewer.close();};
E.viewerExternal.onclick=()=>viewerApp&&openExternal(viewerApp);
E.viewerFallbackOpen.onclick=()=>viewerApp&&openExternal(viewerApp);
E.appFrame.onerror=()=>{E.appFrame.hidden=true;E.viewerFallback.hidden=false;};

// settings
$('#saveSettings').onclick=e=>{e.preventDefault();S.settings.appearance=E.appearance.value;S.settings.speech=E.speechEnabled.checked;save();applySettings();E.settingsDialog.close();};

// export / import / status
function exportData(){const data={version:SCHEMA,exported_at:new Date().toISOString(),apps:S.apps,messages:S.messages,sessions:S.sessions,settings:S.settings,placed:S.placed};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`command-desk-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href);}
async function importData(file){try{const d=JSON.parse(await file.text());if(d.apps)S.apps=d.apps;if(d.messages)S.messages=d.messages;if(d.sessions)S.sessions=d.sessions;if(d.settings)S.settings=d.settings;if(d.placed)S.placed=d.placed;save();applySettings();showHome();novaState('success','Data imported');}catch{novaState('error','Import failed');}}
E.importFile.onchange=()=>{if(E.importFile.files[0])importData(E.importFile.files[0]);E.importFile.value='';};
function showStatus(){const rows=[['Agents endpoint',endpoint('agents')||'—'],['Chat endpoint',endpoint('chat')||'—'],['Schema version',String(SCHEMA)],['Speech',('speechSynthesis'in window)?'Supported':'Unavailable']];E.statusContent.innerHTML=rows.map(([a,b])=>`<p><strong>${esc(a)}</strong><br>${esc(b)}</p>`).join('');E.statusDialog.showModal();}

/* ---------- voice input (mic): feature-detected, only shown where supported ---------- */
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
function wireMic(btn,input){
  if(!SR){return;} // stays hidden where unsupported (honest — no dead button)
  btn.hidden=false;
  let rec=null,listening=false;
  btn.onclick=()=>{
    if(listening){rec&&rec.stop();return;}
    try{
      rec=new SR();rec.lang=C.speechLanguage||'en-AU';rec.interimResults=false;rec.maxAlternatives=1;
      listening=true;btn.classList.add('listening');primeSpeech();
      rec.onresult=e=>{const t=e.results[0][0].transcript;input.value=(input.value?input.value+' ':'')+t;input.dispatchEvent(new Event('input'));};
      rec.onerror=()=>{};
      rec.onend=()=>{listening=false;btn.classList.remove('listening');};
      rec.start();
    }catch{listening=false;btn.classList.remove('listening');}
  };
}
wireMic(E.homeMic,E.homeInput);
wireMic(E.roomMic,E.roomInput);

/* ---------- boot ---------- */
updateDate();applySettings();initFace();blink();loadAgents();
})();
