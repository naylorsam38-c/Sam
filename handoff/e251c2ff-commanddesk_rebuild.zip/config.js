window.COMMAND_DESK_CONFIG = {
  backendBaseUrl: "/commanddesk",
  endpoints: {
    agents: "/agents",
    chat: "/chat",
    tasksCreate: "/api/tasks",
    tasksStatus: "/api/tasks/{id}",
    tasksCancel: "/api/tasks/{id}/cancel"
  },
  taskPollMs: 2500,
  speechLanguage: "en-AU",
  hubNames: ["hub", "command", "command desk", "nova"],
  authMode: "Existing site session",
  // Nova mouth-frame art. Empty = static portrait with speech-synced motion.
  // When you have the frames, list them here and they animate automatically:
  //   novaFrames: ["nova_mouth_1.png","nova_mouth_2.png","nova_mouth_3.png","nova_mouth_4.png"]
  novaFrames: []
};
