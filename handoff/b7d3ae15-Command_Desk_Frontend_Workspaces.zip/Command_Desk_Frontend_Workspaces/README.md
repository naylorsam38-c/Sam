# Command Desk Frontend – Workspace Build

This frontend includes:

- Static background and static interface elements
- The selected assistant as the only continuously animated element
- Appearance menu beneath the date
- Dedicated Home button and workspace dock
- Fast fade transitions
- Full-screen Email workspace
- Multiple-account frontend flow
- Account switching, inbox preview and email-assistant command field
- Placeholder workspaces for Calendar, Documents, Browser and Projects
- Browser voice recognition and speech synthesis
- Backend-ready chat request hooks

Open `index.html` through a static web server. Edit `config.js` when connecting the backend.
