window.COMMAND_DESK_CONFIG = {
  backendBaseUrl: "/commanddesk",
  demoMode: false,
  endpoints: { agents: "/agents", chat: "/chat" },
  speechLanguage: "en-AU"
};
