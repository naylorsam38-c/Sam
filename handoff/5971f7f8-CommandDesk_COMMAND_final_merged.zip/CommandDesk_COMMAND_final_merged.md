# Command Desk — THE COMMAND. Read top to bottom. Run in order. Don't skip.

This single file is the whole build order. Everything the earlier addendum said is already folded into place below. There is nothing else to reconcile.

**THE GOAL:** Sam talks to Nova live. Nova is just the face. A router picks the right worker LLM. The worker does the real job and sorts it. Sam sees the result on screen. Sam only ever touches TWO things (marked SAM below); everything else is yours.

## READ THIS BEFORE ANYTHING -- the three rules that stop every known failure
- **If this doc is silent, or you are unsure, STOP and ask Sam one line. Never improvise on the live system.** Guessing confidently is the one thing that has broken this before.
- **The live running system is the ONLY truth.** Do not deploy from a zip, a backup, an old build, or memory. Ignore every zip/copy on the box. Read the real files on the live path, change those, prove those. If anything you see on the box contradicts this doc, the box wins -- stop and report, don't guess.
- **You cannot see Sam's phone.** You may prove logs and files you can inspect. You may NEVER write "tested" or "works" for anything only Sam can see or hear. Sam confirms it, or it is not done.

---

## WHAT'S ALREADY ON THE BOX — reuse it, don't rebuild it
- Live backend running on EC2: hub + six agents (hub, research, builder, tester, personal_assistant, consolidator) + oversight + Ollama + SQLite. Keep it -- but as of Stage 0: builder and tester are frozen on a stale refusal (a 30 July "make money without Sam" message stuck in their rolling context, re-fired at every call since); personal_assistant returned one empty reply of three. CLEAR that stale context and confirm ALL SIX answer a FRESH question before building anything on them.
- **Memory already works** — workers reach into it and pull what they need. **Do not touch memory. It is not part of this job.**
- Workers can only TALK right now — they can't act on a real service. Fixing that is the core of this job.
- Front end is dead (voice does nothing) and cluttered (old tiles + bolted-on talking face). It gets replaced.
- Gmail: OAuth app created, API enabled, credential JSON downloaded (project command-desk-nova). NOT installed on the box yet. The "allow" handshake is NOT done.

## THE SPINE — the boundaries. If any of these blur, the system rots. Keep them rigid.
- **Nova is I/O only** — ears, mouth, screen. Voice in, speech + result out. She does NOT decide, route, act, or hold memory.
- **Two brains, by cost.** The **cheap local model (Ollama) is the everyday face** — listening, quick back-and-forth, "anything come in?" — running all day, free. **Sonnet is woken ONLY when Sam says so** -- Sam speaks the switch ("I wanna go deep on this") to wake Sonnet, and drops back to the cheap face when he's done. The face model does NOT decide this itself -- no guessing, no auto-wake. Sam holds the switch. This keeps rich conversation on demand without burning API credits on small talk.
- **The router is its own piece** — separate from Nova. It takes the text and returns a **named worker + confidence**. High -> hand off. Low -> ask Sam which, never guess.
- **Tools live in a permission layer, not inside workers.** A worker REQUESTS an action; the permission layer holds the tool and the gate, and allows or refuses. A worker can never reach a tool directly.
- **State machine + action gate are absolutely rigid.** One state variable; one locked send gate. No worker, no model, no stage may bend them.

Layers: **Nova (I/O)** -> **face model (Ollama); Sam's spoken word wakes Sonnet** -> **router (names worker + confidence)** -> **worker (reasons, requests actions)** -> **permission layer (tools + gate)** -> **real service.** Memory sits alongside, untouched. Audit log records every hop.

## HOW SAM AND THE MACHINE WORK TOGETHER -- the rules Sam locked. No back-and-forth.
The whole point of these rules: Sam gets pulled in as little as humanly possible. No dripping questions, no approve-this-approve-that, no chatter.

- **Reverse-engineer EVERY task BEFORE acting.** The moment Sam hands a task, the brain does NOT start. First it turns the task around and reports back, short: where it breaks, what's unclear, what Sam didn't say, what it would have to guess, where it could go wrong, what could cost money, what can't be undone, what leaves the box -- and above all, the one thing that matters most: what in this task needs SAM, something only he can decide or approve that the machine can't handle itself. It lists these in one pass, then waits for Sam's go. Once Sam answers, the goal is LOCKED and it runs to finished. This one up-front pass is the cure for the back-and-forth: ask everything once, at the start, not dripped out halfway through.
- **Goal locked before handoff.** The brain does not hand a worker anything until the goal is clear and locked. If the goal itself isn't understood, it asks Sam ONCE, up front. A worker never starts on a fuzzy goal and bounces back mid-job.
- **The brain oversees the worker SILENTLY.** Brain hands off -> worker does the WHOLE job start to finish -> result comes back THROUGH the brain. The brain checks the result against the goal itself: does this match what Sam asked? If not, it sends the worker back -- WITHOUT bothering Sam. That whole loop happens below Sam. One handoff, one finished result, no chatter between agents.
- **Workers do NOT talk to each other in an open link.** No free-for-all group chat, no agents scheming amongst themselves with no reins (that is exactly what got builder/tester stuck on 30 July). Straight line only: task DOWN from the brain, result UP to the brain. Every loop ends at the brain, and the brain answers to Sam.
- **Sam sees ONLY finished things.** Never drafts-in-progress, never "is this on the right track", never half-work. If it's not done, it does not come to Sam. Working, thinking, drafting, calling tools to get the job done -- all of that is the machine's own business, no approval.
- **The gate is: anything that LEAVES THE BOX to someone who isn't Sam needs Sam's yes.** Not "it did something" -- work all it wants inside the box. The line is "something crossed the fence to the outside world." Email landing in someone's inbox, a refund hitting a card, a quote going to a client, a post on a forum, a message texting someone, ANYTHING spending money or committing Sam or that can't be undone -- that STOPS for Sam's approval. Building an app is inside (no approval). Sending that app to a client is out (approval). The send gate in Stage 4 is the mechanism, but the rule is wider than email: everything outbound. Anything the machine can't clearly classify as "inside", it treats as OUT and asks.
- **Small forks it decides; consequential forks it stops.** Once the goal is locked it works itself out and does NOT come back for small calls (colours, wording, ordering). It stops ONLY when a wrong guess would actually cost Sam -- send the wrong thing, spend money, pick the wrong recipient/target, or drift the goal. Not "approve this paragraph" -- "this genuinely changes what you asked, or it's about to leave the box."
- **"Done" must be PROVEN, not claimed.** A worker that silently failed and wrapped it clean is the one thing the outbound gate can't catch. Finished means shown-real, not "I finished." 

## THE PINS — every stage, no exceptions
1. Front end: /var/www/commanddesk. Prove on airexploit.com/commanddesk. Backend: the running system.
2. Reuse hub, agents, Ollama, SQLite, memory. Don't rebuild what runs.
3. Back up front end AND backend before touching either, and confirm the backup is COMPLETE (a backup you can't restore is not a backup). Old front end stays restorable. If a backend restart is needed to load a new module, back up first, restart, confirm 200 with ALL agents alive -- if it doesn't come back, roll back.
4. Add new capability as NEW files/modules. Never overwrite the existing hub or agents. The personal_assistant agent IS the mail worker — give it the tool, don't spawn a new agent.
5. Straight quotes only. Copy any supplied image assets on deploy (no video). Curl 200 before any deploy is called done.
6. Worker brains: Ollama for the face and simple work; Sonnet only on wake for heavy thinking.
7. Audit log lives in the existing SQLite. Every state change + action: timestamp, state, trigger, result.
8. State machine is a real variable, not a vibe. Sending lives in the permission layer, uncallable unless state is awaiting_confirmation AND a "yes" was captured. Off until Stage 4.
9. Gmail does NOT embed in the frame — settled. Worker returns text; it shows in the panel. Don't try to iframe it.
10. "Done" = audit log shows the states firing on the live site AND Sam has seen/heard it. **HTTP 200 means the page loaded, NOT that it works** -- a page can load and be dead. Sam's confirmation is the real done. If Sam says it's broken, roll back. You CANNOT watch Sam's phone; never fake "tested". Sam is the final eyes.
11. One stage at a time. Finish, prove, STOP, wait for go. One interruption allowed only if a key/permission is genuinely missing — one line, then carry on.

---

## SECURITY — IDENTITY GATE (a hard stop, not a warning; built in Stage 1)

The live page at airexploit.com/commanddesk is public. On a public URL with no login, a "session" is only a browser tab. That is not enough to attach Gmail to.

**No Gmail tool — read, draft, or send — may become reachable until the session is logged in as Sam.** Until login passes:
- Stage 3 does not start.
- The permission layer refuses every Gmail operation regardless of state, worker, or confirmation.
- A logged-out visitor must be unable to read mail, create drafts, reach the confirmation prompt, send, or read audit data.

**Sam's choice: a simple login.**
- Username: command
- Password: Nova
- Single user (Sam only), for the build phase. This is a placeholder bolt on Sam's own test page while he builds — not a multi-user system. When anyone other than Sam ever uses Command Desk, this gets replaced with real per-user accounts; flag that to Sam before that day, don't carry this password into a shared system.

**The four ways this login must NOT be built (or it's a fake lock):**
1. **Checked on the server, never in the browser.** The password must NOT live in any front-end file, JS, or HTML — view-source would reveal it. The browser sends the attempt; the backend decides.
2. **The gate is on the BACKEND actions, not just the page.** Hiding the front end is not enough. Every Gmail operation in the permission layer must require the authenticated session. If the Gmail endpoint can be hit directly without a valid login session, the lock is a front door with the back window open.
3. **Login and the whole session run over HTTPS only.** Never accept the password over plain http.
4. **The login session IS the session identity the state machine uses.** One session_id: the thing that proves "this is Sam" and the thing the state machine / action gate bind to are the same session. No second parallel notion of session.

Obscurity is not authentication. A hard-to-find URL is not a lock. The login above is the lock.

**When the login gets built, and how much it covers:**
- **Home stage:** the login is built and proven as the LAST step of Stage 1, before any Gmail work. Stage 1 is not "done" until Sam can log in AND a logged-out visitor is refused. This gives the rule "no Stage 3 without a login" something real to point at.
- **It covers the whole page, not just Gmail.** Logged out, you see only the login — no Nova, no mic, no panel, no endpoints answering. One gate in front of everything is simpler and leaves no gap to slip through.
- **Slow down guessing:** limit login attempts (e.g. lock further tries for a short window after 5 failures) and log failed attempts. A public username/password with unlimited guesses can be scripted; a small lockout kills that.

This is an absolute failure condition: any Gmail capability exposed on a session that is not proven to be Sam's.

---

## STAGE 0 — Lights on (report only, build nothing)
- **FIRST: clear the stale stuck context on builder and tester (the 30 July refusal), then confirm the backend runs and all six agents + oversight answer a FRESH question -- not a two-day-old one.** Do not treat an agent as healthy until it answers today's question.
- Note for Sam: the stuck message was an external "scheme to make money without Sam" request the agents correctly refused; the login gate built in Stage 1 is what stops anything reaching the agents unauthenticated again. Flag anything else in context that isn't Sam's.
- Trace the voice pipeline's four links (mic capture -> speech-to-text -> reply -> text-to-speech) and report which are alive and which are dead. **If you find the dead link, do NOT fix it here. Name it and stop.** Stage 0 builds nothing.
- Confirm WHERE .env and the Anthropic key live -- the file path and that a key is present. **Report the location only, never the key's value.** Same for every secret, at every stage.
**Done:** a plain report — agent health, the exact dead voice link(s), where keys live.

## STAGE 1 — The interface Sam can talk to
- Replace the front end: Nova as the ORIGINAL STILL IMAGE as background (NO video, NO loop -- the video is dropped entirely), no tiles, plus a mic control and one empty result panel.
- **Do NOT generate, wait on, or substitute any .mp4. Use the original Nova still image.** If that image is not on the box, that is your one allowed interruption: say so in one line and wait. Do not proceed with a placeholder.
- **Two checkpoints, in order:** (a) new front end loads with the still image on the live site -- Sam confirms he sees it -- THEN (b) voice. Don't chase voice on a page that isn't up yet.
- Face runs on Ollama. **MIC IS PARKED for now** -- the dead link is speech-to-text, and the browser speech engine it used does not exist in iPhone Safari, so it can never work in the phone browser as built. Do NOT rebuild it now. Sam types to Nova for this phase; the real voice fix (phone records audio -> box runs speech-to-text e.g. Whisper -> words to Nova) comes later when it is wrapped as a phone app. Nova still speaks replies OUT.
- State machine live in SQLite: idle -> listening -> processing -> idle.
- **LAST step of this stage: build and prove the identity gate (login) from the SECURITY section above.** Stage 1 is not done until Sam can log in on the live page AND a logged-out visitor is refused everything.
**Done:** Sam types on the live site, hears Nova reply, and the login gate works. Log shows the states. Mic parked. No mail yet.

## STAGE 2 — Install the Gmail key
- Install the credential: client ID + secret into .env at 600 perms, same as the Anthropic key. Never in plain chat.
- Generate the one-time consent URL. **[SAM] hand him that single link — the allow tap is the one thing only he can do.** Capture the token on the box.
**Done:** the box holds Sam's authorised Gmail token. Nothing drafted or sent.

## STAGE 3 — Permission layer + router + a READ, shown
- Build the permission layer (new module) holding a Gmail READ tool. The personal_assistant worker requests reads through it -- it does not contain the tool.
- **Extending personal_assistant is additive:** ADD a path for it to request an action through the permission layer. Do NOT rewrite its existing logic. This is the one existing agent you touch, and only by adding.
- Build the router as its own piece: text in -> named worker + confidence out, logged every time. **No magic threshold to memorise: if it is not clearly one worker, treat it as low and ask Sam.** When in doubt, ask -- never guess.
- Wire the Sonnet wake to Sam's SPOKEN word (e.g. "go deep on this"): quick stuff stays on Ollama; only Sam's word wakes Sonnet, and it sleeps when he's done. The face never auto-decides.
- Sam says "what's come in?" -> router names personal_assistant -> worker requests a read via the permission layer -> result shows in the panel AND Nova says it.
**Build order inside this stage:** permission layer + READ first (prove acting works on a zero-risk read), THEN the router (prove picking works), THEN the Sonnet wake. One at a time, prove each.
**Done:** Sam speaks, real email content comes back on screen and spoken. Reading only -- nothing changed or sent.

## STAGE 4 — Draft, then send behind the yes
- Add DRAFT to the permission layer. Sam says "draft a reply saying Y" -> worker requests a draft -> Gmail draft created. State reaches draft_ready -> awaiting_confirmation and STOPS. Draft shows in the panel; Nova asks "send it?"
- Add SEND to the permission layer, behind the locked gate. The gate opens ONLY when ALL of these are true: state is awaiting_confirmation, AND the captured word is on a short explicit yes-list you show Sam first (e.g. "yes", "send it", "send that"), AND that yes is bound to THIS specific draft in THIS state.
- **Because voice transcription garbles words:** if the captured word is not a clear match on the list, do NOT send -- Nova re-asks. Never infer a yes. A "yes" that arrives in any other state, or for a different draft, does nothing.
- **No stale gates:** if Sam doesn't confirm, or says anything else, or time passes, the draft cancels back to idle. The gate is never left sitting open waiting for a stray yes.
- "Change it" -> back to processing, redraft.

**STAGE 4B — SEND EXISTING DRAFT: mark in-flight before calling Gmail, reconcile after (exactly-once send).**
Idempotency by action_id stops a repeated yes. This handles the harder case: Gmail sends but the network reply is lost. Order of operations for send, exactly:
1. Before calling Gmail, write the action as `in_flight` in SQLite (with action_id, draft_id, timestamp).
2. Call gmail.send_existing_draft.
3. On a clear success reply: mark `executed`, record the Gmail result, state -> completed.
4. On a lost or unclear reply (timeout, network error): do NOT resend. Leave the action `in_flight` and report: "Send status unconfirmed — verify in Gmail before any retry." Only Sam confirming the mail did NOT arrive may clear it for a fresh action_id.
5. Any send request that finds an existing `in_flight` or `executed` record for that action_id or draft_id is refused.

A lost network reply must never become a second email in the recipient's inbox.

*Abandoned drafts (no action needed): each "change it" makes a fresh Gmail draft with a new action_id; superseded drafts stay in the drafts folder. Harmless — send is bound to the exact confirmed draft_id, so an old draft can never be sent by mistake. Expect a few; they cannot misfire.*

**Done:** Sam speaks the ask, sees the draft, says a listed yes, it sends. Log shows the exact word that opened the gate and the draft it was bound to.

## STAGE 5 — Clone
- Second worker (calendar, coding, next) = a copy of the same pattern: same router, same permission-layer shape, same gate, same log. Swap the service + instruction.
**Done:** a second worker runs the same way.

---

## THE STATE MACHINE — timeouts on every waiting state
`awaiting_confirmation` expires at 120 seconds. The same rule applies to every state that waits on something external:
- `tool_requested` / `reading` / `executing` / `drafting` — each gets a fixed timeout in configuration (recommended start: 30 seconds for reads, 30 seconds for sends).
- On timeout: state moves to `error`, the action is marked failed, the session returns to `idle`, and the timeout is logged.
- A result that arrives after its timeout is discarded, never applied to a session that has moved on.

A hung Gmail call must never leave the session frozen. If a state can wait, it can time out.

---

## SAM ONLY TOUCHES TWO THINGS
1. **Stage 2:** one allow-tap on the Gmail consent link.
2. **Every stage's "done":** open the live site on his phone and confirm it actually works — you can't see his phone, he's the final eyes.
Everything else is yours. Report at the end of each stage with proof. Start with Stage 0.

## Why this can't get lost
Stage 0 shows what's real so nothing's built blind. Stage 1 stands up the interface (still image, typed input), then locks the door. Stage 2 is just the key. Stage 3 proves routing + acting with a zero-risk READ. Stage 4 adds the only dangerous part behind a rigid gate. Stage 5 repeats a proven thing. You never build two unknowns at once, never touch the running agents blind, never send without a caught yes, never claim a result you couldn't see.
