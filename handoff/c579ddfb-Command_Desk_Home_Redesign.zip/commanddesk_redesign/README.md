# Command Desk — Home Screen Redesign

Built from the supplied live frontend files and kept compatible with the production backend.

## Implemented

- No bottom dock.
- Home is Nova plus one tile grid and the bottom chat input.
- Initial grid is four blank agent tiles plus the add tile in position five.
- Additional agent tiles appear on the next row while the add tile remains fifth.
- Tiles carry valid production agent IDs internally but display no names on Home.
- Per-tile working indicator.
- No explicit Hub tile; Home chat routes to the `hub` backend agent.
- Full-page agent rooms with Back returning Home.
- Compact room switcher beside the appearance control, without a blocking modal.
- Appearance selector repaired.
- Visual curated app picker; no typed app names and no blocking modal.
- Nova frame engine retained with safe fallback when blink/mouth frames are absent.
- Browser speech synthesis wired for voice output.
- Production chat payload preserved: `{avatar, theme, agent, message, session_id}`.
- Returned `session_id` is persisted per room and for Home.
- No backend files or processes are included or modified.

## Mobile validation

Headless Chromium was run at exactly 375 × 812:

- Document width: 375
- Horizontal overflow: 0
- Initial tiles: 5 in one row
- Tile right edge: 366.98 px
- Appearance control visible
- Home input bottom edge: 802 px
- Room input visible
- No room-switch dialog/modal open
- JavaScript page errors: 0

Physical-device validation still requires deploying the package to the real site and opening it on Sam's phone.
