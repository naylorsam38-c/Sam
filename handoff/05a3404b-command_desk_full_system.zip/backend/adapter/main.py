
import json
import urllib.request
from typing import List, Literal, Optional

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Command Desk Backend Adapter")

HUB_URL = "http://127.0.0.1:8765/api/chat"
SLOTS_CONFIG_PATH = "/home/ubuntu/commanddesk/core/slots_config.json"


class Agent(BaseModel):
    id: str
    icon: str


class ChatRequest(BaseModel):
    avatar: Literal["nova", "halo", "gaia"]
    theme: Literal["gunmetal", "volcano", "platinum"]
    agent: str
    message: str
    # Per-room session id, round-tripped from a prior reply's session_id.
    # None on a room's first message -- the Hub opens a fresh session itself
    # in that case and hands its id back for the frontend to persist and
    # reuse, which is what lets oversight (and continuity generally) see one
    # coherent session per room instead of a new one every single turn.
    session_id: Optional[str] = None


class ChatResponse(BaseModel):
    reply: str
    session_id: str


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/agents", response_model=List[Agent])
def agents():
    with open(SLOTS_CONFIG_PATH, "r", encoding="utf-8") as f:
        config = json.load(f)
    return [Agent(id=slot["id"], icon=slot["id"]) for slot in config["slots"]]


@app.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    body = json.dumps({
        "text": payload.message,
        "slot": payload.agent,
        "session_id": payload.session_id,
    }).encode("utf-8")
    req = urllib.request.Request(
        HUB_URL, data=body, headers={"Content-Type": "application/json"}, method="POST"
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return ChatResponse(reply=data.get("reply", ""), session_id=data.get("session_id", ""))
