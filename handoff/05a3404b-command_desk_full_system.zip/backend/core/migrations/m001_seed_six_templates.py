"""Migrate the six fixed slots (Hub, Research, Builder, Tester, Personal
Assistant, Consolidator) into agent_templates rows.

Purely additive: slots_config.json remains the source of truth for how the
six behave at runtime (orchestrator.py routes against it exactly as before,
unchanged). This migration only gives each of them a matching row in
agent_templates, verbatim -- content and behavior are untouched, this just
also files them into the same catalog spawned instances live in.

Idempotent: safe to run more than once. Matches existing templates by name
before inserting, so re-running never creates duplicates.
"""
from __future__ import annotations
from pathlib import Path
from ..db import init_db, connect
from ..agents import create_template, list_templates
from ..orchestrator import load_slots_config


def run(con=None):
    con = con or init_db(connect())
    cfg = load_slots_config()
    slot_ids = cfg['_order']
    existing_names = {t['name'] for t in list_templates(con)}

    created = []
    skipped = []
    for sid in slot_ids:
        slot = cfg[sid]
        name = slot['name']
        if name in existing_names:
            skipped.append(name)
            continue
        prompt_rel = slot.get('system_prompt_file')
        if not prompt_rel:
            raise ValueError(f'Slot {sid} has no system_prompt_file to migrate from')
        prompt_text = Path(__file__).resolve().parents[1].joinpath(prompt_rel).read_text(encoding='utf-8')
        tid = create_template(
            con,
            name=name,
            system_prompt=prompt_text,
            model=slot.get('model'),
            tools=slot.get('tools', []),
            accent_color=slot.get('accent_color', '#888888'),
        )
        created.append((name, tid))
    return {'created': created, 'skipped': skipped}


if __name__ == '__main__':
    result = run()
    print('Created:', result['created'])
    print('Already present, skipped:', result['skipped'])
