from __future__ import annotations
import json, re
from .llm_router import run as _llm_run, get_claude_cheap_model
from .audit_log import log as audit
from . import orchestrator

# ── Router -- its own separate piece ──────────────────────────────────────
# Not inside Nova, not inside any worker. Takes one message, returns which
# worker should handle it and how confident that call is.
#
# Deliberately model-judged, not a numeric cutoff: the model is instructed
# to say "worker: null" when it's genuinely unclear which of two or more
# SPECIFIC workers a request belongs to, rather than this code picking
# "whichever score is highest" against some threshold. nova_voice is one of
# the choices, representing plain conversation with Nova that isn't a
# request for any other worker -- so ordinary chat still resolves cleanly
# and confidently; "ambiguous" is reserved for genuine either-this-or-that
# cases between two real workers.
#
# Pinned to Claude's cheap tier (haiku), not Ollama: tried llama3.2 first
# and it confidently misrouted a plain "what's come in" to Builder with a
# fabricated justification -- exactly the guessing this router exists to
# refuse to do. A tiny real cost per routing call buys instruction-following
# reliable enough that "never guess" is actually true, not just asserted.

ROUTER_PROVIDER = 'claude'

# consolidator is the internal vault agent -- Sam never talks to it
# directly, so it is never a routing target.
_EXCLUDED_FROM_MENU = {'consolidator'}

# Purpose-written for routing decisions specifically -- each slot's own
# prompt.txt first line is written to set that agent's own tone/behavior
# once it's already been chosen, not to help a router TELL slots apart, and
# reusing it verbatim caused a real misroute: "what's come in" went to hub
# because hub's own opening line ("deliver Continuity first...") reads as a
# semantic match for "what's come in" just as much as personal_assistant's
# actual job (checking email) does. These descriptions exist to disambiguate
# on purpose. Any slot not listed here (a new one added later) falls back to
# its prompt.txt first line, same as before.
_ROUTER_DESCRIPTIONS = {
    'hub': ("Sam's default general panel -- catching up on continuity of what Sam and "
            "Command Desk itself were just discussing/doing. NOT email, NOT external "
            "messages -- that is personal_assistant."),
    'research': 'Digging into a topic and producing findings with citations.',
    'builder': 'Designing and shipping code: architecture, implementation, debugging, deployment.',
    'tester': 'Verifying what Builder ships: writing/running tests, reporting bugs.',
    'personal_assistant': ("Sam's day-to-day: checking email/inbox (what has come in, any new mail), "
                            "plans, schedules, reminders, follow-ups."),
    'nova_voice': ('general conversation with Nova -- small talk, thinking out loud, anything '
                   'that is not a specific request for one of the other workers below'),
}


def _worker_menu() -> str:
    """Built fresh every call from slots_config.json (so an added/removed
    slot is picked up with no code change here) plus a purpose-written
    routing description per slot -- falling back to that slot's own
    prompt.txt first line only for a slot this dict doesn't yet know about."""
    lines = []
    for sid in orchestrator.SLOTS:
        if sid in _EXCLUDED_FROM_MENU:
            continue
        cfg = orchestrator.SLOT_CONFIG.get(sid, {})
        desc = _ROUTER_DESCRIPTIONS.get(sid)
        if desc is None:
            prompt = orchestrator.load_prompt(sid)
            desc = prompt.strip().split('\n', 1)[0][:160]
        lines.append(f"- {sid} ({cfg.get('name', sid)}): {desc}")
    return '\n'.join(lines)


_ROUTE_SYSTEM_PROMPT_TEMPLATE = (
    "You are Command Desk's router. Given one message from Sam, decide which ONE "
    "worker below should handle it, and how confident you are (0-100).\n\n"
    "Workers:\n{menu}\n\n"
    "If the message is clearly general conversation (not a specific task for one "
    "of the non-nova_voice workers), choose nova_voice with high confidence.\n"
    "If the message clearly needs a specific worker's help, choose that worker.\n"
    "If it genuinely could belong to two or more of the non-nova_voice workers and "
    "you cannot tell which, set worker to null and confidence to 0 -- do not guess.\n\n"
    "Reply with EXACTLY one JSON object and nothing else, in this shape:\n"
    '{{"worker": "<worker_id or null>", "confidence": <0-100 integer>, "reason": "<one short sentence>"}}'
)


def _parse_route_reply(text: str) -> dict:
    """Returns {worker, confidence, reason, parsed} -- parsed=False means the
    model's reply itself couldn't be understood (a system-level router
    failure, e.g. Ollama unreachable), which callers should treat as a
    fallback-to-Nova case, distinct from the model genuinely reporting
    worker=null (real semantic ambiguity between two specific workers)."""
    match = re.search(r'\{.*\}', text, re.S)
    if not match:
        return {'worker': None, 'confidence': 0, 'reason': 'router reply was not parseable', 'parsed': False}
    try:
        data = json.loads(match.group(0))
    except json.JSONDecodeError:
        return {'worker': None, 'confidence': 0, 'reason': 'router reply was not valid JSON', 'parsed': False}

    worker = data.get('worker')
    if worker not in orchestrator.SLOT_CONFIG or worker in _EXCLUDED_FROM_MENU:
        worker = None
    try:
        confidence = int(data.get('confidence', 0))
    except (TypeError, ValueError):
        confidence = 0
    confidence = max(0, min(100, confidence))
    if worker is None:
        confidence = 0
    return {'worker': worker, 'confidence': confidence, 'reason': str(data.get('reason', ''))[:300], 'parsed': True}


def route(con, text: str) -> dict:
    """text in -> named worker + confidence out. Every call logs its
    decision to audit_log, whether it's a clean route, a genuine ambiguous
    refusal-to-guess, or a system-level parse failure."""
    menu = _worker_menu()
    system_prompt = _ROUTE_SYSTEM_PROMPT_TEMPLATE.format(menu=menu)
    raw = _llm_run('router', system_prompt, [{'role': 'user', 'content': text}],
                   model=get_claude_cheap_model(), provider=ROUTER_PROVIDER)
    reply_text = raw.get('content', '') if isinstance(raw, dict) else str(raw)
    decision = _parse_route_reply(reply_text)

    if not decision['parsed']:
        audit(con, 'router', 'route', text, 'error',
              json.dumps({'raw_reply': reply_text[:500], 'reason': decision['reason']}))
        return {'worker': None, 'confidence': 0, 'status': 'error', 'reason': decision['reason']}

    if decision['worker'] is None:
        audit(con, 'router', 'route', text, 'ambiguous',
              json.dumps({'raw_reply': reply_text[:500], 'reason': decision['reason']}))
        return {
            'worker': None, 'confidence': decision['confidence'], 'status': 'ambiguous',
            'reason': decision['reason'],
            'ask': "I'm not sure which of your agents should take that one -- who do you want on it?",
        }

    audit(con, 'router', 'route', text, 'routed',
          json.dumps({'worker': decision['worker'], 'confidence': decision['confidence'],
                      'reason': decision['reason'], 'raw_reply': reply_text[:500]}))
    return {'worker': decision['worker'], 'confidence': decision['confidence'], 'status': 'routed',
            'reason': decision['reason']}
