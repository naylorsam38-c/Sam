from __future__ import annotations
import uuid
from .db import now


def create_group(con, name, member_ids):
    gid = uuid.uuid4().hex
    members = list(dict.fromkeys(member_ids))  # de-dup while preserving the order they were given in
    started_by = members[0] if members else None
    con.execute(
        'INSERT INTO conversation_groups (id,name,created_at,status,started_by,summary,closed_at) VALUES (?,?,?,?,?,?,?)',
        (gid, name.strip(), now(), 'active', started_by, None, None)
    )
    for mid in members:
        con.execute('INSERT OR IGNORE INTO conversation_group_members VALUES (?,?,?)', (gid, mid, now()))
    con.commit(); return gid


def close_group(con, group_id, summary):
    con.execute('UPDATE conversation_groups SET status=?, summary=?, closed_at=? WHERE id=?',
                ('closed', summary, now(), group_id))
    con.commit()


def list_groups(con):
    return [dict(r) for r in con.execute('SELECT * FROM conversation_groups ORDER BY created_at DESC').fetchall()]


def get_group(con, group_id):
    r = con.execute('SELECT * FROM conversation_groups WHERE id=?', (group_id,)).fetchone()
    return dict(r) if r else None


def group_members(con, group_id) -> list[str]:
    rows = con.execute('SELECT member_id FROM conversation_group_members WHERE group_id=? ORDER BY added_at', (group_id,)).fetchall()
    return [r['member_id'] for r in rows]


def write_group_turn(con, group_id, member_id, content):
    # A dedicated table, not the shared per-slot `transcript` table -- reusing
    # that one filtered by slot would leak each member's private 1:1 chats
    # into any group they belong to. Separate storage makes the isolation
    # guarantee hold by construction rather than by filtering discipline.
    con.execute('INSERT INTO conversation_group_messages(group_id,member_id,content,ts) VALUES (?,?,?,?)', (group_id, member_id, content, now()))
    con.commit()


def get_group_transcript(con, group_id, limit=200):
    rows = con.execute('SELECT * FROM conversation_group_messages WHERE group_id=? ORDER BY id ASC LIMIT ?', (group_id, limit)).fetchall()
    return [dict(r) for r in rows]


def next_round_robin_member(con, group_id, members):
    """Pick whoever goes after the last member that actually spoke (i.e. the
    last non-'user' turn). Wraps around; starts at the first member if no
    agent has spoken in this group yet."""
    rows = con.execute(
        "SELECT member_id FROM conversation_group_messages WHERE group_id=? AND member_id!='user' ORDER BY id DESC LIMIT 1",
        (group_id,)
    ).fetchall()
    if not rows or rows[0]['member_id'] not in members:
        return members[0]
    idx = members.index(rows[0]['member_id'])
    return members[(idx + 1) % len(members)]
