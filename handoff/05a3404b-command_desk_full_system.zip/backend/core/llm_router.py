from __future__ import annotations
import os
from .dotenv_loader import load_dotenv

load_dotenv()  # populates os.environ from .env if present, without overriding real env vars

DEFAULT_MODEL = 'claude-sonnet-5'
DEFAULT_OLLAMA_MODEL = 'llama3.2'
DEFAULT_OLLAMA_HOST = 'http://127.0.0.1:11434'
DEFAULT_CLAUDE_CHEAP_MODEL = 'claude-haiku-4-5-20251001'
DEFAULT_CLAUDE_SHARP_MODEL = 'claude-sonnet-5'


def get_provider():
    # The one-line swap: LLM_PROVIDER=claude (default, unset) or LLM_PROVIDER=ollama.
    load_dotenv()
    return (os.getenv('LLM_PROVIDER') or 'claude').strip().lower()


def get_claude_key():
    # Read at call time (not import time) so a key added to .env after startup
    # is still picked up on the next request.
    load_dotenv()
    return os.getenv('ANTHROPIC_API_KEY')


def get_model():
    return os.getenv('CLAUDE_MODEL') or os.getenv('AIRE_CLAUDE_MODEL') or DEFAULT_MODEL


def get_ollama_host():
    return os.getenv('OLLAMA_HOST') or DEFAULT_OLLAMA_HOST


def get_ollama_model():
    return os.getenv('OLLAMA_MODEL') or DEFAULT_OLLAMA_MODEL


def get_claude_cheap_model():
    # Used by oversight/router_contract.py's "cheap" tier (Clerk, Checker's
    # field extraction) -- a distinct, independently-overridable default
    # from the general/"sharp" Claude model below.
    return os.getenv('CLAUDE_CHEAP_MODEL') or DEFAULT_CLAUDE_CHEAP_MODEL


def get_claude_sharp_model():
    # Used by oversight/router_contract.py's "sharp" tier (Angel's judgement).
    return os.getenv('CLAUDE_SHARP_MODEL') or DEFAULT_CLAUDE_SHARP_MODEL


def run(slot, system_prompt, messages, tools=None, model=None, provider=None):
    """Dispatch to whichever provider this call resolves to. Never silently
    falls back: if a key/model/connection is missing, the returned content
    says so explicitly so the failure is visible in the UI.

    model overrides the global Claude default, or picks the Ollama model
    when provider='ollama' -- used by slots_config.json's per-slot 'model'
    field, or by spawned agent instances whose template pins a model.

    provider, if given, overrides the global LLM_PROVIDER for THIS call
    only -- this is what lets a single slot (e.g. Consolidator on Ollama)
    mix providers alongside mostly-Claude slots without touching the
    global default. None preserves the old all-or-nothing global behavior
    exactly as before (every slot on whatever LLM_PROVIDER is set to)."""
    active_provider = (provider or get_provider()).strip().lower()
    if active_provider == 'ollama':
        return _run_ollama(system_prompt, messages, model)
    return _run_claude(system_prompt, messages, tools, model)


def _run_claude(system_prompt, messages, tools, model):
    key = get_claude_key()
    if not key:
        return {'content': '[Command Desk error] No ANTHROPIC_API_KEY found in .env — cannot reach Claude. Add the key to .env and retry.',
                'source': 'error'}
    try:
        import anthropic
    except ImportError:
        return {'content': "[Command Desk error] The 'anthropic' package is not installed. Run: pip install anthropic",
                'source': 'error'}
    try:
        client = anthropic.Anthropic(api_key=key)
        kwargs = dict(model=model or get_model(), max_tokens=4096, system=system_prompt, messages=messages)
        if tools:
            kwargs['tools'] = tools
        msg = client.messages.create(**kwargs)
        text = ''.join(b.text for b in msg.content if getattr(b, 'type', '') == 'text').strip()
        return {'content': text or '[Command Desk error] Claude returned an empty response.', 'source': 'claude'}
    except Exception as e:
        return {'content': f'[Command Desk error] Claude API call failed ({type(e).__name__}): {e}', 'source': 'error'}


def _run_ollama(system_prompt, messages, model=None):
    try:
        import requests
    except ImportError:
        return {'content': "[Command Desk error] The 'requests' package is not installed. Run: pip install requests",
                'source': 'error'}
    host = get_ollama_host()
    resolved_model = model or get_ollama_model()
    try:
        resp = requests.post(
            f'{host}/api/chat',
            json={
                'model': resolved_model,
                'messages': [{'role': 'system', 'content': system_prompt}, *messages],
                'stream': False,
            },
            timeout=120,
        )
        resp.raise_for_status()
        data = resp.json()
        text = (data.get('message') or {}).get('content', '').strip()
        return {'content': text or '[Command Desk error] Ollama returned an empty response.', 'source': 'ollama'}
    except requests.exceptions.ConnectionError:
        return {'content': f"[Command Desk error] Could not reach Ollama at {host} — is it running? Start it with 'ollama serve' or the Ollama app.",
                'source': 'error'}
    except Exception as e:
        return {'content': f'[Command Desk error] Ollama call failed ({type(e).__name__}): {e}', 'source': 'error'}
