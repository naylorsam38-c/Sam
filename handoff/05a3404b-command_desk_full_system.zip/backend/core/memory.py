from __future__ import annotations
import json, uuid, re
from .db import now

def memory_add(con, text: str, meta: dict | None = None):
    mid = uuid.uuid4().hex
    con.execute('INSERT INTO memories VALUES (?,?,?,?)', (mid, text.strip(), json.dumps(meta or {}), now()))
    con.commit(); return mid

def recall(con, query: str, limit: int = 5, allowed_slots: set[str] | None = None):
    """allowed_slots restricts results to memories captured from those slot ids.
    A memory with no slot tag in its meta is treated as shared/legacy and is
    visible everywhere (kept for backward compatibility with pre-refactor rows).
    Pass allowed_slots=None to disable filtering entirely."""
    words = {w.lower() for w in re.findall(r'[a-zA-Z0-9_]+', query) if len(w)>2}
    rows = con.execute('SELECT * FROM memories ORDER BY created_at DESC').fetchall()
    ranked=[]
    for r in rows:
        if allowed_slots is not None:
            meta = json.loads(r['meta'] or '{}')
            row_slot = meta.get('slot')
            if row_slot is not None and row_slot not in allowed_slots:
                continue
        txt = r['text']; score=sum(1 for w in words if w in txt.lower())
        if score or not words: ranked.append((score, dict(r)))
    return [r for _,r in sorted(ranked, key=lambda x:x[0], reverse=True)[:limit]]

def log_decision(con, topic, decision, rationale, alternatives=None, slot='command'):
    did = uuid.uuid4().hex
    con.execute('INSERT INTO decisions VALUES (?,?,?,?,?,?,?,?)',
        (did, topic.strip(), decision.strip(), rationale.strip(), json.dumps(alternatives or []), now(), slot, 'active'))
    con.commit(); return did

def related_decisions(con, topic: str, limit: int=5, allowed_slots: set[str] | None = None):
    term = f'%{topic.strip()}%'
    if allowed_slots is not None:
        placeholders = ','.join('?' * len(allowed_slots))
        q = (f'SELECT * FROM decisions WHERE status="active" AND slot IN ({placeholders}) '
             'AND (topic LIKE ? OR decision LIKE ? OR rationale LIKE ?) ORDER BY decided_at DESC LIMIT ?')
        params = (*allowed_slots, term, term, term, limit)
    else:
        q = ('SELECT * FROM decisions WHERE status="active" AND (topic LIKE ? OR decision LIKE ? OR rationale LIKE ?) '
             'ORDER BY decided_at DESC LIMIT ?')
        params = (term, term, term, limit)
    return [dict(r) for r in con.execute(q, params).fetchall()]
