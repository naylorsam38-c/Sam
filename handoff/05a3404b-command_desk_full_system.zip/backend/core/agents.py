from __future__ import annotations
import json, uuid
from .db import now


def create_template(con, name, system_prompt, model=None, tools=None, accent_color='#888888'):
    tid = uuid.uuid4().hex
    con.execute('INSERT INTO agent_templates VALUES (?,?,?,?,?,?,?)',
        (tid, name.strip(), system_prompt.strip(), model or '', json.dumps(tools or []), accent_color, now()))
    con.commit(); return tid


def list_templates(con):
    return [dict(r) for r in con.execute('SELECT * FROM agent_templates ORDER BY created_at DESC').fetchall()]


def get_template(con, template_id):
    r = con.execute('SELECT * FROM agent_templates WHERE id=?', (template_id,)).fetchone()
    return dict(r) if r else None


def spawn_instance(con, template_id, name=None):
    tpl = get_template(con, template_id)
    if not tpl:
        raise ValueError(f'Unknown template: {template_id}')
    iid = uuid.uuid4().hex
    inst_name = name or f"{tpl['name']} #{iid[:6]}"
    con.execute('INSERT INTO agent_instances VALUES (?,?,?,?,?,?)',
        (iid, template_id, inst_name, 'active', now(), None))
    con.commit(); return iid


def list_instances(con, status=None):
    if status:
        rows = con.execute('SELECT * FROM agent_instances WHERE status=? ORDER BY created_at DESC', (status,)).fetchall()
    else:
        rows = con.execute('SELECT * FROM agent_instances ORDER BY created_at DESC').fetchall()
    return [dict(r) for r in rows]


def get_instance(con, instance_id):
    r = con.execute('SELECT * FROM agent_instances WHERE id=?', (instance_id,)).fetchone()
    return dict(r) if r else None


def stop_instance(con, instance_id):
    con.execute('UPDATE agent_instances SET status=?, stopped_at=? WHERE id=?', ('stopped', now(), instance_id))
    con.commit()


def delete_instance(con, instance_id):
    con.execute('DELETE FROM agent_instances WHERE id=?', (instance_id,))
    con.commit()


def is_active_instance(con, slot_id) -> bool:
    inst = get_instance(con, slot_id)
    return bool(inst and inst['status'] == 'active')


def instance_slot_cfg(con, instance_id):
    """Build an orchestrator-compatible slot config dict for a live instance,
    so a spawned instance can be routed to exactly like a static slot from
    slots_config.json. Returns None if the instance is missing/stopped or its
    template was deleted out from under it.

    Instances default to a fully isolated, solo memory pool (isolated_group =
    their own id) -- each spawned agent starts private by default. Part 2's
    conversation groups are the explicit mechanism for controlled sharing
    between agents, so instances deliberately don't join the shared 'hub'
    contextual pool on their own."""
    inst = get_instance(con, instance_id)
    if not inst or inst['status'] != 'active':
        return None
    tpl = get_template(con, inst['template_id'])
    if not tpl:
        return None
    return {
        'id': instance_id,
        'name': inst['name'],
        'accent_color': tpl['accent_color'],
        'brain': 'claude',
        'model': tpl['model'] or None,
        'contextual': False,
        'isolated': True,
        'isolated_group': instance_id,
        'tools': json.loads(tpl['tools'] or '[]'),
        'keywords': [],
        'system_prompt': tpl['system_prompt'],
        'memory': 'isolated',
        'template_id': inst['template_id'],
    }
