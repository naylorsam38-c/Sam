from __future__ import annotations
import re, uuid, json
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from .db import now, connect, normalize_quotes
from .auth import validate_session
from .audit_log import log as audit
from .voice_state import (transition as voice_transition, get_pending_draft, set_pending_draft,
                           clear_pending_draft)
from .style_profile import get_style_profile
from .llm_router import run as _llm_run

# ── Permission layer ──────────────────────────────────────────────────────
# The tool lives HERE, never inside a worker. personal_assistant (or any
# other slot) can only reach Gmail by calling the request_* functions below
# -- there is no other path in this codebase that touches the Gmail API.
# Stage 3 added read-only. Stage 4 adds draft + send, both still gated
# entirely through this module: a worker REQUESTS, this layer holds the
# tool and the gate.

READ_TIMEOUT_SECONDS = 30
DRAFT_TIMEOUT_SECONDS = 30
SEND_TIMEOUT_SECONDS = 30
CONFIRMATION_TIMEOUT_SECONDS = 120

BASE_DIR = Path(__file__).resolve().parents[1]
TOKEN_PATH = BASE_DIR / 'google_token.json'

# Broadened from the original phrase list (which missed real phrasing like
# "is there a rob in my junk mail", "what emails have I got", "have a look
# at what he emailed") after live verification showed the router correctly
# sent these to personal_assistant every time, but this regex never fired,
# so the model answered from general knowledge -- "I don't have access to
# your email" -- with the tool sitting right there. Noun-based on purpose:
# catches the SUBJECT (email/inbox/gmail/junk mail/spam) regardless of how
# the verb is phrased, rather than trying to enumerate every way of asking.
# Deliberately generous -- an occasional unnecessary read (e.g. "remind me
# to email my accountant tomorrow") is the accepted trade-off, since reads
# are cheap/safe/idempotent (proven in Stage 3) and the cost of the OTHER
# direction (Sam thinks the tool is broken) is much worse.
#
# Extended a second time after live testing caught two more real misses in
# the SAME session: bare "junk" ("anything from Rob in my junk" -- Sam
# said "junk", not "junk mail") and "come in" as its own signal ("anything
# new come in" has no email-noun at all, only the original narrow "what's
# come in" phrase covered this idea). Same broad-net trade-off as above,
# applied consistently rather than patching phrase-by-phrase forever.
MAIL_TRIGGER = re.compile(
    r"\b(inbox|gmail|junk|spam|come in|e-?mail\w*)\b",
    re.I,
)

# Stage 4: asking personal_assistant to prepare an email. Deliberately
# narrower than MAIL_TRIGGER (which is about READING) -- these phrasings
# are specifically about composing something new.
DRAFT_TRIGGER = re.compile(
    r"\b(draft (?:an?|the) (?:email|reply|message)|write (?:an?|the) (?:email|reply|message) to|"
    r"compose (?:an?|the) email|reply to (?:that|the|this) email)\b",
    re.I,
)

# The locked send gate. A SHORT, EXPLICIT list, checked by exact normalized
# match only -- no fuzzy/partial matching. "yes but wait", "yeah maybe",
# "send it later" etc. do NOT match; that is deliberate, not a gap: a
# near-miss must re-ask, never send. Shown here in full, as asked.
YES_LIST = {
    'yes', 'yep', 'yeah', 'send it', 'send that', 'confirm', 'confirmed', 'go ahead', 'do it',
}
CHANGE_TRIGGER = re.compile(
    r"\b(change it|redo it|redo this|edit it|rewrite it|try again|different wording|"
    r"make it (?:more|less) \w+)\b",
    re.I,
)
# Explicit, Sam-only recovery phrase for an action stuck 'in_flight' after a
# lost/unclear send reply -- the ONLY other way an in_flight action ever
# gets cleared, and only ever by this, never by a timeout or a retry.
NOT_RECEIVED_TRIGGER = re.compile(
    r"\b(it didn'?t send|that didn'?t (?:go through|arrive|send)|"
    r"confirm(?:ing)? it (?:failed|didn'?t send))\b",
    re.I,
)

_executor = ThreadPoolExecutor(max_workers=4)


def _normalize_reply(text: str) -> str:
    return text.strip().lower().rstrip('.!,?')


def _is_yes(text: str) -> bool:
    return _normalize_reply(text) in YES_LIST


def _new_action(con, session_id, worker, tool, draft_id: str | None = None) -> str:
    action_id = uuid.uuid4().hex
    con.execute(
        'INSERT INTO actions (id, session_id, worker, tool, status, created_at, draft_id) VALUES (?,?,?,?,?,?,?)',
        (action_id, session_id, worker, tool, 'pending', now(), draft_id)
    )
    con.commit()
    return action_id


def _set_action_status(con, action_id, status, result_summary=''):
    con.execute(
        'UPDATE actions SET status=?, completed_at=?, result_summary=? WHERE id=?',
        (status, now(), result_summary[:500], action_id)
    )
    con.commit()


def _get_action_status(con, action_id):
    row = con.execute('SELECT status FROM actions WHERE id=?', (action_id,)).fetchone()
    return row['status'] if row else None


def _register_late_discard(action_id: str, future, tool_name: str, open_statuses=('failed',)):
    """A result that finishes after its timeout window is DISCARDED, never
    applied -- fires whenever the background thread actually completes
    (which the caller can no longer wait for once future.result() has
    raised TimeoutError). Only writes an audit row confirming the discard,
    and only if nothing has since resolved the action -- checked against
    open_statuses, since read/draft leave a timed-out action 'failed' but
    send deliberately leaves it 'in_flight' (never resent, never silently
    marked failed). If Sam has since explicitly cleared it
    (failed_confirmed_not_sent), that no longer matches open_statuses, so
    this never overwrites his explicit call with a late background result
    -- whatever that result actually says. Shared by read/draft/send --
    tool_name is just which one this was, for the log."""
    def _on_done(fut):
        con2 = connect()
        try:
            if _get_action_status(con2, action_id) in open_statuses:
                audit(con2, 'permission_layer', f'{tool_name}_late_result', f'action={action_id}',
                      'discarded', 'result arrived after the timeout window; discarded, never applied')
        finally:
            con2.close()
    future.add_done_callback(_on_done)


def _gmail_service():
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request as GoogleAuthRequest
    from googleapiclient.discovery import build

    creds = Credentials.from_authorized_user_file(str(TOKEN_PATH))
    if creds.expired and creds.refresh_token:
        creds.refresh(GoogleAuthRequest())
        TOKEN_PATH.write_text(creds.to_json(), encoding='utf-8')
    return build('gmail', 'v1', credentials=creds)


def _do_gmail_read(max_results=10) -> dict:
    """The actual Gmail call. Read-only: messages().list + a metadata-only
    get() per message (From/Subject/Date headers + snippet) -- never the
    full message body. Runs in a worker thread so the 30s timeout in
    request_gmail_read can actually be enforced from the caller's side."""
    service = _gmail_service()
    resp = service.users().messages().list(userId='me', maxResults=max_results, labelIds=['INBOX']).execute()
    messages = []
    for m in resp.get('messages', []):
        msg = service.users().messages().get(
            userId='me', id=m['id'], format='metadata',
            metadataHeaders=['From', 'Subject', 'Date']
        ).execute()
        headers = {h['name']: h['value'] for h in msg.get('payload', {}).get('headers', [])}
        messages.append({
            'id': m['id'],
            'from': headers.get('From', ''),
            'subject': headers.get('Subject', ''),
            'date': headers.get('Date', ''),
            'snippet': msg.get('snippet', ''),
        })
    return {'messages': messages}


def _do_gmail_draft(to: str, subject: str, body_text: str) -> dict:
    """Creates a REAL Gmail draft via drafts().create() -- requires
    gmail.compose on the token. Stage 3's token is readonly-only, so this
    fails with an auth-scope error until Sam completes the fresh consent
    grant; that is the named hard gate, not a bug in this function."""
    import base64
    from email.mime.text import MIMEText

    service = _gmail_service()
    message = MIMEText(body_text)
    message['to'] = to
    message['subject'] = subject
    raw = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')
    draft = service.users().drafts().create(userId='me', body={'message': {'raw': raw}}).execute()
    return {'gmail_draft_id': draft['id'], 'gmail_message_id': draft.get('message', {}).get('id')}


def _do_gmail_send(gmail_draft_id: str) -> dict:
    """Sends an EXISTING Gmail draft by id via drafts().send() -- never
    composes a fresh message at send time. What gets sent is exactly what
    was drafted and shown to Sam for confirmation; there is no path where
    the sent content can differ from the confirmed draft. Requires
    gmail.send on the token."""
    service = _gmail_service()
    result = service.users().drafts().send(userId='me', body={'id': gmail_draft_id}).execute()
    return {'gmail_message_id': result.get('id')}


def request_gmail_read(con, session_id: str | None, worker: str = 'personal_assistant', max_results: int = 10) -> dict:
    """The ONLY entry point any worker can use to read Gmail. Independently
    re-checks the session against auth_sessions regardless of what gate the
    calling route already applied -- this is the hard requirement: the
    permission layer itself refuses an unauthenticated caller, not just the
    page."""
    if not validate_session(con, session_id):
        audit(con, worker, 'permission_layer.gmail_read', f'session={session_id!r}', 'refused',
              'not authenticated -- refused before any tool_requested/reading transition or Gmail call')
        return {'allowed': False, 'error': 'Not authenticated -- Gmail read refused.'}

    action_id = _new_action(con, session_id, worker, 'gmail_read')
    audit(con, worker, 'permission_layer.gmail_read', f'session={session_id} action={action_id}', 'requested', '')
    voice_transition(con, session_id, 'tool_requested', trigger=f'{worker}:gmail_read', result=action_id)

    _set_action_status(con, action_id, 'running')
    voice_transition(con, session_id, 'reading', trigger=f'{worker}:gmail_read', result=action_id)

    future = _executor.submit(_do_gmail_read, max_results)
    try:
        result = future.result(timeout=READ_TIMEOUT_SECONDS)
    except FutureTimeoutError:
        _set_action_status(con, action_id, 'failed', 'timed out after 30s')
        voice_transition(con, session_id, 'error', trigger='timeout', result=f'action={action_id} timed out')
        voice_transition(con, session_id, 'idle', trigger='timeout_recovery', result=f'action={action_id}')
        audit(con, worker, 'permission_layer.gmail_read', f'action={action_id}', 'timeout',
              'no result within 30s; a late result will be discarded, never applied')
        _register_late_discard(action_id, future, 'gmail_read')
        return {'allowed': True, 'error': 'Gmail read timed out after 30 seconds.', 'action_id': action_id}
    except Exception as e:
        _set_action_status(con, action_id, 'failed', str(e)[:500])
        voice_transition(con, session_id, 'error', trigger='exception', result=str(e)[:120])
        voice_transition(con, session_id, 'idle', trigger='error_recovery', result=f'action={action_id}')
        audit(con, worker, 'permission_layer.gmail_read', f'action={action_id}', 'error', str(e)[:500])
        return {'allowed': True, 'error': f'Gmail read failed: {e}', 'action_id': action_id}

    _set_action_status(con, action_id, 'done', f"{len(result.get('messages', []))} messages")
    voice_transition(con, session_id, 'idle', trigger='read_complete', result=f'action={action_id}')
    audit(con, worker, 'permission_layer.gmail_read', f'action={action_id}', 'ok',
          f"{len(result.get('messages', []))} messages")
    return {'allowed': True, 'action_id': action_id, **result}


def _create_and_confirm_draft(con, session_id, worker, to, subject, body_text, do_draft=None) -> dict:
    """Shared by the initial draft request and a post-'change it' redraft:
    creates the action + drafts row, calls Gmail (or the injected stub in
    tests) with a real 30s timeout, and on success walks the state machine
    drafting -> draft_ready -> awaiting_confirmation, binding the new
    draft_id as this session's pending confirmation target."""
    do_draft = do_draft or _do_gmail_draft

    draft_id = uuid.uuid4().hex
    con.execute(
        'INSERT INTO drafts (id, session_id, worker, to_addr, subject, body_text, status, created_at, updated_at) '
        'VALUES (?,?,?,?,?,?,?,?,?)',
        (draft_id, session_id, worker, to, subject, body_text, 'pending', now(), now())
    )
    con.commit()

    action_id = _new_action(con, session_id, worker, 'gmail_draft', draft_id=draft_id)
    audit(con, worker, 'permission_layer.gmail_draft', f'session={session_id} action={action_id} draft={draft_id}',
          'requested', '')
    voice_transition(con, session_id, 'drafting', trigger=f'{worker}:gmail_draft', result=draft_id)
    _set_action_status(con, action_id, 'running')

    future = _executor.submit(do_draft, to, subject, body_text)
    try:
        result = future.result(timeout=DRAFT_TIMEOUT_SECONDS)
    except FutureTimeoutError:
        _set_action_status(con, action_id, 'failed', 'timed out after 30s')
        con.execute("UPDATE drafts SET status='failed', updated_at=? WHERE id=?", (now(), draft_id))
        con.commit()
        voice_transition(con, session_id, 'error', trigger='timeout', result=f'action={action_id} timed out')
        voice_transition(con, session_id, 'idle', trigger='timeout_recovery', result=f'action={action_id}')
        audit(con, worker, 'permission_layer.gmail_draft', f'action={action_id}', 'timeout',
              'no result within 30s; a late result will be discarded, never applied')
        _register_late_discard(action_id, future, 'gmail_draft')
        return {'allowed': True, 'error': 'Draft creation timed out after 30 seconds.', 'action_id': action_id, 'draft_id': draft_id}
    except Exception as e:
        _set_action_status(con, action_id, 'failed', str(e)[:500])
        con.execute("UPDATE drafts SET status='failed', updated_at=? WHERE id=?", (now(), draft_id))
        con.commit()
        voice_transition(con, session_id, 'error', trigger='exception', result=str(e)[:120])
        voice_transition(con, session_id, 'idle', trigger='error_recovery', result=f'action={action_id}')
        audit(con, worker, 'permission_layer.gmail_draft', f'action={action_id}', 'error', str(e)[:500])
        return {'allowed': True, 'error': f'Draft creation failed: {e}', 'action_id': action_id, 'draft_id': draft_id}

    con.execute(
        "UPDATE drafts SET status='awaiting_confirmation', gmail_draft_id=?, updated_at=? WHERE id=?",
        (result.get('gmail_draft_id'), now(), draft_id)
    )
    con.commit()
    _set_action_status(con, action_id, 'done', f'draft {draft_id} created')
    voice_transition(con, session_id, 'draft_ready', trigger='draft_created', result=draft_id)
    set_pending_draft(con, session_id, draft_id)
    voice_transition(con, session_id, 'awaiting_confirmation', trigger='awaiting_send_confirmation', result=draft_id)
    audit(con, worker, 'permission_layer.gmail_draft', f'action={action_id}', 'ok', f'draft {draft_id} ready')
    return {'allowed': True, 'action_id': action_id, 'draft_id': draft_id, 'to': to, 'subject': subject, 'body': body_text}


def request_gmail_draft(con, session_id: str | None, worker: str, to: str, subject: str, body_text: str) -> dict:
    """The ONLY entry point any worker can use to create a Gmail draft.
    Independently re-checks the session, same hard requirement as read."""
    if not validate_session(con, session_id):
        audit(con, worker, 'permission_layer.gmail_draft', f'session={session_id!r}', 'refused',
              'not authenticated -- refused before any drafting transition or Gmail call')
        return {'allowed': False, 'error': 'Not authenticated -- Gmail draft refused.'}
    return _create_and_confirm_draft(con, session_id, worker, to, subject, body_text)


def request_gmail_send(con, session_id: str | None, draft_id: str, worker: str = 'personal_assistant',
                        do_send=None) -> dict:
    """The ONLY entry point that can actually send. Never called with a
    caller-supplied draft_id from outside this module in practice --
    handle_confirmation_reply always passes the session's OWN
    voice_state.pending_draft_id, never anything from the incoming
    request -- but this function independently re-validates the session
    and the exactly-once guard regardless of caller, the same discipline as
    every other request_* function here."""
    do_send = do_send or _do_gmail_send

    if not validate_session(con, session_id):
        audit(con, worker, 'permission_layer.gmail_send', f'session={session_id!r}', 'refused',
              'not authenticated -- refused before any send')
        return {'allowed': False, 'error': 'Not authenticated -- Gmail send refused.'}

    draft = con.execute('SELECT * FROM drafts WHERE id=?', (draft_id,)).fetchone()
    if not draft:
        audit(con, worker, 'permission_layer.gmail_send', f'draft={draft_id}', 'refused', 'unknown draft_id')
        return {'allowed': False, 'error': 'Unknown draft.'}

    # Exactly-once guard: refuse if an in_flight or executed send action
    # already exists for this draft_id. Checked in the same connection,
    # immediately before writing the new in_flight row below -- there is no
    # window where a second concurrent call for the same draft_id could
    # both pass this check before either one commits its own in_flight row.
    existing = con.execute(
        "SELECT id, status FROM actions WHERE draft_id=? AND tool='gmail_send' AND status IN ('in_flight','executed') "
        "ORDER BY created_at DESC LIMIT 1",
        (draft_id,)
    ).fetchone()
    if existing:
        audit(con, worker, 'permission_layer.gmail_send', f'draft={draft_id}', 'refused',
              f"an action for this draft is already {existing['status']} (action={existing['id']}) -- refusing duplicate send")
        return {'allowed': False, 'sent': False,
                'error': f"This draft already has a send {existing['status']} -- refusing to send again.",
                'existing_action_id': existing['id']}

    action_id = _new_action(con, session_id, worker, 'gmail_send', draft_id=draft_id)
    _set_action_status(con, action_id, 'in_flight')
    audit(con, worker, 'permission_layer.gmail_send', f'session={session_id} action={action_id} draft={draft_id}',
          'in_flight', 'written before calling Gmail -- exactly-once guard is now active for this draft')
    voice_transition(con, session_id, 'sending', trigger=f'{worker}:gmail_send', result=action_id)

    future = _executor.submit(do_send, draft['gmail_draft_id'])
    try:
        result = future.result(timeout=SEND_TIMEOUT_SECONDS)
    except FutureTimeoutError:
        # Deliberately does NOT mark failed and does NOT resend. The
        # action stays in_flight, so the exactly-once guard above keeps
        # refusing any further send attempt for this draft_id until Sam
        # explicitly confirms it did NOT arrive (confirm_send_not_received).
        audit(con, worker, 'permission_layer.gmail_send', f'action={action_id}', 'unconfirmed',
              'no result within 30s -- left in_flight, NOT resent; verify in Gmail before any retry')
        voice_transition(con, session_id, 'idle', trigger='send_unconfirmed', result=f'action={action_id}')
        _register_late_discard(action_id, future, 'gmail_send', open_statuses=('in_flight',))
        return {'allowed': True, 'sent': False, 'action_id': action_id, 'draft_id': draft_id,
                'error': 'Send status unconfirmed -- verify in Gmail before any retry.'}
    except Exception as e:
        # A clean, definite failure (Gmail itself rejected the send) is
        # different from a timeout: we KNOW it did not send, so it is safe
        # to mark it failed rather than leaving it stuck in_flight -- a
        # fresh attempt is allowed since 'failed' is not in the guard above.
        _set_action_status(con, action_id, 'failed', str(e)[:500])
        voice_transition(con, session_id, 'error', trigger='exception', result=str(e)[:120])
        voice_transition(con, session_id, 'idle', trigger='error_recovery', result=f'action={action_id}')
        audit(con, worker, 'permission_layer.gmail_send', f'action={action_id}', 'error', str(e)[:500])
        return {'allowed': True, 'sent': False, 'action_id': action_id, 'draft_id': draft_id, 'error': f'Send failed: {e}'}

    _set_action_status(con, action_id, 'executed', f"gmail_message_id={result.get('gmail_message_id')}")
    con.execute("UPDATE drafts SET status='sent', updated_at=? WHERE id=?", (now(), draft_id))
    con.commit()
    voice_transition(con, session_id, 'completed', trigger='send_complete', result=action_id)
    voice_transition(con, session_id, 'idle', trigger='send_complete_recovery', result=action_id)
    clear_pending_draft(con, session_id)
    audit(con, worker, 'permission_layer.gmail_send', f'action={action_id}', 'ok',
          f"sent, gmail_message_id={result.get('gmail_message_id')}")
    return {'allowed': True, 'sent': True, 'action_id': action_id, 'draft_id': draft_id,
            'gmail_message_id': result.get('gmail_message_id')}


def find_in_flight_send(con, session_id: str) -> str | None:
    """The most recent send action for this session still stuck in_flight,
    if any -- what NOT_RECEIVED_TRIGGER looks up before calling
    confirm_send_not_received. Deliberately not scoped to a particular
    voice_state (by the time Sam says this, current_state has usually
    already moved back to idle after the timeout)."""
    row = con.execute(
        "SELECT id FROM actions WHERE session_id=? AND tool='gmail_send' AND status='in_flight' "
        "ORDER BY created_at DESC LIMIT 1",
        (session_id,)
    ).fetchone()
    return row['id'] if row else None


def confirm_send_not_received(con, action_id: str, worker: str = 'personal_assistant') -> dict:
    """The ONLY way an in_flight send action ever gets cleared without a
    successful send confirmation. Requires an explicit, separate
    confirmation that the email did NOT arrive -- never automatic, never
    inferred from the timeout alone. Frees the draft up for a genuinely NEW
    action_id on the next send attempt; the old action_id is never reused
    or retried."""
    row = con.execute("SELECT * FROM actions WHERE id=? AND tool='gmail_send'", (action_id,)).fetchone()
    if not row:
        return {'ok': False, 'error': 'Unknown send action.'}
    if row['status'] != 'in_flight':
        return {'ok': False, 'error': f"This action is already {row['status']}, not in_flight -- nothing to clear."}
    _set_action_status(con, action_id, 'failed_confirmed_not_sent', 'Sam confirmed this did not arrive')
    audit(con, worker, 'permission_layer.gmail_send', f'action={action_id}', 'cleared_by_sam',
          'Sam explicitly confirmed this send did not arrive -- cleared for a fresh action_id, old one never reused')
    return {'ok': True}


def check_and_expire_confirmation(con, session_id: str) -> bool:
    """Lazy, on-next-interaction expiry. This codebase has no background
    scheduler anywhere (same fact vault.py's own docstring already
    establishes for the daily rollup) -- so, consistent with that existing
    architecture, a session-state timeout here is enforced opportunistically
    on the next real interaction rather than by a wall clock ticking in the
    background. The safety property (the send gate stays closed except in
    exactly this state, bound to exactly this draft_id) holds regardless of
    when this check actually runs; it just means the 120s window is
    measured up to Sam's next message, not to an independent timer. Returns
    True if it found and expired a stale awaiting_confirmation."""
    row = con.execute(
        'SELECT current_state, updated_at, pending_draft_id FROM voice_state WHERE session_id=?', (session_id,)
    ).fetchone()
    if not row or row['current_state'] != 'awaiting_confirmation':
        return False
    updated = datetime.fromisoformat(row['updated_at'])
    if updated.tzinfo is None:
        updated = updated.replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - updated).total_seconds()
    if age <= CONFIRMATION_TIMEOUT_SECONDS:
        return False
    draft_id = row['pending_draft_id']
    if draft_id:
        con.execute("UPDATE drafts SET status='expired', updated_at=? WHERE id=? AND status='awaiting_confirmation'",
                    (now(), draft_id))
        con.commit()
    clear_pending_draft(con, session_id)
    voice_transition(con, session_id, 'idle', trigger='confirmation_timeout',
                      result=f'draft={draft_id} expired after {CONFIRMATION_TIMEOUT_SECONDS}s')
    audit(con, 'permission_layer', 'gmail_draft', f'draft={draft_id}', 'expired',
          f'awaiting_confirmation timed out after {CONFIRMATION_TIMEOUT_SECONDS}s -- cancelled back to idle')
    return True


def _regenerate_draft_body(draft, change_request: str) -> dict:
    """Used only on a 'change it' reply -- asks the brain to revise the
    existing draft per Sam's instruction. Reply with EXACTLY one JSON
    object so the redraft can go straight back through
    _create_and_confirm_draft like any other draft."""
    prompt = (
        "Sam asked to change a draft email you already prepared. Revise it per his instruction. "
        "Reply with EXACTLY one JSON object and nothing else, in this shape: "
        '{"subject": "...", "body": "..."}\n\n'
        f"Original to: {draft['to_addr']}\nOriginal subject: {draft['subject']}\n"
        f"Original body:\n{draft['body_text']}\n\n"
        f"Sam's change instruction: {change_request}"
    )
    raw = _llm_run('personal_assistant', '', [{'role': 'user', 'content': prompt}],
                   model='claude-sonnet-5', provider='claude')
    text = raw.get('content', '') if isinstance(raw, dict) else str(raw)
    match = re.search(r'\{.*\}', text, re.S)
    if not match:
        return {'subject': draft['subject'], 'body': draft['body_text']}
    try:
        parsed = json.loads(match.group(0))
    except json.JSONDecodeError:
        return {'subject': draft['subject'], 'body': draft['body_text']}
    return {'subject': parsed.get('subject') or draft['subject'], 'body': parsed.get('body') or draft['body_text']}


def handle_confirmation_reply(con, session_id: str, text: str, worker: str = 'personal_assistant') -> dict:
    """Called only when current_state == 'awaiting_confirmation' (the
    caller checks that, and calls check_and_expire_confirmation first).
    This is the whole gate: opens ONLY when the text is an exact yes-list
    match AND it is bound to the draft_id currently pending for THIS
    session, read server-side from voice_state -- there is no other way to
    reach request_gmail_send. A change request redrafts (old draft
    superseded, new draft_id). Anything else re-asks; it never sends."""
    draft_id = get_pending_draft(con, session_id)
    draft = con.execute('SELECT * FROM drafts WHERE id=?', (draft_id,)).fetchone() if draft_id else None

    if not draft_id or not draft:
        voice_transition(con, session_id, 'idle', trigger='confirmation_missing_draft', result='no pending draft bound')
        return {'reply': "I don't have a pending draft to confirm -- what would you like me to do?", 'session_id': session_id}

    # Matched against a smart-quote-normalized copy only -- text itself
    # (used for storage/regeneration below) stays exactly as Sam typed it.
    matched_text = normalize_quotes(text)

    if NOT_RECEIVED_TRIGGER.search(matched_text):
        # Not actually applicable here (there's no in_flight send while
        # still awaiting_confirmation -- send hasn't happened yet), but
        # recognised and answered honestly rather than silently falling
        # through to the yes/change/re-ask logic below.
        return {'reply': "This one hasn't been sent yet -- it's still waiting on your confirmation. Send it, or change it?",
                'session_id': session_id}

    if _is_yes(text):
        result = request_gmail_send(con, session_id, draft_id, worker=worker)
        if result.get('sent'):
            reply = f"Sent. (Gmail message id {result.get('gmail_message_id')})"
        else:
            reply = result.get('error', 'Send status unconfirmed -- verify in Gmail before any retry.')
        return {'reply': reply, 'session_id': session_id, 'send_result': result}

    if CHANGE_TRIGGER.search(matched_text):
        con.execute("UPDATE drafts SET status='superseded', updated_at=? WHERE id=?", (now(), draft_id))
        con.commit()
        clear_pending_draft(con, session_id)
        voice_transition(con, session_id, 'processing', trigger='change_requested', result=f'old draft {draft_id} superseded')
        audit(con, worker, 'permission_layer.gmail_draft', f'draft={draft_id}', 'superseded',
              'Sam asked to change it -- old draft superseded harmlessly, redraft follows')
        revised = _regenerate_draft_body(draft, text)
        new_result = _create_and_confirm_draft(con, session_id, worker, draft['to_addr'],
                                                revised['subject'], revised['body'])
        if not new_result.get('allowed') or new_result.get('error'):
            return {'reply': f"Couldn't redraft: {new_result.get('error')}", 'session_id': session_id}
        return {'reply': (f"Updated. New draft to {new_result['to']}, subject \"{new_result['subject']}\":\n"
                           f"{new_result['body']}\n\nSend it?"),
                'session_id': session_id, 'draft_result': new_result}

    # Garbled / near-miss / anything else: do NOT send, re-ask. State stays
    # exactly where it was (awaiting_confirmation, same draft_id).
    audit(con, worker, 'permission_layer.gmail_draft', f'draft={draft_id}', 'unrecognized_reply',
          f'reply did not match the yes-list or change trigger: {text[:120]!r} -- re-asking, not sending')
    return {'reply': f'Just to be clear -- send the draft to {draft["to_addr"]}? Say "yes" to send, or "change it" to redraft.',
            'session_id': session_id}


def compose_draft_content(con, instruction: str, context_key: str = 'work') -> dict:
    """Uses the brain to turn Sam's instruction into a real to/subject/body,
    given the style profile for this context as input -- this function
    CONSUMES the profile, it never infers style itself (that's
    style_profile.build_style_profile's job, run separately). Reply with
    EXACTLY one JSON object."""
    profile = get_style_profile(con, context_key)
    profile_text = json.dumps(profile) if profile else '(no style profile yet -- use a neutral, clean tone)'
    prompt = (
        "Sam asked you to prepare an email. Turn his instruction into a real draft. "
        f"Match this communication style profile for the '{context_key}' context: {profile_text}\n\n"
        'Reply with EXACTLY one JSON object and nothing else: {"to": "...", "subject": "...", "body": "..."}\n'
        "If Sam's instruction doesn't include a clear recipient email address, set \"to\" to null instead of guessing.\n\n"
        f"Sam's instruction: {instruction}"
    )
    raw = _llm_run('personal_assistant', '', [{'role': 'user', 'content': prompt}],
                   model='claude-sonnet-5', provider='claude')
    text = raw.get('content', '') if isinstance(raw, dict) else str(raw)
    match = re.search(r'\{.*\}', text, re.S)
    if not match:
        return {'error': 'Could not parse a draft from that instruction.'}
    try:
        parsed = json.loads(match.group(0))
    except json.JSONDecodeError:
        return {'error': 'Could not parse a draft from that instruction.'}
    if not parsed.get('to'):
        return {'error': 'No clear recipient in that instruction -- who should this go to?'}
    return {'to': parsed['to'], 'subject': parsed.get('subject', ''), 'body': parsed.get('body', '')}
