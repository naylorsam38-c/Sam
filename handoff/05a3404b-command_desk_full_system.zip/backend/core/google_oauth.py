from __future__ import annotations
import os
from html import escape
from pathlib import Path
from google_auth_oauthlib.flow import Flow
from .db import now
from .auth import validate_session

# New, additive module -- Gmail OAuth capture only (Stage 2). Nothing here
# reads mail; that's Stage 3, gated behind its own permission layer.
BASE_DIR = Path(__file__).resolve().parents[1]
CLIENT_SECRET_PATH = BASE_DIR / 'google_client_secret.json'
TOKEN_PATH = BASE_DIR / 'google_token.json'
REDIRECT_URI = 'https://airexploit.com/commanddesk/oauth/callback'

# Stage 4: draft + send are now built (behind their own permission-layer
# gate and the locked yes-list send confirmation), so the consent request
# grows to the superset needed to actually create/send a draft. This never
# downgrades or removes the existing readonly grant -- requesting it again
# alongside compose/send in the SAME consent is what keeps read working too
# once Sam re-consents; Google issues one token covering everything granted.
SCOPES = [
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/gmail.compose',
    'https://www.googleapis.com/auth/gmail.send',
]


def _flow(state: str | None = None, code_verifier: str | None = None) -> Flow:
    return Flow.from_client_secrets_file(
        str(CLIENT_SECRET_PATH),
        scopes=SCOPES,
        state=state,
        redirect_uri=REDIRECT_URI,
        code_verifier=code_verifier,
    )


def start_flow(con, session_id: str) -> str:
    """Generates the one-time consent URL and binds the OAuth `state` value
    to the session that requested it -- this is what proves, on the way
    back, that the callback belongs to the same authenticated session that
    started it, independent of (and in addition to) the cookie check on the
    callback route itself.

    google-auth-oauthlib auto-generates a PKCE code_verifier the first time
    authorization_url() runs and only ever holds it as an attribute on THIS
    Flow object in memory. The callback runs in a later request (often after
    a process restart, always after this function has returned and the
    object has gone out of scope), so it can never see that attribute unless
    it's persisted somewhere durable. Storing it alongside `state` here --
    and only ever reading it back once, in complete_flow -- is that
    persistence."""
    flow = _flow()
    auth_url, state = flow.authorization_url(
        access_type='offline',       # required for a refresh token
        include_granted_scopes='true',
        prompt='consent',            # forces the consent screen so a refresh token is reissued
    )
    con.execute('INSERT INTO oauth_states (state, session_id, code_verifier, created_at) VALUES (?,?,?,?)',
                (state, session_id, flow.code_verifier, now()))
    con.commit()
    return auth_url


def complete_flow(con, state: str, code: str) -> dict:
    """Exchanges the authorization code for tokens.

    Deliberately does NOT take or check a session cookie. The real security
    property here is `state` itself: a single-use, ~178-bit random value
    (30 chars, 62-char alphabet, drawn from oauthlib's SystemRandom
    generator) that only ever existed because an authenticated session
    called start_flow(). Requiring the cookie ADDITIONALLY on this route
    was actively wrong -- Google's redirect can land in a browser context
    (an in-app webview, a different browser) that never had that cookie,
    which is exactly what happened to Sam's first real attempt. The
    session_id this flow belongs to comes from the oauth_states row itself,
    not from anything the incoming request claims."""
    row = con.execute('SELECT session_id, code_verifier FROM oauth_states WHERE state=?', (state,)).fetchone()
    if not row:
        raise ValueError("This link has expired or was already used. Ask Command Desk for a fresh consent link.")

    session_id = row['session_id']
    if not validate_session(con, session_id):
        con.execute('DELETE FROM oauth_states WHERE state=?', (state,))
        con.commit()
        raise ValueError("The session that started this no longer exists. Log in again and request a fresh link.")

    flow = _flow(state=state, code_verifier=row['code_verifier'])
    try:
        flow.fetch_token(code=code)
    except Exception as e:
        # The authorization code is single-use at Google's end regardless of
        # what happens here, so a retry with the same code/state can never
        # succeed -- consume the state row now rather than leaving a dead
        # row that just invites a confusing second failure.
        con.execute('DELETE FROM oauth_states WHERE state=?', (state,))
        con.commit()
        raise ValueError("Google didn't complete the connection. Ask Command Desk for a fresh consent link.") from e
    creds = flow.credentials

    token_json = creds.to_json()
    TOKEN_PATH.write_text(token_json, encoding='utf-8')
    os.chmod(TOKEN_PATH, 0o600)

    con.execute('DELETE FROM oauth_states WHERE state=?', (state,))
    con.commit()

    return {'has_refresh_token': bool(creds.refresh_token), 'scopes': list(creds.scopes or [])}


def render_success_page() -> str:
    return """<!doctype html>
<html><head><meta charset="utf-8"><title>Gmail connected</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:-apple-system,system-ui,sans-serif;background:#050607;color:#fff;
  display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;
  text-align:center;padding:24px}
.card{max-width:360px}
h1{font-size:20px;margin:0 0 8px;color:#7ee787}
p{color:rgba(255,255,255,.6);font-size:14px;line-height:1.5;margin:0 0 24px}
a{display:inline-block;background:#e8ebef;color:#000;padding:12px 24px;border-radius:12px;
  text-decoration:none;font-weight:600;font-size:14px}
</style></head>
<body><div class="card">
<h1>Gmail connected</h1>
<p>Command Desk can now read your inbox (read-only). Nothing has been changed or sent.</p>
<a href="/commanddesk/">Back to Command Desk</a>
</div></body></html>"""


def render_error_page(message: str) -> str:
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>Couldn't connect Gmail</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{{font-family:-apple-system,system-ui,sans-serif;background:#050607;color:#fff;
  display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;
  text-align:center;padding:24px}}
.card{{max-width:360px}}
h1{{font-size:20px;margin:0 0 8px;color:#ff6b6b}}
p{{color:rgba(255,255,255,.6);font-size:14px;line-height:1.5;margin:0 0 24px}}
a{{display:inline-block;background:#e8ebef;color:#000;padding:12px 24px;border-radius:12px;
  text-decoration:none;font-weight:600;font-size:14px}}
</style></head>
<body><div class="card">
<h1>Couldn't connect Gmail</h1>
<p>{escape(message)}</p>
<a href="/commanddesk/">Back to Command Desk</a>
</div></body></html>"""
