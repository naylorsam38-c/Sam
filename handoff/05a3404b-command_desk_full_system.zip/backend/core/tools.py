from __future__ import annotations
import json, uuid
from .db import now

# Security invariant (do not weaken): the only value this module ever persists
# as `credential` is an opaque token or API key issued by the tool's own
# provider for programmatic access -- never an account password. There is no
# function here that accepts a "password" parameter. Client apps are expected
# to obtain the credential themselves (OAuth consent flow run entirely on the
# client, or a provider-issued API key pasted by the user) before calling
# set_credential; this backend never talks to a provider to mint a token.


def create_tool(con, tool_type, label, kind='conversational', config=None, needs_credential=True):
    """needs_credential=False is for tools with nothing to authenticate (e.g.
    a local Ollama server reached by plain host URL) -- those go active
    immediately since there's no token to wait for."""
    tid = uuid.uuid4().hex
    status = 'pending' if needs_credential else 'active'
    con.execute(
        'INSERT INTO tool_connections (id,tool_type,label,kind,config,credential,credential_type,status,created_at) '
        'VALUES (?,?,?,?,?,?,?,?,?)',
        (tid, tool_type, label.strip(), kind, json.dumps(config or {}), None, 'none', status, now())
    )
    con.commit(); return tid


def list_tools(con):
    rows = con.execute('SELECT * FROM tool_connections ORDER BY created_at DESC').fetchall()
    return [_public(dict(r)) for r in rows]


def get_tool(con, tool_id):
    r = con.execute('SELECT * FROM tool_connections WHERE id=?', (tool_id,)).fetchone()
    return dict(r) if r else None


def get_tool_public(con, tool_id):
    """Same lookup as get_tool but with the credential stripped -- use this
    for anything that flows back out through the API."""
    tool = get_tool(con, tool_id)
    return _public(tool) if tool else None


def update_tool(con, tool_id, label=None, config=None):
    tool = get_tool(con, tool_id)
    if not tool:
        raise ValueError(f'Unknown tool: {tool_id}')
    new_label = label.strip() if label else tool['label']
    new_config = json.dumps(config) if config is not None else tool['config']
    con.execute('UPDATE tool_connections SET label=?, config=? WHERE id=?', (new_label, new_config, tool_id))
    con.commit()


def set_credential(con, tool_id, credential: str, credential_type: str):
    """The only write path for a tool's credential. `credential` must already
    be an opaque token/API key -- the caller (API route) is responsible for
    never accepting or forwarding anything that could be a raw password."""
    if credential_type not in ('oauth_token', 'api_key'):
        raise ValueError(f'Unsupported credential_type: {credential_type}')
    tool = get_tool(con, tool_id)
    if not tool:
        raise ValueError(f'Unknown tool: {tool_id}')
    con.execute(
        'UPDATE tool_connections SET credential=?, credential_type=?, status=? WHERE id=?',
        (credential, credential_type, 'active', tool_id)
    )
    con.commit()


def delete_tool(con, tool_id):
    con.execute('DELETE FROM tool_connections WHERE id=?', (tool_id,))
    con.commit()


def active_tools_for_hub(con):
    """Summaries (never credentials) for injecting into Hub's routing context."""
    rows = con.execute("SELECT * FROM tool_connections WHERE status='active' ORDER BY created_at DESC").fetchall()
    return [{'id': r['id'], 'label': r['label'], 'tool_type': r['tool_type'], 'kind': r['kind']} for r in rows]


def _public(row: dict):
    """Strip the credential value out of anything that leaves this module
    toward the API layer -- callers only ever need to know a tool IS
    connected, never the token itself."""
    row = dict(row)
    row['connected'] = row.get('credential') is not None
    row.pop('credential', None)
    return row
