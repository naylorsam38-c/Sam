from __future__ import annotations
import json, re
from .db import now
from .audit_log import log as audit_log

# idle -> listening -> processing -> idle. voice_state holds the real,
# persisted variable (one row per session, mutated in place). Every single
# transition is additionally written to the existing audit_log table via its
# existing helper -- timestamp, state, trigger, result -- so the state
# machine's history is inspectable independent of its current value.
# Additive only: voice_state is a new table; audit_log's schema and helper
# are reused completely unchanged.


def get_state(con, session_id: str) -> str:
    row = con.execute('SELECT current_state FROM voice_state WHERE session_id=?', (session_id,)).fetchone()
    return row['current_state'] if row else 'idle'


def transition(con, session_id: str, to_state: str, trigger: str, result: str = 'ok') -> dict:
    from_state = get_state(con, session_id)
    ts = now()
    existing = con.execute('SELECT 1 FROM voice_state WHERE session_id=?', (session_id,)).fetchone()
    if existing:
        con.execute('UPDATE voice_state SET current_state=?, updated_at=? WHERE session_id=?', (to_state, ts, session_id))
    else:
        con.execute('INSERT INTO voice_state (session_id, current_state, updated_at) VALUES (?,?,?)', (session_id, to_state, ts))
    con.commit()
    audit_log(
        con, 'nova_voice', 'voice_state_transition',
        trigger, f'{from_state}->{to_state}',
        json.dumps({'session_id': session_id, 'from': from_state, 'to': to_state, 'result': result, 'ts': ts})
    )
    return {'from': from_state, 'to': to_state, 'ts': ts}


# ── Stage 3: Sonnet wake ───────────────────────────────────────────────────
# brain_mode is a second, independent axis on the same voice_state row --
# 'ollama' (default, free, everyday) or 'claude' (woken on Sam's own word).
# Nothing here decides to wake or sleep on its own; these two regexes are
# the ONLY things that ever change brain_mode, and both are only ever
# checked for slot == 'nova_voice' in orchestrator.handle_turn -- the face
# model itself never sees or acts on this decision, it just gets told which
# model/provider to run on for this turn.
WAKE_TRIGGER = re.compile(
    r"\b(go deep(?:er)? (?:on|into) this|switch to sonnet|wake up sonnet|"
    r"think (?:harder|deeper) (?:on|about) this|use claude(?: for this)?)\b",
    re.I,
)
SLEEP_TRIGGER = re.compile(
    r"\b(back to (?:normal|ollama)|that'?s enough|switch back|"
    r"go back to ollama|sonnet off|stand down sonnet)\b",
    re.I,
)


def get_brain_mode(con, session_id: str) -> str:
    row = con.execute('SELECT brain_mode FROM voice_state WHERE session_id=?', (session_id,)).fetchone()
    return (row['brain_mode'] if row and row['brain_mode'] else 'ollama')


def set_brain_mode(con, session_id: str, mode: str, trigger: str) -> dict:
    from_mode = get_brain_mode(con, session_id)
    ts = now()
    existing = con.execute('SELECT 1 FROM voice_state WHERE session_id=?', (session_id,)).fetchone()
    if existing:
        con.execute('UPDATE voice_state SET brain_mode=?, updated_at=? WHERE session_id=?', (mode, ts, session_id))
    else:
        con.execute(
            'INSERT INTO voice_state (session_id, current_state, brain_mode, updated_at) VALUES (?,?,?,?)',
            (session_id, 'idle', mode, ts)
        )
    con.commit()
    audit_log(
        con, 'nova_voice', 'brain_mode_change',
        trigger, f'{from_mode}->{mode}',
        json.dumps({'session_id': session_id, 'from': from_mode, 'to': mode, 'ts': ts})
    )
    return {'from': from_mode, 'to': mode, 'ts': ts}


# ── Stage 4: send-confirmation binding ─────────────────────────────────────
# pending_draft_id is a third independent axis on the same voice_state row.
# It is what makes "that yes is bound to THIS specific draft_id in THIS
# state" true by construction rather than by a runtime check: the send
# gate (permission_layer.handle_confirmation_reply) never accepts a
# draft_id from the incoming request at all -- it always reads the
# session's OWN currently-pending draft_id from here. There is no code
# path anywhere that lets a caller name an arbitrary draft_id to confirm.


def get_pending_draft(con, session_id: str) -> str | None:
    row = con.execute('SELECT pending_draft_id FROM voice_state WHERE session_id=?', (session_id,)).fetchone()
    return row['pending_draft_id'] if row else None


def set_pending_draft(con, session_id: str, draft_id: str | None):
    ts = now()
    existing = con.execute('SELECT 1 FROM voice_state WHERE session_id=?', (session_id,)).fetchone()
    if existing:
        con.execute('UPDATE voice_state SET pending_draft_id=?, updated_at=? WHERE session_id=?', (draft_id, ts, session_id))
    else:
        con.execute(
            'INSERT INTO voice_state (session_id, current_state, pending_draft_id, updated_at) VALUES (?,?,?,?)',
            (session_id, 'idle', draft_id, ts)
        )
    con.commit()


def clear_pending_draft(con, session_id: str):
    set_pending_draft(con, session_id, None)
