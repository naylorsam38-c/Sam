from __future__ import annotations
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = ROOT / '.env'


def load_dotenv(path: Path = ENV_PATH) -> None:
    """Minimal .env loader -- no python-dotenv dependency required.
    Reads KEY=VALUE lines and sets them via os.environ.setdefault, so a real
    environment variable set outside the file always wins. Safe to call more
    than once. Silently does nothing if the file doesn't exist."""
    if not path.exists():
        return
    for line in path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, _, value = line.partition('=')
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            os.environ.setdefault(key, value)
