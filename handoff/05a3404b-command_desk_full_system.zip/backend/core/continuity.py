from __future__ import annotations
import json, uuid
from .db import now

def latest_open_session(con, slot=None):
    # slot=None keeps the original "latest open session anywhere" behavior,
    # used by resume_line's cross-slot "what was I just doing" summary.
    # open_session below passes slot explicitly -- that's the actual bug fix:
    # without it, switching Hub -> Research -> Hub compared the Hub lookup
    # against Research's session (the global latest), never matched, and
    # spawned a third orphaned session instead of resuming the first.
    if slot is not None:
        return con.execute(
            'SELECT * FROM sessions WHERE open=1 AND slot=? ORDER BY last_active DESC LIMIT 1', (slot,)
        ).fetchone()
    return con.execute('SELECT * FROM sessions WHERE open=1 ORDER BY last_active DESC LIMIT 1').fetchone()

def resume_line(con) -> str | None:
    s = latest_open_session(con)
    if not s: return None
    st = json.loads(s['state'] or '{}')
    summary = st.get('summary','session started')
    next_step = st.get('next_step','continue')
    return f"Last time ({s['slot']}): {summary}. Next: {next_step}. Pick up there?"

def open_session(con, slot='personal_assistant'):
    s = latest_open_session(con, slot)
    if s:
        return s['id']
    sid=uuid.uuid4().hex
    con.execute('INSERT INTO sessions VALUES (?,?,?,?,?,1)', (sid, slot, now(), now(), json.dumps({'summary':f'working in {slot}', 'next_step':'continue the thread'})))
    con.commit(); return sid

def update_state(con, session_id, summary, next_step):
    con.execute('UPDATE sessions SET state=?, last_active=? WHERE id=?', (json.dumps({'summary':summary,'next_step':next_step}), now(), session_id)); con.commit()

def write_intent(con, session_id, intent_text, request_text):
    """Store Hub's stated intent for this session, alongside summary/next_step
    in the same state JSON blob. Purely a record of what Hub said it would
    do -- nothing reads this back to check itself; only the Checker, later,
    after the session closes, ever compares it to what actually happened.

    request_text is the user's own message that produced THIS intent, and
    is written in the same call, as a paired unit -- never reconstructed
    later from transcript history. A later turn with no INTENT line (e.g.
    "thanks, how's it going") never calls this function, so both intent
    and its paired request_text stay frozen together from whichever turn
    actually produced them; they can't drift apart or get mismatched."""
    row = con.execute('SELECT state FROM sessions WHERE id=?', (session_id,)).fetchone()
    state = json.loads(row['state']) if row and row['state'] else {}
    state['intent'] = intent_text
    state['intent_request_text'] = request_text
    con.execute('UPDATE sessions SET state=?, last_active=? WHERE id=?', (json.dumps(state), now(), session_id)); con.commit()

def write_turn(con, session_id, slot, role, content):
    con.execute('INSERT INTO transcript(session_id,slot,role,content,ts) VALUES (?,?,?,?,?)', (session_id,slot,role,content,now())); con.commit()

def close_session(con, session_id):
    con.execute('UPDATE sessions SET open=0,last_active=? WHERE id=?', (now(), session_id)); con.commit()

def peer_transcript(con, slot_ids, limit=4):
    """Fetch recent turns written by other slots in the same isolated group
    (e.g. Builder reading Tester's last notes, and vice versa). Returns oldest
    first so it reads like a normal conversation log.

    Scoped to OPEN sessions only. Originally this read the transcript table
    with no session boundary at all, so a peer's turns kept bleeding forward
    into every subsequent session for the OTHER slot regardless of how long
    ago they happened or whether anyone ever closed that conversation out --
    that's exactly how a single stale exchange (isolated_group members asked
    to scheme up a money-making plan behind Sam's back, correctly refused)
    stayed live: the refusal itself kept getting fed to the other peer as
    "recent notes", which produced another refusal, which fed back the other
    way, indefinitely. Closing the session did nothing by itself because
    this query never looked at session state. Joining on sessions.open=1
    means a closed session's turns stop surfacing to the peer immediately,
    while a genuinely live back-and-forth (session still open) keeps
    flowing exactly as before."""
    slot_ids = [s for s in (slot_ids or []) if s]
    if not slot_ids:
        return []
    placeholders = ','.join('?' * len(slot_ids))
    rows = con.execute(
        f'SELECT t.slot, t.role, t.content, t.ts FROM transcript t '
        f'JOIN sessions s ON s.id = t.session_id '
        f'WHERE t.slot IN ({placeholders}) AND s.open=1 '
        'ORDER BY t.ts DESC LIMIT ?', (*slot_ids, limit)
    ).fetchall()
    return [dict(r) for r in reversed(rows)]
