def describe():
    return 'Memory'
