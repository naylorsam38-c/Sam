def describe():
    return 'Personal Assistant'
