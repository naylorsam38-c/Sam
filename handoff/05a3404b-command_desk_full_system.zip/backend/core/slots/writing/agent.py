def describe():
    return 'Writing'
