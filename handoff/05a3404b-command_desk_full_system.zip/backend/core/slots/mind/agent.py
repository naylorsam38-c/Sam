def describe():
    return 'Mind'
