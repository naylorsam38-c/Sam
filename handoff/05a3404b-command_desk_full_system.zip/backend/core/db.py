from __future__ import annotations
import sqlite3, json, os
from pathlib import Path
from datetime import datetime, timezone

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / 'data'
DB_PATH = DATA_DIR / 'aire.db'

def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')

# iOS/Android keyboards autocorrect straight quotes to smart/curly ones by
# default, so real phone-typed text almost never contains a literal ' or ".
# Every trigger-phrase regex in this codebase (MAIL_TRIGGER, WAKE_TRIGGER,
# SLEEP_TRIGGER, NOT_RECEIVED_TRIGGER, ...) is written and tested with
# straight quotes, so without this a phrase like Sam's real "what's come
# in" (typed with U+2019) silently never matches the same pattern that
# matches "what's come in" (U+0027). Call this ONCE on the text used for
# trigger matching only -- never on what gets stored or shown, so the
# transcript keeps Sam's actual typed text unaltered.
# Built from codepoints, not literal characters, so this source file itself
# stays straight-quotes-only -- chr(0x2018)/chr(0x2019) are left/right single
# (curly apostrophe), chr(0x201c)/chr(0x201d) are left/right double.
_SMART_QUOTES = {
    chr(0x2018): "'", chr(0x2019): "'",
    chr(0x201c): '"', chr(0x201d): '"',
}

def normalize_quotes(text: str) -> str:
    for smart, straight in _SMART_QUOTES.items():
        text = text.replace(smart, straight)
    return text

def connect(path: Path | str = DB_PATH):
    DATA_DIR.mkdir(exist_ok=True)
    con = sqlite3.connect(path, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con

def init_db(con=None):
    con = con or connect()

    # One-time rename for any pre-existing DB still on the old table names --
    # renaming (not copy+drop) preserves every existing row untouched. Must
    # run BEFORE the CREATE TABLE IF NOT EXISTS block below: otherwise that
    # block would create an empty conversation_group_members/messages table
    # first, and this rename would then see the new name already "exists"
    # and skip, orphaning the old table's data permanently.
    existing = {r['name'] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    if 'group_members' in existing and 'conversation_group_members' not in existing:
        con.execute('ALTER TABLE group_members RENAME TO conversation_group_members')
    if 'group_transcript' in existing and 'conversation_group_messages' not in existing:
        con.execute('ALTER TABLE group_transcript RENAME TO conversation_group_messages')

    con.executescript('''
    CREATE TABLE IF NOT EXISTS context (namespace TEXT, key TEXT, value TEXT, updated_at TEXT, PRIMARY KEY(namespace,key));
    CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, slot TEXT, started_at TEXT, last_active TEXT, state TEXT, open INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS transcript (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT, slot TEXT, role TEXT, content TEXT, ts TEXT);
    CREATE TABLE IF NOT EXISTS decisions (id TEXT PRIMARY KEY, topic TEXT, decision TEXT, rationale TEXT, alternatives TEXT, decided_at TEXT, slot TEXT, status TEXT DEFAULT 'active');
    CREATE TABLE IF NOT EXISTS nudges (id TEXT PRIMARY KEY, kind TEXT, text TEXT, created_at TEXT, due TEXT, done INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, slot TEXT, tool TEXT, input_summary TEXT, outcome TEXT, details TEXT);
    CREATE TABLE IF NOT EXISTS memories (id TEXT PRIMARY KEY, text TEXT, meta TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS agent_templates (id TEXT PRIMARY KEY, name TEXT, system_prompt TEXT, model TEXT, tools TEXT, accent_color TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS agent_instances (id TEXT PRIMARY KEY, template_id TEXT, name TEXT, status TEXT DEFAULT 'active', created_at TEXT, stopped_at TEXT);
    CREATE TABLE IF NOT EXISTS conversation_groups (id TEXT PRIMARY KEY, name TEXT, created_at TEXT, status TEXT DEFAULT 'active');
    CREATE TABLE IF NOT EXISTS conversation_group_members (group_id TEXT, member_id TEXT, added_at TEXT, PRIMARY KEY(group_id, member_id));
    CREATE TABLE IF NOT EXISTS conversation_group_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, group_id TEXT, member_id TEXT, content TEXT, ts TEXT);
    CREATE TABLE IF NOT EXISTS tool_connections (
        id TEXT PRIMARY KEY,
        tool_type TEXT,
        label TEXT,
        kind TEXT,
        config TEXT,
        credential TEXT,
        credential_type TEXT,
        status TEXT DEFAULT 'active',
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS oversight_records (
        session_id TEXT PRIMARY KEY,
        tenant_id TEXT,
        agent TEXT,
        intent TEXT,
        raw_transcript TEXT,
        outcome TEXT,
        summary TEXT,
        flag TEXT,
        written_at TEXT,
        written_by TEXT
    );
    CREATE TABLE IF NOT EXISTS oversight_checks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        tenant_id TEXT,
        status TEXT,
        matches TEXT,
        mismatches TEXT,
        checked_at TEXT,
        written_by TEXT
    );
    CREATE TABLE IF NOT EXISTS review_queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        tenant_id TEXT,
        history TEXT,
        diagnosis TEXT,
        suggested_handoff TEXT,
        raised_at TEXT,
        raised_by TEXT,
        status TEXT
    );
    -- Phase 1 memory: worker_daily is each slot's rolling window (3-5 days,
    -- MEMORY_WINDOW_DAYS in vault.py) -- the only context a worker carries by
    -- default. vault_entries is the permanent, append-only long-term store;
    -- entries age INTO it from worker_daily on overflow and are never deleted
    -- or overwritten once there, same discipline as the oversight tables.
    CREATE TABLE IF NOT EXISTS worker_daily (
        id TEXT PRIMARY KEY,
        slot TEXT,
        day TEXT,
        summary TEXT,
        message_count INTEGER,
        created_at TEXT,
        UNIQUE(slot, day)
    );
    CREATE TABLE IF NOT EXISTS vault_entries (
        id TEXT PRIMARY KEY,
        slot TEXT,
        day TEXT,
        summary TEXT,
        archived_at TEXT
    );
    -- Per-session "seen this before" dedup for the vault trigger (locked spec
    -- point 5: no repeat queries on the same subject). Deliberately its own
    -- table rather than a key in sessions.state: update_state() overwrites
    -- that whole JSON blob on every single turn regardless of slot/subject,
    -- so anything stored there would be wiped by the very next turn, not just
    -- a same-turn ordering issue. A dedicated table has no such dependency.
    CREATE TABLE IF NOT EXISTS vault_queries (
        id TEXT PRIMARY KEY,
        session_id TEXT,
        subject TEXT,
        queried_at TEXT
    );
    -- Stage 1 identity gate. auth_users holds exactly one seeded row
    -- (command / bcrypt hash of Nova) -- password_hash only, never plaintext.
    -- auth_sessions marks which of the existing `sessions` rows is currently
    -- authenticated: the login session IS the continuity session_id, not a
    -- second parallel token. login_attempts is insert-only, used for the
    -- rolling-window lockout and as a record of failed attempts.
    CREATE TABLE IF NOT EXISTS auth_users (
        username TEXT PRIMARY KEY,
        password_hash TEXT,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS auth_sessions (
        session_id TEXT PRIMARY KEY,
        username TEXT,
        created_at TEXT,
        last_seen_at TEXT
    );
    CREATE TABLE IF NOT EXISTS login_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        success INTEGER,
        ip TEXT,
        ts TEXT
    );
    -- Stage 1 voice state machine: idle -> listening -> processing -> idle
    -- (Stage 3 adds tool_requested/reading/error, all written through the
    -- same transition() helper -- no schema change needed for new state
    -- names since current_state is just a free-text column).
    -- One row per session, mutated in place -- the real persisted variable.
    -- Every transition is additionally written to the existing audit_log
    -- table (see voice_state.py), so the value here is a live pointer and
    -- audit_log is the durable history of how it got there.
    CREATE TABLE IF NOT EXISTS voice_state (
        session_id TEXT PRIMARY KEY,
        current_state TEXT,
        updated_at TEXT
    );
    -- Stage 2: binds a Google OAuth `state` value to the session that
    -- requested it, so the callback can prove the code it received belongs
    -- to the same authenticated session that started the flow (CSRF
    -- protection independent of the cookie check the route already applies).
    -- A row is deleted the moment its flow completes -- this table only
    -- ever holds in-flight consent requests, never a history.
    CREATE TABLE IF NOT EXISTS oauth_states (
        state TEXT PRIMARY KEY,
        session_id TEXT,
        code_verifier TEXT,
        created_at TEXT
    );
    -- Stage 3: action lifecycle for anything requested through the
    -- permission layer (currently just gmail_read). Every action a worker
    -- asks the layer to perform gets a row here from the moment it's
    -- requested; status moves pending -> running -> done/failed. This is
    -- what lets a late-arriving result (one that finishes after its 30s
    -- timeout already fired) check "is this action still open?" and know
    -- to discard itself -- see permission_layer.py's done-callback.
    CREATE TABLE IF NOT EXISTS actions (
        id TEXT PRIMARY KEY,
        session_id TEXT,
        worker TEXT,
        tool TEXT,
        status TEXT,
        created_at TEXT,
        completed_at TEXT,
        result_summary TEXT
    );
    ''')
    # conversation_groups gained started_by/summary/closed_at after it was already
    # live with data -- CREATE TABLE IF NOT EXISTS won't add columns to an existing
    # table, so migrate additively and only when a column is actually missing, so
    # groups created before this change keep their rows intact.
    cols = {r['name'] for r in con.execute("PRAGMA table_info(conversation_groups)").fetchall()}
    for col in ('started_by', 'summary', 'closed_at'):
        if col not in cols:
            con.execute(f'ALTER TABLE conversation_groups ADD COLUMN {col} TEXT')

    # oversight_checks gained these once the grounding/field-comparison brain
    # was wired in -- additive only, same pattern as above, no existing table
    # (including this one's original columns) is altered or dropped.
    cols = {r['name'] for r in con.execute("PRAGMA table_info(oversight_checks)").fetchall()}
    for col in ('unverifiable', 'intent_fields', 'outcome_fields', 'fabrications'):
        if col not in cols:
            con.execute(f'ALTER TABLE oversight_checks ADD COLUMN {col} TEXT')

    # review_queue predates the grounding brain's angel.py, which produces a
    # case shaped {trigger, judgement, ...} instead of the original
    # {history, diagnosis, suggested_handoff}. Additive only, same pattern --
    # without this, Angel's actual judgement text is silently dropped on write.
    cols = {r['name'] for r in con.execute("PRAGMA table_info(review_queue)").fetchall()}
    for col in ('trigger', 'judgement'):
        if col not in cols:
            con.execute(f'ALTER TABLE review_queue ADD COLUMN {col} TEXT')

    # oauth_states gained code_verifier after the first real consent attempt
    # failed with "Missing code verifier" -- google-auth-oauthlib generates a
    # PKCE verifier per-Flow-object and never persists it itself, so it must
    # be stored here and re-applied to a fresh Flow object in the callback.
    # Additive only, same pattern as above.
    cols = {r['name'] for r in con.execute("PRAGMA table_info(oauth_states)").fetchall()}
    if 'code_verifier' not in cols:
        con.execute('ALTER TABLE oauth_states ADD COLUMN code_verifier TEXT')

    # Stage 3: which brain nova_voice answers on -- lives on the same
    # voice_state row as current_state (not sessions.state, same
    # blind-overwrite reason as everywhere else here) but is a genuinely
    # separate axis: current_state is the idle/listening/processing/
    # tool_requested/reading/error machine, brain_mode is just 'ollama' or
    # 'claude'. Only Sam's own wake/sleep phrasing ever changes it -- see
    # voice_state.WAKE_TRIGGER/SLEEP_TRIGGER.
    cols = {r['name'] for r in con.execute("PRAGMA table_info(voice_state)").fetchall()}
    if 'brain_mode' not in cols:
        con.execute("ALTER TABLE voice_state ADD COLUMN brain_mode TEXT DEFAULT 'ollama'")

    # Stage 4: which draft (if any) the send-confirmation gate for this
    # session is currently bound to. Lives on the same voice_state row for
    # the same reason brain_mode does -- a third independent axis, not
    # touched by anything except the drafting/confirmation code path.
    if 'pending_draft_id' not in cols:
        con.execute('ALTER TABLE voice_state ADD COLUMN pending_draft_id TEXT')

    # Stage 4: draft/send action lifecycle needs to know WHICH draft an
    # action belongs to, so the exactly-once guard on send can look up "is
    # there already an in_flight/executed action for this draft_id" before
    # calling Gmail. gmail_read actions (Stage 3) never set this column.
    cols = {r['name'] for r in con.execute("PRAGMA table_info(actions)").fetchall()}
    if 'draft_id' not in cols:
        con.execute('ALTER TABLE actions ADD COLUMN draft_id TEXT')

    # Stage 4: one row per drafted email, independent of the Gmail draft
    # resource itself (gmail_draft_id references that once created).
    # status moves pending -> awaiting_confirmation -> sent, or sideways to
    # cancelled/expired/superseded/failed. Never deleted, so the full
    # history of every draft this system ever proposed stays inspectable.
    con.execute('''
    CREATE TABLE IF NOT EXISTS drafts (
        id TEXT PRIMARY KEY,
        session_id TEXT,
        worker TEXT,
        to_addr TEXT,
        subject TEXT,
        body_text TEXT,
        gmail_draft_id TEXT,
        status TEXT,
        created_at TEXT,
        updated_at TEXT
    )
    ''')

    # Stage 4: persistent per-context (mates/work, for now) communication
    # style profile, built once from Sam's real Sent mail by the brain
    # model and consumed -- never inferred -- by the drafting step.
    con.execute('''
    CREATE TABLE IF NOT EXISTS style_profiles (
        id TEXT PRIMARY KEY,
        context_key TEXT UNIQUE,
        profile_json TEXT,
        is_temporary INTEGER DEFAULT 0,
        created_at TEXT,
        updated_at TEXT
    )
    ''')

    con.commit(); return con
