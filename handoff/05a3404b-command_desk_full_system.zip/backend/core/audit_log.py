from .db import now

def log(con, slot, tool, input_summary, outcome, details=''):
    con.execute('INSERT INTO audit_log(ts,slot,tool,input_summary,outcome,details) VALUES (?,?,?,?,?,?)',
                (now(), slot, tool, input_summary[:500], outcome, details[:2000]))
    con.commit()
