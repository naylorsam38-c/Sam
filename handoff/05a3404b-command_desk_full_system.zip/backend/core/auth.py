from __future__ import annotations
import bcrypt
from datetime import datetime, timedelta, timezone
from .db import now
from .continuity import open_session

# Seeded once, at first boot, to compute the initial hash -- never stored or
# compared in plaintext again after that. This constant lives in a
# backend-only file; it is never sent to the client and appears in no
# frontend file, JS, or HTML.
DEFAULT_USERNAME = 'command'
DEFAULT_PASSWORD = 'Nova'

LOCKOUT_THRESHOLD = 5
LOCKOUT_WINDOW_MINUTES = 15


def seed_default_user(con):
    """Idempotent: only inserts if the row is missing, so this is safe to
    call on every startup without resetting a since-rotated password."""
    row = con.execute('SELECT 1 FROM auth_users WHERE username=?', (DEFAULT_USERNAME,)).fetchone()
    if row:
        return
    pw_hash = bcrypt.hashpw(DEFAULT_PASSWORD.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    con.execute('INSERT INTO auth_users (username, password_hash, created_at) VALUES (?,?,?)',
                (DEFAULT_USERNAME, pw_hash, now()))
    con.commit()


def is_locked_out(con, username: str) -> bool:
    """Rolling window: 5+ failed attempts for this username in the last
    LOCKOUT_WINDOW_MINUTES blocks further attempts until the window clears."""
    window_start = (datetime.now(timezone.utc) - timedelta(minutes=LOCKOUT_WINDOW_MINUTES)).isoformat()
    row = con.execute(
        'SELECT COUNT(*) c FROM login_attempts WHERE username=? AND success=0 AND ts>?',
        (username, window_start)
    ).fetchone()
    return row['c'] >= LOCKOUT_THRESHOLD


def record_attempt(con, username: str, success: bool, ip: str | None):
    con.execute('INSERT INTO login_attempts (username, success, ip, ts) VALUES (?,?,?,?)',
                (username, 1 if success else 0, ip, now()))
    con.commit()


def verify_login(con, username: str, password: str) -> bool:
    row = con.execute('SELECT password_hash FROM auth_users WHERE username=?', (username,)).fetchone()
    if not row:
        return False
    try:
        return bcrypt.checkpw(password.encode('utf-8'), row['password_hash'].encode('utf-8'))
    except ValueError:
        return False


def create_session(con, username: str) -> str:
    """The login session IS the continuity session: opens/resumes a real row
    in the existing sessions table (slot='nova_voice') rather than inventing
    a second, parallel session concept. auth_sessions only records that this
    particular session_id is currently authenticated."""
    session_id = open_session(con, 'nova_voice')
    existing = con.execute('SELECT 1 FROM auth_sessions WHERE session_id=?', (session_id,)).fetchone()
    if existing:
        con.execute('UPDATE auth_sessions SET last_seen_at=? WHERE session_id=?', (now(), session_id))
    else:
        con.execute('INSERT INTO auth_sessions (session_id, username, created_at, last_seen_at) VALUES (?,?,?,?)',
                    (session_id, username, now(), now()))
    con.commit()
    return session_id


def validate_session(con, session_id: str | None) -> bool:
    if not session_id:
        return False
    row = con.execute('SELECT 1 FROM auth_sessions WHERE session_id=?', (session_id,)).fetchone()
    return bool(row)


def invalidate_session(con, session_id: str):
    con.execute('DELETE FROM auth_sessions WHERE session_id=?', (session_id,))
    con.commit()
