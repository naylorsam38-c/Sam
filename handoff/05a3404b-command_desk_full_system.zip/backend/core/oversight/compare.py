"""
COMPARE — deterministic field matching. NO MODEL TOUCHES THIS FILE.

This is the load-bearing design decision of the whole oversight layer:

    The model does LANGUAGE. Python does JUDGEMENT.

A model is used once, to turn free text ("send the March invoice to Acme
for $250") into structured fields. From that point on, deciding whether
the intent matched the outcome is plain Python — exact, repeatable, and
impossible to hallucinate. If we let the model decide "did this match?"
it would sometimes say yes to a $2500 invoice that should have been $250,
and it would say it confidently. So it never gets that job.

Three verdicts per field, never two:
    match        — intent said X, outcome did X
    mismatch     — intent said X, outcome did Y            <- the real catch
    unverifiable — intent said X, outcome has no data on X

"unverifiable" exists because collapsing it into either of the others is
a lie. Silently calling it a match hides failures. Calling it a mismatch
cries wolf. The honest answer is "I could not check this."
"""

import re

# The fixed field set. Deliberately small. A field that isn't here isn't
# checked — better a narrow honest check than a wide guessy one.
FIELDS = ("action", "recipient", "amount", "reference")

# Intent text that extracted to nothing useful — the "send something"
# failure. Not a mismatch; the system simply couldn't be checked.
VAGUE = "intent_too_vague"


def _norm(value) -> str | None:
    """Normalise a value for comparison. None stays None."""
    if value is None:
        return None
    s = str(value).strip().lower()
    if not s:
        return None
    # strip currency symbols, thousands separators, trailing zeroes on money
    s = s.replace("$", "").replace(",", "")
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[.\s]+$", "", s)
    # 250.00 and 250 are the same amount
    if re.fullmatch(r"\d+\.\d+", s):
        s = s.rstrip("0").rstrip(".")
    return s or None


def _amounts_equal(a: str, b: str) -> bool:
    """Money compares numerically, not as strings."""
    try:
        return abs(float(a) - float(b)) < 0.005
    except (TypeError, ValueError):
        return a == b


def compare(intent_fields: dict, outcome_fields: dict) -> dict:
    """
    Pure function. Same inputs always give the same output.

    intent_fields  — what the Hub SAID it would do (from field_extract)
    outcome_fields — what actually happened (from the session outcome)

    Returns the checker result body: status, matches, mismatches,
    unverifiable. Never raises on odd input; unknown becomes unverifiable.
    """
    matches, mismatches, unverifiable = [], [], []

    stated = {f: _norm(intent_fields.get(f)) for f in FIELDS}

    # Nothing usable came out of the intent — that IS the finding.
    if not any(stated.values()):
        return {
            "status": VAGUE,
            "matches": [],
            "mismatches": [],
            "unverifiable": [{"field": f, "reason": "no value stated"} for f in FIELDS],
        }

    for field in FIELDS:
        intended = stated[field]
        if intended is None:
            continue  # intent didn't claim this field; nothing to check

        actual = _norm(outcome_fields.get(field))

        if actual is None:
            unverifiable.append({
                "field": field,
                "intended": intended,
                "reason": "outcome recorded no value for this field",
            })
            continue

        equal = _amounts_equal(intended, actual) if field == "amount" else intended == actual

        if equal:
            matches.append({"field": field, "value": intended})
        else:
            mismatches.append({
                "field": field,
                "intended": intended,
                "actual": actual,
            })

    if mismatches:
        status = "mismatch"
    elif matches:
        status = "checked"
    else:
        # intent stated things, outcome could confirm none of them
        status = "unverified"

    return {
        "status": status,
        "matches": matches,
        "mismatches": mismatches,
        "unverifiable": unverifiable,
    }
