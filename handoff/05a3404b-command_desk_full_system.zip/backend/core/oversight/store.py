"""
STORE — the only file that touches the database for the oversight layer.

Merge note for Dispatch: wire these four functions to the project's real
DB layer (SQLite now, PostgreSQL later — every table gets tenant_id, same
as the rest of the schema). Two new tables:

  oversight_records   -- written by Clerk, read by Angel
  oversight_checks    -- written by Checker
  review_queue        -- written by Angel, read by SAM's UI only

Structural enforcement lives in the SHAPE of this file:
- There is no generic "write anything" function. Each module can only do
  what its function allows. The Angel has exactly one write path, and it
  lands in Sam's queue — nowhere else.
- Nothing in here reaches agent memory, lessons, or any existing table.
"""

import json

from ..db import connect


# --- Clerk's write path ---
def write_record(record: dict) -> None:
    con = connect()
    con.execute(
        'INSERT OR REPLACE INTO oversight_records '
        '(session_id, tenant_id, agent, intent, raw_transcript, outcome, summary, flag, written_at, written_by) '
        'VALUES (?,?,?,?,?,?,?,?,?,?)',
        (
            record['session_id'], record['tenant_id'], record['agent'], record.get('intent'),
            json.dumps(record['raw_transcript']), json.dumps(record['outcome']),
            record.get('summary'), record.get('flag'), record['written_at'], record['written_by'],
        ),
    )
    con.commit()


# --- Checker's write path ---
def write_check(result: dict) -> None:
    con = connect()
    con.execute(
        'INSERT INTO oversight_checks '
        '(session_id, tenant_id, status, matches, mismatches, checked_at, written_by, '
        'unverifiable, intent_fields, outcome_fields, fabrications) '
        'VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        (
            result['session_id'], result['tenant_id'], result['status'],
            json.dumps(result['matches']), json.dumps(result['mismatches']),
            result['checked_at'], result['written_by'],
            json.dumps(result.get('unverifiable', [])),
            json.dumps(result.get('intent_fields', {})),
            json.dumps(result.get('outcome_fields', {})),
            json.dumps(result.get('fabrications', [])),
        ),
    )
    con.commit()


# --- Angel's read path (raw record only) ---
def read_record(session_id: str, tenant_id: str) -> dict | None:
    con = connect()
    row = con.execute(
        'SELECT * FROM oversight_records WHERE session_id=? AND tenant_id=?',
        (session_id, tenant_id),
    ).fetchone()
    if row is None:
        return None
    rec = dict(row)
    rec['raw_transcript'] = json.loads(rec['raw_transcript'] or '[]')
    rec['outcome'] = json.loads(rec['outcome'] or '{}')
    return rec


# --- Angel's ONLY write path: Sam's queue ---
def write_case_to_review_queue(case: dict) -> None:
    con = connect()
    con.execute(
        'INSERT INTO review_queue '
        '(session_id, tenant_id, history, diagnosis, suggested_handoff, raised_at, raised_by, status, '
        'trigger, judgement) '
        'VALUES (?,?,?,?,?,?,?,?,?,?)',
        (
            case['session_id'], case['tenant_id'], case.get('history'), case.get('diagnosis'),
            case.get('suggested_handoff'), case['raised_at'], case['raised_by'], case['status'],
            case.get('trigger'), case.get('judgement'),
        ),
    )
    con.commit()
