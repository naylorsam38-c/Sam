"""
ANGEL — the read-only judge. Comes to SAM, never to the Hub.

Structural rules (do not weaken these when merging):
- READ-ONLY. It has no action tools, no path to the Hub, no path to any
  agent. Its only imports are router_contract, store, and threshold.
- Its ONE write lands in review_queue, which only Sam's UI reads.
- It reads the RAW record once, after the session is over. Not live.
- Model from the router as "sharp". Never names a model.

THE THRESHOLD DECISION (was left open — decided here, easy to change):

  The Angel stays SILENT unless one of these is true:

    0. intent_fabricated - the Hub stated a detail nobody ever gave it
    1. mismatch          - intent and outcome disagree on a field
    2. no_intent_recorded - the Hub acted without saying what it intended
    3. intent_too_vague  - the Hub said something unusable ("send something")
    4. unverified        - intent claimed things, outcome confirmed none

  Everything else — a clean "checked" — produces NO case and NO noise.

Why this line: 2, 3 and 4 are not "the agent did something wrong", they
are "the system could not tell whether it did something wrong". That is
worth Sam's attention exactly as much as an error is, because it means
the safety net has a hole in it. A quiet failure to check is the thing
that bites later. 1 is the obvious catch.

Cry-wolf control lives here and nowhere else: if the queue gets noisy,
tighten this list — do not soften the Checker, and never teach the Hub
to write vaguer intents to keep the queue clean.
"""

from datetime import datetime, timezone
from pathlib import Path

from .router_contract import get_model
from .store import read_record, write_case_to_review_queue

_PROMPT_PATH = Path(__file__).parent / "prompts" / "angel_judge.txt"

# Statuses that earn Sam's attention. Single source of truth.
RAISE_ON = frozenset({
    "intent_fabricated",
    "mismatch",
    "no_intent_recorded",
    "intent_too_vague",
    "unverified",
})


def should_raise(check: dict) -> bool:
    """Pure function, no model, trivially testable."""
    return check.get("status") in RAISE_ON


def judge_session(session_id: str, tenant_id: str, check: dict, call_model) -> dict | None:
    """
    Called after the Checker. Returns the case it raised, or None if the
    session was clean and no case was warranted.

    check      — the Checker's result for this session
    call_model — injected callable (model_name, prompt) -> str
    """
    if not should_raise(check):
        return None

    record = read_record(session_id, tenant_id)
    model = get_model("sharp")

    prompt = (
        _PROMPT_PATH.read_text(encoding="utf-8")
        .replace("{{STATUS}}", str(check.get("status")))
        .replace("{{MISMATCHES}}", str(check.get("mismatches", [])))
        .replace("{{FABRICATIONS}}", str(check.get("fabrications", [])))
        .replace("{{UNVERIFIABLE}}", str(check.get("unverifiable", [])))
        .replace("{{INTENT_FIELDS}}", str(check.get("intent_fields", {})))
        .replace("{{RECORD}}", str(record))
    )

    try:
        judgement = call_model(model, prompt)
    except Exception as exc:
        # The Angel failing is itself something Sam should see, not a
        # silent skip. Raise the case anyway, with the failure stated.
        judgement = f"[angel could not produce a judgement: {exc}]"

    case = {
        "session_id": session_id,
        "tenant_id": tenant_id,
        "trigger": check.get("status"),
        "judgement": judgement,
        "raised_at": datetime.now(timezone.utc).isoformat(),
        "raised_by": "angel",
        "status": "awaiting_sam",
    }

    write_case_to_review_queue(case)
    return case
