"""
CLERK — writes the flat, factual record of what happened in a session.

Structural rules (do not weaken these when merging):
- The Clerk has NO action tools. It reads a finished session, writes a record.
- It never judges severity. It may record THAT something failed, as a fact.
- It gets its model from the router as "cheap" — it never names a model.
- It writes ONLY to its own table (oversight_records). It does not touch
  agent memory, lessons, or any other table.
"""

from datetime import datetime, timezone
from pathlib import Path

from .router_contract import get_model          # -> get_model("cheap")
from .store import write_record                 # -> INSERT into oversight_records

_PROMPT_PATH = Path(__file__).parent / "prompts" / "clerk_record.txt"


def record_session(session: dict) -> dict:
    """
    Called AFTER a session ends. `session` is the raw session data:
    {
      "session_id": str,
      "tenant_id": str,
      "agent": str,              # which agent ran (hub, builder, ...)
      "intent": str | None,      # Hub's stated intent, if it wrote one
      "transcript": list,        # raw messages / tool calls, in order
      "outcome": dict,           # what actually happened (side effects)
    }

    Returns the record it wrote.
    """
    model = get_model("cheap")

    # Placeholder logic — plumbing first, brains later. _PROMPT_PATH points
    # at the real summarisation prompt (prompts/clerk_record.txt), ready for
    # whenever this call is wired to actually invoke the model; until then
    # we store the facts verbatim so the pipe stays proven with real data.
    record = {
        "session_id": session["session_id"],
        "tenant_id": session["tenant_id"],
        "agent": session["agent"],
        "intent": session.get("intent"),
        "raw_transcript": session["transcript"],
        "outcome": session["outcome"],
        "summary": None,          # filled by the cheap model later
        "flag": None,             # later: "clean" | "suspicious" (optional lever)
        "written_at": datetime.now(timezone.utc).isoformat(),
        "written_by": "clerk",
    }

    write_record(record)
    return record
