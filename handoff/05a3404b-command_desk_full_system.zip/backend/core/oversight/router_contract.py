"""
ROUTER CONTRACT — the single swap point for brains.

Merge note for Dispatch: this file should end up as a thin wrapper around
the project's existing llm_router.py — do NOT build a second router. The
contract is just this: modules ask for a TIER, never a model name.

Tiers:
  "cheap"  -> the cheap/fast Claude model (Clerk, Checker's field extraction),
              or the Ollama model if that's the active provider
  "sharp"  -> the good model for judgement (Angel), or the Ollama model if
              that's the active provider

Flip what a tier points at in llm_router (env vars or its defaults) and
every module shifts at once. No model name is hardcoded here -- the actual
strings live in llm_router.py alongside its other model defaults.
"""

from ..llm_router import (
    get_provider,
    get_claude_cheap_model as _claude_cheap_model,
    get_claude_sharp_model as _claude_sharp_model,
    get_ollama_model as _ollama_model,
)

_TIERS = ("cheap", "sharp")


def get_model(tier: str) -> str:
    if tier not in _TIERS:
        raise ValueError(f"Unknown tier '{tier}' — use 'cheap' or 'sharp'")
    # Ollama has one model for every tier, same as before -- no regression
    # for an all-Ollama deployment. On the Claude path, cheap and sharp now
    # resolve independently.
    if get_provider() == 'ollama':
        return _ollama_model()
    if tier == 'sharp':
        return _claude_sharp_model()
    return _claude_cheap_model()
