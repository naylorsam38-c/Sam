"""
CHECKER — pure comparison. Hub said X should happen; did X happen?

Structural rules (do not weaken these when merging):
- Read-only on everything. Its only write is its own check result.
- No judgement, no severity, no opinion. Match / mismatch per field, done.
  Deciding whether a mismatch MATTERS is the Angel's job, not this one.
- Model from the router as "cheap". Never names a model.
- If the Hub wrote no intent, the Checker records exactly that — it does
  NOT guess what the intent probably was. A missing intent is a finding.
- If the intent was too vague to extract fields from, that is also a
  finding ("intent_too_vague"), not a pass.

The model is used ONLY to turn text into fields. The verdict itself is
deterministic Python in compare.py. See that file for why.
"""

from datetime import datetime, timezone

from .router_contract import get_model  # noqa: F401  (tier contract held)
from .store import write_check
from .field_extract import extract_fields, EMPTY
from .compare import compare, FIELDS
from .grounding import ground


def _outcome_fields(outcome, call_model) -> dict:
    """
    The outcome may already be structured (a dict from the tool that ran)
    or it may be free text. Structured wins — if the system already knows
    what it did, we don't ask a model to re-read it.
    """
    if isinstance(outcome, dict):
        known = {f: outcome.get(f) for f in FIELDS}
        if any(known.values()):
            return known
        text = outcome.get("summary") or outcome.get("text") or ""
        return extract_fields(text, call_model) if text else dict(EMPTY)

    if isinstance(outcome, str) and outcome.strip():
        return extract_fields(outcome, call_model)

    return dict(EMPTY)


def check_session(session: dict, call_model) -> dict:
    """
    Called after a session ends. Compares stated intent to actual outcome.

    session    — must contain session_id, tenant_id, intent, outcome,
                 and request_text (the user's original words, verbatim —
                 the ground truth the intent is checked against)
    call_model — injected callable (model_name, prompt) -> str
    """
    now = datetime.now(timezone.utc).isoformat()
    base = {
        "session_id": session["session_id"],
        "tenant_id": session["tenant_id"],
        "checked_at": now,
        "written_by": "checker",
    }

    intent = session.get("intent")

    if not intent or not str(intent).strip():
        result = {
            **base,
            "status": "no_intent_recorded",   # a finding in itself
            "matches": [],
            "mismatches": [],
            "unverifiable": [],
            "fabrications": [],
        }
        write_check(result)
        return result

    intent_fields = extract_fields(intent, call_model)

    # Grounding first. If the Hub invented a name, a number or a reference
    # that was never in the request, the intent itself is untrustworthy and
    # there is no point comparing an outcome against it.
    fabrications = ground(intent_fields, session.get("request_text", ""))
    if fabrications:
        result = {
            **base,
            "status": "intent_fabricated",
            "matches": [],
            "mismatches": [],
            "unverifiable": [],
            "fabrications": fabrications,
            "intent_fields": intent_fields,
        }
        write_check(result)
        return result

    outcome_fields = _outcome_fields(session.get("outcome", {}), call_model)

    result = {**base, **compare(intent_fields, outcome_fields)}
    result["fabrications"] = []

    # Kept for the Angel to read — it sees what was compared, not just the
    # verdict, so it can tell "wrong amount" from "couldn't read the intent".
    result["intent_fields"] = intent_fields
    result["outcome_fields"] = outcome_fields

    write_check(result)
    return result
