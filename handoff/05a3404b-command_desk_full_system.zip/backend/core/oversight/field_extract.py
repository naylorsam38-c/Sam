"""
FIELD EXTRACT — the ONE place a model is allowed to touch the check.

Its only job: turn free text into a fixed, small dict of fields. It does
not decide anything. It does not compare. It does not judge. If it cannot
find a field, it returns None for that field — it must never invent one.

Everything downstream (compare.py) is deterministic Python, so a bad
extraction shows up as an honest "unverifiable" or a visible mismatch,
not as a confident wrong verdict.

Structural rules held here:
- Model comes from the router as "cheap". No model is named in this file.
- Output is parsed strictly. Anything that isn't valid JSON with the
  expected keys returns all-None — a failed extraction is reported as a
  failed extraction, never patched over with a guess.
"""

import json
import re
from pathlib import Path

from .router_contract import get_model
from .compare import FIELDS

_PROMPT_PATH = Path(__file__).parent / "prompts" / "checker_extract.txt"

EMPTY = {f: None for f in FIELDS}


def _load_prompt() -> str:
    return _PROMPT_PATH.read_text(encoding="utf-8")


def _parse(raw: str) -> dict:
    """
    Strict parse. Small models like to wrap JSON in prose or code fences,
    so we pull the first JSON object out — but we do NOT try to repair
    malformed JSON. Unparseable means failed, and failed is reported.
    """
    if not raw:
        return dict(EMPTY)

    text = raw.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.MULTILINE).strip()

    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not match:
        return dict(EMPTY)

    try:
        data = json.loads(match.group(0))
    except (json.JSONDecodeError, ValueError):
        return dict(EMPTY)

    if not isinstance(data, dict):
        return dict(EMPTY)

    out = {}
    for field in FIELDS:
        value = data.get(field)
        if isinstance(value, (str, int, float)) and str(value).strip():
            # models emit these when they mean "I don't know" — treat as None
            candidate = str(value).strip()
            # Belt and braces against the example-leak failure: if the model
            # copies a placeholder straight out of the prompt, that is not a
            # value, it is a hallucination wearing a costume. Drop it.
            leaked = candidate.startswith("<") and candidate.endswith(">")
            if leaked or candidate.lower() in {
                "null", "none", "n/a", "unknown", "something", "-", "tbd",
            }:
                out[field] = None
            else:
                out[field] = str(value).strip()
        else:
            out[field] = None
    return out


def extract_fields(text: str, call_model) -> dict:
    """
    text       — the intent line, or the outcome description
    call_model — injected callable (model_name, prompt) -> str

    Injected rather than imported so this file has no path to any agent
    or router internals beyond asking for a tier, and so compare-level
    tests can run with no model at all.
    """
    if not text or not str(text).strip():
        return dict(EMPTY)

    model = get_model("cheap")
    prompt = _load_prompt().replace("{{TEXT}}", str(text).strip())

    try:
        raw = call_model(model, prompt)
    except Exception:
        # A model failure is an extraction failure. It is not a verdict.
        return dict(EMPTY)

    return _parse(raw)
