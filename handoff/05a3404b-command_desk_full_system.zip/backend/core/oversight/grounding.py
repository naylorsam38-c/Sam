"""
GROUNDING — catches invention. NO MODEL TOUCHES THIS FILE.

The problem this solves, found the hard way:

    Request: "chase up Acme about that invoice"
    Hub wrote: "send MARCH invoice to Acme Corp"

Nobody said March. The model produced a plausible specific instead of
leaving a gap, and it did it confidently. Prompt-tuning reduced it but
did not stop it — on a small local model, it is a capability ceiling.

So we stop asking the model to be honest and check it in code instead.

The insight: the user's own words are ground truth. They are the one
thing in the pipeline that cannot be hallucinated. Any concrete detail
in the intent that does not appear in the request was invented — and
that is a string comparison, not a judgement call.

WHAT IS GROUNDED, AND WHAT ISN'T:

    recipient, amount, reference   -> grounded strictly
    action                         -> NOT grounded

Action is exempt on purpose. "email the invoice" legitimately becomes
"send invoice" — paraphrasing a verb is the model doing its job. But
WHO, HOW MUCH and WHICH THING are the fields that hurt a real customer
when they're wrong, and there is no legitimate reason for a name, a
number or a document reference to appear in the intent if it never
appeared in the request.
"""

import re

# Fields where an ungrounded value is a fabrication, not a paraphrase.
GROUNDED_FIELDS = ("recipient", "amount", "reference")

# Function words only. Domain nouns like "invoice" and "quote" are
# DELIBERATELY not here — they are legitimate grounding evidence. If the
# user said "that invoice" and the agent said "the outstanding invoice",
# the word "invoice" traces, and that is enough.
_STOPWORDS = frozenset({
    "the", "a", "an", "that", "this", "to", "for", "of", "and", "or",
    "it", "in", "on", "at", "with", "from", "about", "please",
    "them", "their", "his", "her", "my", "our", "your", "is", "be",
})

# HARD TOKENS — the details that cost money when they're wrong.
# Every one of these in an intent must trace back to the request. No
# leniency, because these are exactly what the model invents: a month,
# a weekday, a figure. "March", "Thursday", "250".
_MONTHS = frozenset("""january february march april may june july august
september october november december jan feb mar apr jun jul aug sep sept
oct nov dec""".split())

_WEEKDAYS = frozenset("""monday tuesday wednesday thursday friday saturday
sunday mon tue tues wed thu thur thurs fri sat sun""".split())

_HARD = _MONTHS | _WEEKDAYS


def _hard_tokens(value: str) -> set[str]:
    """Dates and days. Treated as strictly as numbers."""
    return {t for t in _tokens(value) if t in _HARD}


def _tokens(text: str) -> set[str]:
    if not text:
        return set()
    raw = re.findall(r"[a-z0-9]+", str(text).lower())
    return {t for t in raw if t}


def _distinctive(value: str) -> set[str]:
    """The tokens in a value that actually carry meaning."""
    return {t for t in _tokens(value) if t not in _STOPWORDS}


def _number_tokens(value: str) -> set[str]:
    """Digits, normalised so 250.00 and 250 are the same token."""
    out = set()
    for n in re.findall(r"\d+(?:\.\d+)?", str(value)):
        n = n.rstrip("0").rstrip(".") if "." in n else n
        out.add(n)
    return out


def ground(intent_fields: dict, request_text: str) -> list[dict]:
    """
    Pure function. Returns a list of fabrication findings — empty means
    everything concrete in the intent traces back to the request.

    intent_fields — what the Hub said it would do
    request_text  — the user's original words, verbatim

    If request_text is missing we return no findings rather than
    accusing the model with no evidence. An ungroundable check is not
    a failed check; the Checker records that separately.
    """
    if not request_text or not str(request_text).strip():
        return []

    request = _tokens(request_text)
    request_numbers = _number_tokens(request_text)
    findings = []

    for field in GROUNDED_FIELDS:
        value = intent_fields.get(field)
        if value is None or not str(value).strip():
            continue

        # Numbers are absolute: a figure not in the request is invented,
        # full stop. This is the one that writes a wrong invoice.
        numbers = _number_tokens(value)
        ungrounded_numbers = numbers - request_numbers
        if ungrounded_numbers:
            findings.append({
                "field": field,
                "value": str(value),
                "invented": sorted(ungrounded_numbers),
                "reason": "number does not appear in the original request",
            })
            continue

        # Hard tokens next: a month or weekday in the intent that was
        # never in the request is invented, same standard as a number.
        # This is what catches "that invoice" -> "MARCH invoice" and
        # "next week" -> "THURSDAY".
        hard = _hard_tokens(value)
        ungrounded_hard = hard - _tokens(request_text)
        if ungrounded_hard:
            findings.append({
                "field": field,
                "value": str(value),
                "invented": sorted(ungrounded_hard),
                "reason": "date or day does not appear in the original request",
            })
            continue

        # Soft words last, and deliberately lenient: at least ONE token
        # must trace back. This tolerates "Acme" -> "Acme Corp" and
        # "that invoice" -> "the outstanding invoice".
        #
        # Being strict here was tested and rejected. It flagged the word
        # "outstanding" as a fabrication — technically true, practically
        # noise. A queue that cries about adjectives stops being read,
        # and then the real catches go unread with it. Hard tokens are
        # checked hard; describing words are not worth Sam's attention.
        words = _distinctive(value)
        if not words:
            continue
        if not (words & request):
            findings.append({
                "field": field,
                "value": str(value),
                "invented": sorted(words),
                "reason": "no part of this appears in the original request",
            })

    return findings
