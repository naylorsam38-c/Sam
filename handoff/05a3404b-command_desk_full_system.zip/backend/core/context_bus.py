def set_context(con, namespace, key, value):
    from .db import now
    con.execute('INSERT OR REPLACE INTO context VALUES (?,?,?,?)', (namespace,key,value,now())); con.commit()

def get_context(con, namespace, key, default=None):
    r=con.execute('SELECT value FROM context WHERE namespace=? AND key=?', (namespace,key)).fetchone()
    return r['value'] if r else default
