import uuid
from .db import now

def add_nudge(con, kind, text, due=None):
    nid=uuid.uuid4().hex
    con.execute('INSERT INTO nudges VALUES (?,?,?,?,?,0)', (nid, kind, text, now(), due))
    con.commit(); return nid

def pending(con, limit=3):
    return [dict(r) for r in con.execute('SELECT * FROM nudges WHERE done=0 ORDER BY created_at DESC LIMIT ?', (limit,)).fetchall()]

def maybe_learning_nudge(text: str):
    t=text.lower()
    if 'oauth' in t: return 'Learning gap: OAuth keeps coming up — do a 10-minute primer before the next build step.'
    if 'playwright' in t or 'test' in t: return 'Learning gap: testing workflow — code → test → fix → repeat until green.'
    if 'deploy' in t or 'tunnel' in t: return 'Learning gap: phone access needs local network or secure tunnel basics.'
    return None
