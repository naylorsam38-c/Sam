from .memory import memory_add, log_decision, related_decisions, recall
from .nudge_bus import add_nudge

def run_tool(con, name, **kw):
    if name == 'capture': return memory_add(con, kw['text'], {'type':'capture','slot':kw.get('slot','command')})
    if name == 'log_decision': return log_decision(con, kw['topic'], kw['decision'], kw.get('rationale',''), kw.get('alternatives',[]), kw.get('slot','command'))
    if name == 'recall': return recall(con, kw.get('query',''))
    if name == 'related_decisions': return related_decisions(con, kw.get('topic',''))
    if name == 'nudge': return add_nudge(con, kw.get('kind','followup'), kw['text'], kw.get('due'))
    raise ValueError(f'Unknown tool {name}')
