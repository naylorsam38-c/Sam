"""
VAULT -- Phase 1 memory backbone.

Two layers:
- worker_daily: each slot's own rolling window (MEMORY_WINDOW_DAYS, tunable
  via env, 3-5 days per Sam's locked spec) -- the ONLY context a worker
  carries by default. Deliberately lean; nothing else is auto-injected.
- vault_entries: the permanent long-term store. Entries age INTO it when a
  slot's rolling window overflows (immediate-on-overflow). Additive only --
  nothing here is ever deleted or overwritten once written, same discipline
  as the oversight tables.

The vault agent (consolidator, Ollama/llama3.2, pinned regardless of the
global provider) indexes and answers. It never reasons, decides, or
free-browses: vault_search() is a plain deterministic keyword scan (same
shape as memory.recall()) that narrows candidates; the model's only job is
to confirm/report on what was found, or say no.

No scheduler exists in this codebase (confirmed: no APScheduler/Celery, no
crontab, no systemd timer for the app). Daily rollup is triggered lazily --
opportunistically, the first time a slot is used after its previous day has
gone unsummarised -- not on a clock. Scheduled as a FastAPI BackgroundTask
from the /api/chat route so it never adds latency to a chat reply.
"""
from __future__ import annotations
import os, re, uuid
from datetime import datetime, timezone, timedelta
from .db import now
from .oversight.router_contract import get_model
from .llm_router import run as _llm_run

MEMORY_WINDOW_DAYS = int(os.getenv("MEMORY_WINDOW_DAYS", "4"))  # 3-5, tunable
VAULT_SLOT = "consolidator"

# Deterministic trigger, same idiom as the existing "note that/capture this"
# and "decision/decided" regexes already in orchestrator.handle_turn -- not
# an extra model call. Cost stays at zero until something actually matches;
# recall on unusual phrasing is the known tradeoff of this choice over an
# LLM-classified trigger, and is stated here rather than silently assumed.
VAULT_TRIGGER = re.compile(
    r"\b(have we|has anyone|did we already|has this come up|"
    r"seen this before|any history on|check if we|before i (?:reply|send|call|act)|"
    r"is there (?:any )?(?:history|record) (?:on|of|with))\b",
    re.I,
)


def _call_cheap_model(model_name: str, prompt: str) -> str:
    """Worker daily summaries: cheap Claude tier (haiku), same call shape as
    clerk/checker's injected call_model."""
    raw = _llm_run("memory", "", [{"role": "user", "content": prompt}], model=model_name)
    return raw.get("content", "") if isinstance(raw, dict) else str(raw)


def _call_vault_model(model_name: str, prompt: str) -> str:
    """The vault always runs on Ollama/llama3.2, pinned regardless of the
    global LLM_PROVIDER -- matches consolidator's own slot config, and free,
    per Sam's explicit cost requirement. model_name is accepted (not used)
    only to keep the same two-arg call_model shape used everywhere else."""
    raw = _llm_run("consolidator", "", [{"role": "user", "content": prompt}], model="llama3.2", provider="ollama")
    return raw.get("content", "") if isinstance(raw, dict) else str(raw)


def _today() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def _yesterday() -> str:
    return (datetime.now(timezone.utc).date() - timedelta(days=1)).isoformat()


def summarize_day(con, slot: str, day: str, call_model=_call_cheap_model) -> str | None:
    """Summarise one slot's transcript for one completed day. Returns None if
    the slot was silent that day -- nothing to summarise, nothing written."""
    rows = con.execute(
        "SELECT role, content FROM transcript WHERE slot=? AND date(ts)=? ORDER BY ts",
        (slot, day),
    ).fetchall()
    if not rows:
        return None
    transcript_text = "\n".join(f"{r['role']}: {r['content']}" for r in rows)[:6000]
    prompt = (
        f"Summarise this one day of work by the '{slot}' agent in 3-6 short, factual "
        "sentences: what came in, what was done, what's left open. No opinions, no "
        "invented detail beyond what's below.\n\n" + transcript_text
    )
    model = get_model("cheap")
    summary = call_model(model, prompt)
    return summary.strip() if summary else None


def roll_worker_daily(con, slot: str, call_model=_call_cheap_model):
    """Opportunistic daily rollup -- called after a turn, as a background
    task. If slot's previous day isn't in worker_daily yet, summarise it and
    write it; then age-overflow the window immediately if it now exceeds
    MEMORY_WINDOW_DAYS. Safe to call repeatedly (UNIQUE(slot,day) + the
    already-rolled check make it a no-op once a day is done)."""
    if slot == VAULT_SLOT:
        return  # the vault doesn't keep a rolling window on itself
    y = _yesterday()
    already = con.execute(
        "SELECT 1 FROM worker_daily WHERE slot=? AND day=?", (slot, y)
    ).fetchone()
    if already:
        return
    summary = summarize_day(con, slot, y, call_model)
    if summary is None:
        return
    count = con.execute(
        "SELECT COUNT(*) c FROM transcript WHERE slot=? AND date(ts)=?", (slot, y)
    ).fetchone()["c"]
    con.execute(
        "INSERT OR IGNORE INTO worker_daily (id, slot, day, summary, message_count, created_at) "
        "VALUES (?,?,?,?,?,?)",
        (uuid.uuid4().hex, slot, y, summary, count, now()),
    )
    con.commit()
    _age_overflow(con, slot)


def _age_overflow(con, slot: str):
    """Immediate-on-overflow: the moment a slot's rolling window exceeds
    MEMORY_WINDOW_DAYS, the oldest entries move into the permanent vault.
    vault_entries is insert-only; worker_daily rows are removed only here,
    only after their content is safely archived first."""
    rows = con.execute(
        "SELECT id, day, summary FROM worker_daily WHERE slot=? ORDER BY day DESC",
        (slot,),
    ).fetchall()
    overflow = rows[MEMORY_WINDOW_DAYS:]
    for r in overflow:
        con.execute(
            "INSERT INTO vault_entries (id, slot, day, summary, archived_at) VALUES (?,?,?,?,?)",
            (uuid.uuid4().hex, slot, r["day"], r["summary"], now()),
        )
        con.execute("DELETE FROM worker_daily WHERE id=?", (r["id"],))
    if overflow:
        con.commit()


def worker_context(con, slot: str) -> list[dict]:
    """The rolling window -- the ONLY context a worker carries by default.
    Deliberately lean: just the last MEMORY_WINDOW_DAYS summaries."""
    rows = con.execute(
        "SELECT day, summary FROM worker_daily WHERE slot=? ORDER BY day DESC LIMIT ?",
        (slot, MEMORY_WINDOW_DAYS),
    ).fetchall()
    return [dict(r) for r in rows]


def vault_search(con, query: str, name: str | None = None, slot: str | None = None, limit: int = 8) -> list[dict]:
    """Deterministic keyword-scored scan over the permanent vault -- same
    scoring shape as memory.recall(). This is what actually narrows
    candidates; the model's job stays confirm-only."""
    words = {w.lower() for w in re.findall(r"[a-zA-Z0-9_]+", query) if len(w) > 2}
    if name:
        words.add(name.lower())
    q = "SELECT * FROM vault_entries"
    params: list = []
    if slot:
        q += " WHERE slot=?"
        params.append(slot)
    q += " ORDER BY day DESC"
    rows = con.execute(q, params).fetchall()
    ranked = []
    for r in rows:
        txt = r["summary"] or ""
        score = sum(1 for w in words if w in txt.lower())
        if score or not words:
            ranked.append((score, dict(r)))
    return [r for _, r in sorted(ranked, key=lambda x: x[0], reverse=True)[:limit]]


def vault_answer(con, query: str, name: str | None = None, call_model=_call_vault_model) -> dict:
    """The vault's one job: 'seen this before?' Deterministic search narrows
    candidates; the Ollama/llama3.2 vault agent only confirms/reports on what
    was found -- matching evidence, or a clean no. Never guesses, never
    free-browses past the shortlist it was actually handed."""
    candidates = vault_search(con, query, name=name)
    if not candidates:
        return {"found": False, "answer": "No.", "evidence": []}
    material = "\n".join(f"- [{c['day']}, {c['slot']}] {c['summary']}" for c in candidates)
    prompt = (
        "You are the long-term vault. Below are archived daily summaries that matched a "
        f'search for: "{query}". Do not reason, advise, or add anything not present below. '
        "If any entry genuinely answers the query, report it plainly (quote or closely "
        "paraphrase it). If none of them actually answer it, reply with exactly: No.\n\n"
        + material
    )
    answer = call_model("llama3.2", prompt)
    found = bool(answer) and answer.strip().rstrip(".").lower() != "no"
    return {"found": found, "answer": (answer or "").strip(), "evidence": candidates}


def vault_already_queried(con, session_id: str, subject: str) -> bool:
    """Session-scoped dedup so the same subject isn't queried twice in one
    session. Lives in its own vault_queries table rather than the shared
    sessions.state JSON blob: continuity.update_state() overwrites that whole
    blob on every turn regardless of slot/subject, so anything stored there
    would be wiped by the very next turn -- not just a same-turn ordering
    issue. A dedicated table has no such dependency."""
    subject_l = subject.strip().lower()
    rows = con.execute(
        "SELECT subject FROM vault_queries WHERE session_id=?", (session_id,)
    ).fetchall()
    return any(subject_l in r["subject"] or r["subject"] in subject_l for r in rows)


def mark_vault_queried(con, session_id: str, subject: str):
    con.execute(
        "INSERT INTO vault_queries (id, session_id, subject, queried_at) VALUES (?,?,?,?)",
        (uuid.uuid4().hex, session_id, subject.strip().lower()[:200], now()),
    )
    con.commit()
