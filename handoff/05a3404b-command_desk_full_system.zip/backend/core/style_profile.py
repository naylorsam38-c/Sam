from __future__ import annotations
import json, re, uuid
from pathlib import Path
from .db import now
from .llm_router import run as _llm_run
from .audit_log import log as audit

# ── Style profile ──────────────────────────────────────────────────────────
# Stage 4: reads Sam's past SENT mail ONCE (on first connect / on demand,
# never automatically on a schedule -- there is no scheduler in this
# codebase) and writes a persistent per-context communication profile that
# the drafting step later CONSUMES. This module never drafts anything and
# the drafting step never infers style itself -- the profile is the only
# bridge between the two. Buildable and provable right now: it only needs
# the gmail.readonly scope Stage 2 already granted.

BASE_DIR = Path(__file__).resolve().parents[1]
TOKEN_PATH = BASE_DIR / 'google_token.json'

# Sam's own stated defaults, used only when there's no usable sent history
# to learn from at all -- flagged is_temporary so the drafting step (and
# Sam, when shown the profile) both know this is a placeholder, not
# something learned from his actual writing.
DEFAULT_PROFILES = {
    'mates': {
        'tone': 'very informal, casual',
        'structure': 'short, no fixed structure, minimal greeting/sign-off',
        'vocabulary': 'slang okay, contractions, casual punctuation',
        'formality': 'low',
        'notes': 'placeholder -- no learned history yet',
    },
    'work': {
        'tone': 'formal, clean, professional',
        'structure': 'clear greeting, structured body, professional sign-off',
        'vocabulary': 'precise, no slang, complete sentences',
        'formality': 'high',
        'notes': 'placeholder -- no learned history yet',
    },
}

# Skip noise before any of it reaches the model: auto-replies, forwards,
# and anything too short to say anything about Sam's actual writing style.
_NOISE_PATTERNS = re.compile(
    r'\b(out of office|automatic reply|auto-reply|automatically generated|'
    r'undeliverable|delivery status notification)\b', re.I
)
_MIN_BODY_LEN = 15  # shorter than this carries no real style signal (one-word replies, "ok", "thanks!")


def _fetch_sent_messages(max_results=50) -> list[dict]:
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request as GoogleAuthRequest
    from googleapiclient.discovery import build

    creds = Credentials.from_authorized_user_file(str(TOKEN_PATH))
    if creds.expired and creds.refresh_token:
        creds.refresh(GoogleAuthRequest())
        TOKEN_PATH.write_text(creds.to_json(), encoding='utf-8')

    service = build('gmail', 'v1', credentials=creds)
    resp = service.users().messages().list(userId='me', labelIds=['SENT'], maxResults=max_results).execute()
    messages = []
    for m in resp.get('messages', []):
        msg = service.users().messages().get(userId='me', id=m['id'], format='full').execute()
        messages.append(msg)
    return messages


def _extract_text(message: dict) -> str:
    """Pull the plain-text body out of a Gmail message resource, walking a
    multipart payload for the first text/plain part. Falls back to the
    snippet (still workable for the noise filter and analysis) if no
    plain-text part is found."""
    import base64
    payload = message.get('payload', {})

    def _walk(part):
        if part.get('mimeType') == 'text/plain' and part.get('body', {}).get('data'):
            return base64.urlsafe_b64decode(part['body']['data']).decode('utf-8', errors='replace')
        for sub in part.get('parts', []) or []:
            found = _walk(sub)
            if found:
                return found
        return None

    return _walk(payload) or message.get('snippet', '')


def _is_noise(headers: dict, body: str) -> bool:
    subject = headers.get('Subject', '')
    if _NOISE_PATTERNS.search(subject) or _NOISE_PATTERNS.search(body[:500]):
        return True
    if subject.strip().lower().startswith(('fwd:', 'fw:')):
        return True
    stripped = body.strip()
    if len(stripped) < _MIN_BODY_LEN:
        return True
    # Signature-only heuristic: cut at a common signature marker and see if
    # anything real is left before it.
    sig_stripped = re.split(r'\n--\s*\n|\nSent from my ', stripped, maxsplit=1)[0].strip()
    return len(sig_stripped) < _MIN_BODY_LEN


def _context_key_for(to_addr: str) -> str:
    """First-pass bucketing: a recognisable personal free-mail domain reads
    as 'mates', everything else as 'work'. Coarse on purpose -- refining to
    genuinely per-recipient profiles is future work once there's enough
    sent history per individual contact to say something specific."""
    personal_domains = ('gmail.com', 'hotmail.com', 'yahoo.com', 'outlook.com', 'icloud.com')
    match = re.search(r'@([\w.-]+)', to_addr or '')
    domain = match.group(1).lower() if match else ''
    return 'mates' if domain in personal_domains else 'work'


def _call_brain(prompt: str) -> str:
    """The BRAIN, not the cheap model -- Sam's explicit requirement, since
    this shapes every drafted email going forward. Pinned to Sonnet
    regardless of the global provider/model default."""
    raw = _llm_run('style_profile', '', [{'role': 'user', 'content': prompt}],
                    model='claude-sonnet-5', provider='claude')
    return raw.get('content', '') if isinstance(raw, dict) else str(raw)


def _analyze_samples(context_key: str, samples: list[str], call_model) -> dict:
    joined = '\n\n---\n\n'.join(samples[:15])[:8000]
    prompt = (
        f"Below are {len(samples)} real emails Sam actually sent in the '{context_key}' context. "
        "Analyse ONLY what is actually present in them -- do not invent or generalise beyond the "
        "evidence. Produce a JSON object with exactly these keys: tone, structure, vocabulary, "
        "formality, notes. Each should be a short, concrete description of how Sam actually writes "
        "in this context, not generic advice.\n\n"
        "Reply with EXACTLY one JSON object and nothing else.\n\n" + joined
    )
    raw = call_model(prompt)
    match = re.search(r'\{.*\}', raw, re.S)
    if not match:
        return {'tone': 'unknown', 'structure': 'unknown', 'vocabulary': 'unknown', 'formality': 'unknown',
                'notes': 'model reply was not parseable', 'sample_count': len(samples)}
    try:
        parsed = json.loads(match.group(0))
    except json.JSONDecodeError:
        return {'tone': 'unknown', 'structure': 'unknown', 'vocabulary': 'unknown', 'formality': 'unknown',
                'notes': 'model reply was not valid JSON', 'sample_count': len(samples)}
    parsed['sample_count'] = len(samples)
    return parsed


def _write_profile(con, context_key: str, profile: dict, is_temporary: bool):
    existing = con.execute('SELECT id FROM style_profiles WHERE context_key=?', (context_key,)).fetchone()
    ts = now()
    if existing:
        con.execute(
            'UPDATE style_profiles SET profile_json=?, is_temporary=?, updated_at=? WHERE context_key=?',
            (json.dumps(profile), int(is_temporary), ts, context_key)
        )
    else:
        con.execute(
            'INSERT INTO style_profiles (id, context_key, profile_json, is_temporary, created_at, updated_at) '
            'VALUES (?,?,?,?,?,?)',
            (uuid.uuid4().hex, context_key, json.dumps(profile), int(is_temporary), ts, ts)
        )
    con.commit()


def get_style_profile(con, context_key: str) -> dict | None:
    """What the drafting step calls -- it consumes this, it never infers
    style itself. Returns None only if build_style_profile has genuinely
    never run (not even the default placeholders written yet)."""
    row = con.execute('SELECT profile_json, is_temporary FROM style_profiles WHERE context_key=?', (context_key,)).fetchone()
    if not row:
        return None
    profile = json.loads(row['profile_json'])
    profile['is_temporary'] = bool(row['is_temporary'])
    return profile


def build_style_profile(con, max_results: int = 50, call_model=None, fetch_messages=None) -> dict:
    """Reads Sam's past SENT mail ONCE and writes a persistent per-context
    profile. Never runs automatically -- called on first connect or on
    demand only. fetch_messages/call_model are injectable purely for
    isolated testing (default to the real Gmail call and the real brain)."""
    call_model = call_model or _call_brain
    fetch_messages = fetch_messages or _fetch_sent_messages

    try:
        messages = fetch_messages(max_results)
    except Exception as e:
        audit(con, 'style_profile', 'build_style_profile', '', 'error', str(e)[:500])
        return {'ok': False, 'error': str(e)}

    buckets: dict[str, list[str]] = {}
    kept = 0
    for msg in messages:
        headers = {h['name']: h['value'] for h in msg.get('payload', {}).get('headers', [])}
        body = _extract_text(msg)
        if _is_noise(headers, body):
            continue
        key = _context_key_for(headers.get('To', ''))
        buckets.setdefault(key, []).append(body[:2000])
        kept += 1

    if kept == 0:
        for key, profile in DEFAULT_PROFILES.items():
            _write_profile(con, key, profile, is_temporary=True)
        audit(con, 'style_profile', 'build_style_profile', f'scanned={len(messages)}', 'default_placeholder',
              'no usable sent history at all after noise filtering -- wrote default mates/work placeholders')
        return {'ok': True, 'source': 'default_placeholder', 'contexts': dict(DEFAULT_PROFILES)}

    results = {}
    for key, samples in buckets.items():
        profile = _analyze_samples(key, samples, call_model)
        _write_profile(con, key, profile, is_temporary=False)
        results[key] = profile

    # A known context (mates/work) with zero qualifying samples THIS round
    # still gets its own default placeholder, flagged temporary -- real
    # history existing for the OTHER context doesn't mean this one should be
    # left with nothing for the drafting step to consume. Never overwrites
    # an already-learned (non-temporary) profile for that context.
    for key, default_profile in DEFAULT_PROFILES.items():
        if key not in results:
            existing = get_style_profile(con, key)
            if existing and not existing.get('is_temporary'):
                continue
            _write_profile(con, key, default_profile, is_temporary=True)
            results[key] = {**default_profile, 'is_temporary': True}

    audit(con, 'style_profile', 'build_style_profile', f'scanned={len(messages)} kept={kept}', 'ok',
          json.dumps({'contexts': {k: v.get('is_temporary', False) for k, v in results.items()}}))
    return {'ok': True, 'source': 'real_sent_mail', 'contexts': results}
