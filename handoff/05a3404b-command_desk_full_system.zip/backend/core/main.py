from __future__ import annotations
import os, json
from fastapi import FastAPI, HTTPException, BackgroundTasks, Cookie, Depends, Response, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import uvicorn
from .dotenv_loader import load_dotenv
load_dotenv()
from .db import init_db, connect, normalize_quotes
from .continuity import resume_line, open_session, close_session
from .orchestrator import handle_turn, SLOTS, SLOT_CONFIG, DEFAULT_SLOT, reload_slots, handle_group_message, handle_group_close
from .groups import create_group, list_groups, get_group, group_members as get_group_member_ids, get_group_transcript
from .memory import memory_add, recall, log_decision, related_decisions
from .nudge_bus import pending, add_nudge
from .agents import (create_template, list_templates, get_template, spawn_instance,
                      list_instances, get_instance, stop_instance, delete_instance,
                      is_active_instance)
from .tools import (create_tool, list_tools, get_tool, get_tool_public, update_tool,
                     set_credential, delete_tool)
from .oversight.clerk import record_session
from .oversight.checker import check_session
from .oversight.angel import judge_session
from .llm_router import run as _llm_run
from .vault import roll_worker_daily, vault_search, vault_answer, VAULT_SLOT, _call_cheap_model
from .auth import (seed_default_user, is_locked_out, record_attempt, verify_login,
                    create_session as create_auth_session, validate_session, invalidate_session)
from .voice_state import (transition as voice_transition, get_state as voice_get_state,
                           get_brain_mode as voice_get_brain_mode, WAKE_TRIGGER, SLEEP_TRIGGER)
from .google_oauth import (start_flow as google_start_flow, complete_flow as google_complete_flow,
                            render_success_page as google_success_page, render_error_page as google_error_page)
from .router import route as router_route
from .audit_log import log as audit_log_write
from .permission_layer import (check_and_expire_confirmation, handle_confirmation_reply,
                                confirm_send_not_received, find_in_flight_send, NOT_RECEIVED_TRIGGER)
from .style_profile import build_style_profile, get_style_profile

# The legacy plain-HTML/JS frontend (frontend/) has been retired -- the
# Flutter app is the only product now. No route serves it; the directory
# itself is deleted so it can't be hit by accident or re-mounted later.
con = init_db(connect())
seed_default_user(con)

# This SQLite app has no multi-tenant concept yet (tenant_id belongs to the
# separate future Postgres/RLS schema) -- oversight's own tables want one
# for later parity, so every row gets this single constant for now.
OVERSIGHT_TENANT_ID = 'default'

def call_model(model_name, prompt):
    """Thin adapter so no oversight module reaches into the router or any
    agent directly: a single free-text prompt in, a plain string out. When
    the active provider is Ollama, llm_router's own Ollama path ignores the
    model argument and always uses whichever OLLAMA_MODEL is configured --
    same characteristic router_contract.py already has for its tiers."""
    raw = _llm_run('oversight', '', [{'role': 'user', 'content': prompt}], model=model_name)
    return raw.get('content', '') if isinstance(raw, dict) else str(raw)

def run_oversight_pipeline(con, session_id):
    """Called when a session ends: clerk records the raw facts, checker
    compares intent vs outcome (grounding intent against the paired
    request_text first), angel reads the raw record + check and raises a
    case only when the threshold in angel.RAISE_ON is met."""
    srow = con.execute('SELECT * FROM sessions WHERE id=?', (session_id,)).fetchone()
    if srow is None:
        return
    transcript = [dict(r) for r in con.execute(
        'SELECT role, content, ts FROM transcript WHERE session_id=? ORDER BY ts', (session_id,)
    ).fetchall()]
    state = json.loads(srow['state']) if srow['state'] else {}
    session = {
        'session_id': session_id,
        'tenant_id': OVERSIGHT_TENANT_ID,
        'agent': srow['slot'],
        'intent': state.get('intent'),  # real value if Hub stated one this session, else None
        # Paired with intent at the exact moment it was written (write_intent);
        # never reconstructed from transcript history, so a later intent-less
        # turn (e.g. "thanks, how's it going") can't get mismatched against it.
        'request_text': state.get('intent_request_text'),
        'transcript': transcript,
        'outcome': {'message_count': len(transcript)},
    }
    record_session(session)
    check = check_session(session, call_model)
    judge_session(session_id, OVERSIGHT_TENANT_ID, check, call_model)
app = FastAPI(title='Command Desk', version='1.0.0')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*'],
)

class Turn(BaseModel):
    text: str
    slot: str | None = None
    session_id: str | None = None
class Capture(BaseModel):
    text: str
    kind: str = 'knowledge'
    slot: str = DEFAULT_SLOT
class Decision(BaseModel):
    topic: str; decision: str; rationale: str = ''; alternatives: list[str] = []; slot: str = DEFAULT_SLOT
class Nudge(BaseModel):
    kind: str='followup'; text: str; due: str|None=None
class AgentTemplateIn(BaseModel):
    name: str; system_prompt: str; model: str|None=None; tools: list[str]=[]; accent_color: str='#888888'
class SpawnIn(BaseModel):
    template_id: str; name: str|None=None
class GroupIn(BaseModel):
    name: str; members: list[str]
class GroupMessageIn(BaseModel):
    text: str; speaker: str|None=None; mention: str|None=None
class GroupCloseIn(BaseModel):
    shared_with_hub: bool = False
class ToolIn(BaseModel):
    tool_type: str; label: str; kind: str = 'conversational'; config: dict = {}
    needs_credential: bool = True
class ToolUpdateIn(BaseModel):
    label: str | None = None; config: dict | None = None
class ToolCredentialIn(BaseModel):
    # Deliberately only a token/API-key field -- there is no password field on
    # this model, by design, so the backend has no path to receive one. The
    # client is expected to obtain `credential` itself (a completed OAuth
    # token, or a provider-issued API key) before calling this route.
    credential: str
    credential_type: str  # 'oauth_token' | 'api_key'
class LoginIn(BaseModel):
    username: str
    password: str
class NovaTurnIn(BaseModel):
    text: str
class RouterIn(BaseModel):
    text: str


def require_auth(session_id: str | None = Cookie(default=None)) -> str:
    """The real gate: every Stage 1 voice-flow route depends on this. A
    request with no cookie, or a cookie that doesn't match a currently
    authenticated session, is refused with 401 -- regardless of what the
    frontend happens to be showing."""
    if not validate_session(con, session_id):
        raise HTTPException(401, 'Not authenticated')
    return session_id

@app.get('/api/health')
def health(): return {'ok': True, 'slots': SLOTS}
@app.get('/api/slots')
def slots():
    # Slot list and metadata come straight from core/slots_config.json --
    # the single source of truth. Add/remove a slot there, no code changes.
    return [SLOT_CONFIG[sid] for sid in SLOTS]
@app.post('/api/slots/reload')
def slots_reload():
    """Re-read core/slots_config.json without restarting the server."""
    return {'slots': reload_slots()}
@app.get('/api/resume')
def resume(): return {'resume': resume_line(con)}
@app.post('/api/session/new/{slot}')
def new_session(slot: str):
    if slot not in SLOTS and not is_active_instance(con, slot): raise HTTPException(400,'Unknown slot')
    return {'session_id': open_session(con, slot)}
@app.post('/api/session/{session_id}/close')
def close(session_id: str):
    close_session(con, session_id)
    run_oversight_pipeline(con, session_id)
    return {'ok':True}

# ── Stage 1 identity gate + voice state machine ──
# Login IS session creation: a successful login opens/resumes the real
# `sessions` row (slot='nova_voice') and marks that same session_id as
# authenticated in auth_sessions. Every route below that a logged-out
# visitor must not reach depends on require_auth, which checks the actual
# cookie against auth_sessions -- not anything the frontend claims.
@app.post('/api/auth/login')
def auth_login(body: LoginIn, response: Response, request: Request):
    username = body.username.strip()
    client_ip = request.client.host if request.client else None
    if is_locked_out(con, username):
        record_attempt(con, username, False, client_ip)
        raise HTTPException(429, 'Too many failed attempts. Try again in a few minutes.')
    ok = verify_login(con, username, body.password)
    record_attempt(con, username, ok, client_ip)
    if not ok:
        raise HTTPException(401, 'Invalid username or password.')
    session_id = create_auth_session(con, username)
    response.set_cookie(
        key='session_id', value=session_id,
        # Stage 2 note: this was `samesite='strict'` in Stage 1. Google's
        # OAuth redirect back to our callback is a cross-site top-level GET
        # navigation (the browser arrives here FROM accounts.google.com) --
        # a Strict cookie is withheld on exactly that kind of request, which
        # would silently 401 the callback and break the whole consent flow.
        # Lax still blocks the cookie on cross-site POST/state-changing
        # requests (real CSRF protection intact) and only allows it on
        # top-level GET navigations like this one -- the standard, expected
        # setting for a session cookie that has to survive an OAuth
        # redirect. The oauth_states table adds its own independent
        # state-binding check on top, so this isn't the only protection.
        httponly=True, secure=True, samesite='lax', path='/'
    )
    return {'ok': True}
@app.get('/api/auth/whoami')
def auth_whoami(session_id: str = Depends(require_auth)):
    return {'authenticated': True}
@app.post('/api/auth/logout')
def auth_logout(response: Response, session_id: str | None = Cookie(default=None)):
    if session_id:
        invalidate_session(con, session_id)
    response.delete_cookie('session_id', path='/')
    return {'ok': True}

# ── Stage 2: Gmail OAuth capture only. Nothing here reads mail -- that's
# Stage 3, behind its own permission layer.
#
# The gate genuinely belongs on /oauth/start: only an authenticated Sam
# session can mint a `state`. The callback does NOT also require the
# cookie -- Google's redirect can land in a browser context that never had
# it (an in-app webview is exactly this case, and is what broke Sam's first
# real attempt: separate cookie jar, session cookie never sent). The actual
# security property is `state` itself -- a single-use, ~178-bit random
# value that only ever existed because start_flow() was called from an
# authenticated session. complete_flow() reads the session_id back out of
# the oauth_states row it's bound to, not from anything this request
# claims, and independently confirms that session is still valid before
# doing anything.
#
# Path note: the registered redirect_uri is EXACTLY
# https://airexploit.com/commanddesk/oauth/callback -- Google rejects
# anything that doesn't match verbatim. nginx maps /commanddesk/oauth/ to
# /api/oauth/ here, so the callback route below has to be /api/oauth/callback
# (no extra segment), not /api/oauth/google/callback.
#
# The callback is reached by a full-page browser redirect from Google, in
# whatever webview Sam happens to be using -- it must render a page a human
# can read, not a raw JSON blob.
@app.get('/api/oauth/start')
def oauth_google_start(session_id: str = Depends(require_auth)):
    return {'consent_url': google_start_flow(con, session_id)}
@app.get('/api/oauth/callback', response_class=HTMLResponse)
def oauth_google_callback(code: str, state: str):
    try:
        google_complete_flow(con, state, code)
    except ValueError as e:
        return HTMLResponse(google_error_page(str(e)), status_code=400)
    except Exception:
        return HTMLResponse(google_error_page(
            "Something unexpected went wrong completing the connection. Ask Command Desk for a fresh consent link."
        ), status_code=502)
    return HTMLResponse(google_success_page())

@app.post('/api/nova/listening')
def nova_listening(session_id: str = Depends(require_auth)):
    t = voice_transition(con, session_id, 'listening', trigger='mic_press')
    return {'state': 'listening', 'transition': t}
@app.get('/api/nova/state')
def nova_state(session_id: str = Depends(require_auth)):
    return {'state': voice_get_state(con, session_id)}

# ── Stage 4: style profile -- built on demand from Sam's real Sent mail,
# never automatically. Gated: only an authenticated session can trigger a
# rebuild or read a profile back. The design is "show Sam the profile once
# for confirm/correct" -- these routes are what that surface calls. ──
@app.post('/api/style_profile/build')
def style_profile_build(session_id: str = Depends(require_auth)):
    return build_style_profile(con)
@app.get('/api/style_profile/{context_key}')
def style_profile_get(context_key: str, session_id: str = Depends(require_auth)):
    profile = get_style_profile(con, context_key)
    if not profile:
        raise HTTPException(404, 'No profile built yet for this context.')
    return profile

@app.post('/api/router/route')
def router_route_endpoint(body: RouterIn):
    """Direct inspection of the router in isolation -- its own separate
    piece, callable on its own, not just as a side effect of a nova/turn
    call. Returns the same {worker, confidence, status, reason[, ask]}
    shape nova_turn uses internally to decide whether to delegate."""
    if not body.text.strip():
        raise HTTPException(400, 'text is required')
    return router_route(con, body.text)

@app.post('/api/nova/turn')
def nova_turn(body: NovaTurnIn, background_tasks: BackgroundTasks, session_id: str = Depends(require_auth)):
    if not body.text.strip():
        voice_transition(con, session_id, 'idle', trigger='empty_transcript', result='rejected')
        raise HTTPException(400, 'Empty message')

    # Matched against a smart-quote-normalized copy only -- body.text itself
    # (stored, sent to the router/LLM) stays exactly as Sam typed it.
    matched_text = normalize_quotes(body.text)

    # Stage 4: "it didn't send" is Sam's own explicit, out-of-band recovery
    # phrase -- checked before anything else, regardless of current_state
    # (by the time Sam says this, the state machine has usually already
    # moved back to idle after the send timeout; what's still stuck is the
    # actions-table row, not the visible state). This is the ONLY other way
    # an in_flight send action ever clears. Checked before the 'processing'
    # transition below since it never needs it.
    if NOT_RECEIVED_TRIGGER.search(matched_text):
        stuck_action_id = find_in_flight_send(con, session_id)
        if stuck_action_id:
            confirm_send_not_received(con, stuck_action_id)
            voice_transition(con, session_id, 'idle', trigger='sam_confirmed_not_sent', result=stuck_action_id)
            return {'reply': "Got it -- marking that as not sent. Ask me to send a fresh one whenever you're ready.",
                    'session_id': session_id}
        return {'reply': "I don't have anything stuck mid-send right now.", 'session_id': session_id}

    # Stage 4: a draft awaiting confirmation is answered directly here --
    # never routed anywhere. Captured BEFORE the 'processing' transition
    # below, which would otherwise overwrite 'awaiting_confirmation' on
    # this exact same request and make this check never fire -- that was a
    # real bug caught during Stage 4 verification, not a hypothetical one.
    # First check the lazy 120s expiry (no scheduler exists in this
    # codebase; enforced on the next real interaction, same idiom as the
    # Phase 1 daily rollup); if it just expired, fall through to normal
    # routing for whatever Sam actually said. Otherwise the reply IS the
    # confirmation-flow outcome -- yes, change, or a re-ask -- and nothing
    # else runs this turn.
    state_before_this_turn = voice_get_state(con, session_id)
    if state_before_this_turn == 'awaiting_confirmation':
        if not check_and_expire_confirmation(con, session_id):
            outcome = handle_confirmation_reply(con, session_id, body.text)
            background_tasks.add_task(run_oversight_pipeline, con, session_id)
            return outcome

    voice_transition(con, session_id, 'processing', trigger='stt_final_transcript', result=body.text[:120])

    # Stage 3: a wake/sleep phrase is a control word directed at Nova
    # itself, not a task for any worker -- it must never be handed to the
    # router (which would happily delegate "go deep on this: <a real
    # question>" to Research just because the question part looks like a
    # research request, so the wake trigger -- scoped to slot=='nova_voice'
    # in handle_turn -- would never even run). Checking it first and
    # forcing nova_voice keeps Sam's switch entirely his own, independent
    # of whatever the router would otherwise have picked.
    if WAKE_TRIGGER.search(matched_text) or SLEEP_TRIGGER.search(matched_text):
        decision = {'worker': 'nova_voice', 'confidence': 100, 'status': 'routed', 'reason': 'wake/sleep control word'}
        audit_log_write(con, 'router', 'route', body.text, 'bypassed',
                         'wake/sleep control word -- routed directly to nova_voice without calling the router')
    else:
        # Router decides which worker handles this turn. nova_voice itself
        # is one of its own choices (plain conversation, no delegation) so
        # ordinary chat is unaffected; a genuine tie between two OTHER
        # workers comes back as 'ambiguous' and is surfaced to Sam rather
        # than guessed. A router-level failure (e.g. Ollama unreachable)
        # falls back to nova_voice rather than blocking the turn -- the new
        # piece failing must not make the existing, already-verified
        # conversation path worse than it was before this stage.
        decision = router_route(con, body.text)
    if decision['status'] == 'ambiguous':
        voice_transition(con, session_id, 'idle', trigger='router_ambiguous', result=decision.get('reason', '')[:120])
        return {'reply': decision['ask'], 'session_id': session_id, 'router': decision}
    target_slot = decision['worker'] if decision['status'] == 'routed' else 'nova_voice'

    try:
        result = handle_turn(con, body.text, target_slot, session_id)
    except ValueError as e:
        voice_transition(con, session_id, 'idle', trigger='error', result=str(e)[:120])
        raise HTTPException(400, str(e))
    background_tasks.add_task(run_oversight_pipeline, con, result['session_id'])
    # handle_turn may have called into the permission layer and left the
    # state machine at 'awaiting_confirmation' (a draft was just created
    # and IS waiting on Sam) -- unconditionally forcing 'idle' here would
    # immediately stomp that back out from under the confirmation gate at
    # the top of this function, the same class of bug as the earlier
    # 'processing' clobber caught during Stage 4 verification. Only
    # normalize back to idle when the turn didn't leave something else
    # pending.
    if voice_get_state(con, session_id) != 'awaiting_confirmation':
        voice_transition(con, session_id, 'idle', trigger='reply_received', result='ok')
    return {'reply': result['reply'], 'session_id': result['session_id'], 'router': decision,
            'source': result.get('source'), 'brain_mode': voice_get_brain_mode(con, session_id)}

@app.post('/api/chat')
def chat(turn: Turn, background_tasks: BackgroundTasks):
    if not turn.text.strip(): raise HTTPException(400,'Empty message')
    try:
        result = handle_turn(con, turn.text, turn.slot, turn.session_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # Oversight runs per-turn, in the background, on the session as it stands
    # right now -- NOT gated on session close. The web frontend's sessions are
    # long-lived (a room can stay open indefinitely), so waiting for a "close"
    # that may never come would mean oversight never runs for web chats at
    # all. run_oversight_pipeline only reads the current transcript/state; it
    # doesn't require open=0, so calling it here doesn't touch continuity --
    # the session stays open exactly as before. BackgroundTasks runs this
    # after the response is already sent, so the multi-call oversight chain
    # (clerk + checker + angel, each a real model call) never adds to the
    # user-visible chat latency.
    background_tasks.add_task(run_oversight_pipeline, con, result['session_id'])
    # Phase 1 memory: opportunistic daily rollup for whichever slot just
    # ran. No scheduler exists in this codebase, so this is how the rolling
    # window actually advances -- lazily, on real usage, not on a clock. The
    # summarisation call (cheap tier) and any resulting archive-to-vault
    # happen after the response is sent, same as oversight above; the vault
    # itself never runs a rolling window on itself.
    if result['slot'] != VAULT_SLOT:
        background_tasks.add_task(roll_worker_daily, con, result['slot'], _call_cheap_model)
    return result
@app.post('/api/capture')
def capture(c: Capture): return {'id': memory_add(con, c.text, {'type':c.kind,'slot':c.slot})}
@app.get('/api/memory/search')
def search_memory(q: str='', name: str | None = None):
    # Extends the existing endpoint rather than duplicating it: 'items' is
    # the original memories-table search, unchanged; 'vault' is new, a plain
    # keyword search over the permanent long-term store (not the LLM-mediated
    # yes/no -- that's /api/memory/vault below, for an actual retrieval ask).
    return {'items': recall(con, q), 'vault': vault_search(con, q, name=name)}
class VaultQuery(BaseModel):
    query: str; name: str | None = None
@app.post('/api/memory/vault')
def memory_vault(v: VaultQuery):
    # The actual "have we seen this before?" ask: deterministic search over
    # vault_entries narrows candidates, the Ollama/llama3.2 vault agent only
    # confirms/reports on them. Exposed as its own route mainly so this is
    # independently testable/inspectable, separate from the trigger-based
    # path wired into handle_turn() for Hub/workers.
    if not v.query.strip(): raise HTTPException(400, 'query is required')
    return vault_answer(con, v.query, name=v.name)
@app.post('/api/decision')
def decision(d: Decision): return {'id': log_decision(con, d.topic,d.decision,d.rationale,d.alternatives,d.slot)}
@app.get('/api/decision/search')
def decision_search(q: str=''): return {'items': related_decisions(con, q)}
@app.post('/api/nudge')
def nudge(n: Nudge): return {'id': add_nudge(con,n.kind,n.text,n.due)}
@app.get('/api/nudges')
def nudges(): return {'items': pending(con, 20)}

# ── Agent templates + spawned instances (unlimited, no hard cap) ──
@app.post('/api/agents/templates')
def create_agent_template(t: AgentTemplateIn):
    if not t.name.strip() or not t.system_prompt.strip():
        raise HTTPException(400, 'name and system_prompt are required')
    return {'id': create_template(con, t.name, t.system_prompt, t.model, t.tools, t.accent_color)}
@app.get('/api/agents/templates')
def get_agent_templates(): return {'items': list_templates(con)}
@app.post('/api/agents/instances')
def spawn_agent_instance(s: SpawnIn):
    try:
        return {'id': spawn_instance(con, s.template_id, s.name)}
    except ValueError as e:
        raise HTTPException(404, str(e))
@app.get('/api/agents/instances')
def get_agent_instances(status: str | None = None): return {'items': list_instances(con, status)}
@app.post('/api/agents/instances/{instance_id}/stop')
def stop_agent_instance(instance_id: str):
    if not get_instance(con, instance_id): raise HTTPException(404, 'Unknown instance')
    stop_instance(con, instance_id); return {'ok': True}
@app.delete('/api/agents/instances/{instance_id}')
def delete_agent_instance(instance_id: str):
    if not get_instance(con, instance_id): raise HTTPException(404, 'Unknown instance')
    delete_instance(con, instance_id); return {'ok': True}

# ── Conversation groups (isolated side threads, arbitrary member sets) ──
@app.post('/api/groups')
def create_conversation_group(g: GroupIn):
    if not g.name.strip(): raise HTTPException(400, 'name is required')
    if not g.members: raise HTTPException(400, 'at least one member is required')
    bad = [m for m in g.members if m not in SLOTS and not is_active_instance(con, m)]
    if bad: raise HTTPException(400, f'Unknown member id(s): {bad}')
    return {'id': create_group(con, g.name, g.members)}
@app.get('/api/groups')
def get_groups(): return {'items': list_groups(con)}
@app.get('/api/groups/{group_id}')
def get_group_detail(group_id: str):
    g = get_group(con, group_id)
    if not g: raise HTTPException(404, 'Unknown group')
    return {**g, 'members': get_group_member_ids(con, group_id)}
@app.post('/api/groups/{group_id}/message')
def post_group_message(group_id: str, m: GroupMessageIn):
    if not get_group(con, group_id): raise HTTPException(404, 'Unknown group')
    if not m.text.strip(): raise HTTPException(400, 'Empty message')
    try:
        return handle_group_message(con, group_id, m.text, m.speaker, m.mention)
    except ValueError as e:
        raise HTTPException(400, str(e))
@app.get('/api/groups/{group_id}/transcript')
def group_transcript_route(group_id: str):
    if not get_group(con, group_id): raise HTTPException(404, 'Unknown group')
    return {'items': get_group_transcript(con, group_id)}
@app.post('/api/groups/{group_id}/close')
def close_conversation_group(group_id: str, c: GroupCloseIn = GroupCloseIn()):
    if not get_group(con, group_id): raise HTTPException(404, 'Unknown group')
    try:
        return handle_group_close(con, group_id, c.shared_with_hub)
    except ValueError as e:
        raise HTTPException(400, str(e))

# ── Tool connections (Gmail, Stripe, ChatGPT, Ollama, custom -- credentials
# are always client-obtained tokens/API keys, never passwords; see tools.py) ──
@app.post('/api/tools')
def create_tool_connection(t: ToolIn):
    if not t.label.strip() or not t.tool_type.strip():
        raise HTTPException(400, 'tool_type and label are required')
    if t.kind not in ('conversational', 'action'):
        raise HTTPException(400, "kind must be 'conversational' or 'action'")
    return {'id': create_tool(con, t.tool_type, t.label, t.kind, t.config, t.needs_credential)}
@app.get('/api/tools')
def get_tool_connections(): return {'items': list_tools(con)}
@app.get('/api/tools/{tool_id}')
def get_tool_connection(tool_id: str):
    tool = get_tool_public(con, tool_id)
    if not tool: raise HTTPException(404, 'Unknown tool')
    return tool
@app.patch('/api/tools/{tool_id}')
def rename_tool_connection(tool_id: str, t: ToolUpdateIn):
    if not get_tool(con, tool_id): raise HTTPException(404, 'Unknown tool')
    update_tool(con, tool_id, t.label, t.config)
    return get_tool_public(con, tool_id)
@app.post('/api/tools/{tool_id}/credential')
def set_tool_credential(tool_id: str, c: ToolCredentialIn):
    if not get_tool(con, tool_id): raise HTTPException(404, 'Unknown tool')
    if not c.credential.strip(): raise HTTPException(400, 'credential is required')
    try:
        set_credential(con, tool_id, c.credential, c.credential_type)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return get_tool_public(con, tool_id)
@app.delete('/api/tools/{tool_id}')
def delete_tool_connection(tool_id: str):
    if not get_tool(con, tool_id): raise HTTPException(404, 'Unknown tool')
    delete_tool(con, tool_id); return {'ok': True}

def main():
    # Default stays localhost-only. launch_lan.bat sets COMMAND_DESK_HOST=0.0.0.0
    # so the phone app can reach the server over the local wifi network.
    host = os.getenv('COMMAND_DESK_HOST', '127.0.0.1')
    port = int(os.getenv('COMMAND_DESK_PORT', '8765'))
    uvicorn.run('core.main:app', host=host, port=port, reload=False)
if __name__ == '__main__': main()
