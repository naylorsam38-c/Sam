from __future__ import annotations
import re, json
from pathlib import Path
from .continuity import open_session, write_turn, update_state, write_intent, resume_line, peer_transcript
from .db import normalize_quotes
from .llm_router import run
from .memory import memory_add, recall, log_decision, related_decisions
from .nudge_bus import maybe_learning_nudge, add_nudge, pending
from .audit_log import log as audit
from .agents import instance_slot_cfg, is_active_instance
from .tools import active_tools_for_hub
from .vault import worker_context, vault_answer, vault_already_queried, mark_vault_queried, VAULT_TRIGGER
from .permission_layer import (request_gmail_read, MAIL_TRIGGER, request_gmail_draft,
                                DRAFT_TRIGGER, compose_draft_content)
from .voice_state import get_brain_mode, set_brain_mode, WAKE_TRIGGER, SLEEP_TRIGGER
from .groups import (group_members as _group_members, write_group_turn, get_group_transcript,
                      next_round_robin_member, get_group, close_group)

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / 'slots_config.json'


def load_slots_config(path: Path = CONFIG_PATH) -> dict:
    """Read slots_config.json fresh from disk. Returns a dict with '_order'
    (slot ids in config order), '_default' (fallback slot id), and one entry
    per slot id -> its config dict. Raises if the file is missing/malformed --
    fail loud rather than silently running with zero slots."""
    raw = json.loads(path.read_text(encoding='utf-8'))
    slots = sorted(raw['slots'], key=lambda s: s.get('order', 0))
    config = {s['id']: s for s in slots}
    default_slot = raw.get('default_slot') or (slots[0]['id'] if slots else None)
    return {'_order': [s['id'] for s in slots], '_default': default_slot, **config}


def reload_slots():
    """Re-read slots_config.json without restarting the process. A slot can be
    added or removed just by editing the config and calling this (or simply
    restarting the server) -- no Python changes required either way."""
    global SLOT_CONFIG, SLOTS, DEFAULT_SLOT
    fresh = load_slots_config()
    SLOT_CONFIG = {k: v for k, v in fresh.items() if not k.startswith('_')}
    SLOTS = fresh['_order']
    DEFAULT_SLOT = fresh['_default']
    return SLOTS


# Initial load at import time.
_loaded = load_slots_config()
SLOT_CONFIG: dict = {k: v for k, v in _loaded.items() if not k.startswith('_')}
SLOTS: list[str] = _loaded['_order']
DEFAULT_SLOT: str = _loaded['_default']


def _resolve_cfg(slot, con=None):
    """Static slots_config.json entries take priority; a spawned agent
    instance (identified by its instance id) is checked only when a db
    connection is supplied, so this stays a pure/static lookup wherever con
    isn't available (e.g. contextual_slot_ids, which never deals with
    instances since they're solo-isolated by default)."""
    cfg = SLOT_CONFIG.get(slot)
    if cfg is not None:
        return cfg
    if con is not None:
        dyn = instance_slot_cfg(con, slot)
        if dyn:
            return dyn
    return {}


def load_prompt(slot, con=None):
    cfg = _resolve_cfg(slot, con)
    if cfg.get('system_prompt'):
        return cfg['system_prompt']
    rel = cfg.get('system_prompt_file')
    if rel:
        p = ROOT / rel
        if p.exists():
            return p.read_text(encoding='utf-8')
    return f'You are the {slot} slot.'


def isolated_group_members(slot: str, con=None) -> set[str]:
    cfg = _resolve_cfg(slot, con)
    group = cfg.get('isolated_group')
    if not group:
        return {slot}
    members = {sid for sid, c in SLOT_CONFIG.items() if c.get('isolated_group') == group}
    members.add(slot)
    return members


def contextual_slot_ids() -> set[str]:
    return {sid for sid, c in SLOT_CONFIG.items() if c.get('contextual')}


_INSTANCE_ID_RE = re.compile(r'^[0-9a-f]{32}$')  # exactly what uuid.uuid4().hex produces


def infer_slot(text, current=None, con=None):
    # An explicitly selected slot always wins -- tapping a slot button in the
    # UI makes that the active conversation; keywords only route when no slot
    # was chosen (e.g. API calls that omit 'slot'). con is optional so this
    # keeps working exactly as before for callers (incl. existing tests) that
    # never deal with spawned instances and only pass (text) or (text, current).
    if current in SLOT_CONFIG:
        return current
    if current and _INSTANCE_ID_RE.match(current):
        if con is not None and is_active_instance(con, current):
            return current
        # current is shaped exactly like a spawned-instance id (32 hex chars)
        # but isn't a live active one -- stopped, deleted, or never existed.
        # That's a real error, not "no slot chosen": silently falling back to
        # hub here would mask a stale/dead instance reference. A genuinely
        # arbitrary string (not UUID-shaped) still falls through to keyword
        # routing below, unchanged.
        if con is not None:
            raise ValueError(f'Unknown or stopped agent instance: {current}')
    t = text.lower()
    for sid in SLOTS:
        kws = SLOT_CONFIG.get(sid, {}).get('keywords', [])
        if any(kw in t for kw in kws):
            return sid
    return DEFAULT_SLOT


def compact_summary(text):
    clean=' '.join(text.strip().split())
    return (clean[:120] + ('...' if len(clean)>120 else '')) or 'continuing the thread'


def handle_turn(con, text: str, slot: str = None, session_id: str | None = None):
    slot = infer_slot(text, slot, con)
    cfg = _resolve_cfg(slot, con)
    is_isolated = bool(cfg.get('isolated'))
    session_id = session_id or open_session(con, slot)
    write_turn(con, session_id, slot, 'user', text)
    captures=[]
    if re.search(r'\b(note that|capture this|remember that)\b', text, re.I):
        frag = re.sub(r'.*?\b(note that|capture this|remember that)\b[: ]*', '', text, flags=re.I).strip() or text
        memory_add(con, frag, {'type':'capture','slot':slot,'session':session_id}); captures.append('captured')
    decision_match = re.search(r'(?:decision|decided|we decided)[: ]+(.+)', text, re.I)
    if decision_match:
        log_decision(con, 'user decision', decision_match.group(1), 'Captured from Sam during conversation.', [], slot); captures.append('decision logged')
    nudge = maybe_learning_nudge(text)
    if nudge: add_nudge(con, 'gap', nudge); captures.append(nudge)

    # Isolated slots (Builder/Tester) never touch the shared Memory/Decision
    # pool -- they only see each other's transcript. Contextual slots share a
    # common pool that explicitly excludes anything tagged to an isolated
    # slot, so the wall holds in both directions.
    if is_isolated:
        allowed = isolated_group_members(slot, con)
        memories = recall(con, text, 3, allowed_slots=allowed)
        decisions = related_decisions(con, text[:80], 3, allowed_slots=allowed)
        peers = [s for s in allowed if s != slot]
        peer_notes = peer_transcript(con, peers, limit=4)
    else:
        allowed = contextual_slot_ids()
        memories = recall(con, text, 3, allowed_slots=allowed)
        decisions = related_decisions(con, text[:80], 3, allowed_slots=allowed)
        peer_notes = []

    # Phase 1 memory -- each slot's own rolling window (3-5 days, deliberately
    # lean, no scheduler involved: worker_context is just a cheap read of
    # whatever roll_worker_daily has already written for this slot).
    recent_days = worker_context(con, slot)

    prompt = load_prompt(slot, con) + f"\n\nRelevant memory: {json.dumps(memories)[:1200]}\nRelated decisions: {json.dumps(decisions)[:1200]}"
    if recent_days:
        prompt += f"\nRecent days ({slot}): {json.dumps(recent_days)[:900]}"
    if peer_notes:
        prompt += f"\nPeer notes ({'/'.join(sorted(isolated_group_members(slot, con)))}): {json.dumps(peer_notes)[:1200]}"

    # Every deterministic trigger below is matched against a smart-quote-
    # normalized copy of the text ONLY -- 'text' itself (stored, shown, sent
    # to the LLM) stays exactly as Sam typed it. Without this, a phrase
    # typed on a real phone keyboard (which autocorrects ' to the curly
    # U+2019) silently never matches a pattern written and tested with a
    # straight apostrophe -- caught live when Sam's actual "what's come in"
    # (curly) failed to match the trigger a straight-quote test had verified.
    matched_text = normalize_quotes(text)

    # Vault check: trigger-based, not polling. Only fires on phrasing that
    # actually asks "have we seen this before" (VAULT_TRIGGER), and only once
    # per subject per session (vault_already_queried/mark_vault_queried, kept
    # in their own vault_queries table -- NOT sessions.state, since
    # update_state() below overwrites that whole blob every turn regardless
    # of slot/subject). This is a real synchronous Ollama call when it fires
    # -- latency here is intentional, not an oversight; its answer needs to
    # be in THIS turn's context, not a later one.
    if VAULT_TRIGGER.search(matched_text) and not vault_already_queried(con, session_id, text):
        vault_result = vault_answer(con, text)
        prompt += f"\nVault check (prior history on this): {vault_result['answer'] or 'No.'}"
        mark_vault_queried(con, session_id, text)

    # Stage 4 fix: computed BEFORE the read hook below so a draft/send
    # intent always wins over the read net, even when both match the same
    # message. MAIL_TRIGGER was broadened to a noun-based net (inbox/gmail/
    # junk mail/spam/e-mail*) after live verification showed the old narrow
    # phrase list missed real phrasing like "is there a rob in my junk
    # mail" -- but that same broad net now also matches "draft an email to
    # X" (it contains the word "email"). Without this precedence check,
    # BOTH the read hook and the draft hook's own "not MAIL_TRIGGER" guard
    # would fire wrong: a spurious real read would run, AND the draft would
    # be silently skipped entirely. Proven with a regression test before
    # this shipped.
    draft_intent = slot == 'personal_assistant' and DRAFT_TRIGGER.search(matched_text)

    # Stage 3: Gmail read, gated entirely through the permission layer.
    # personal_assistant is the mail worker -- this only detects the trigger
    # and asks the layer for a read; the layer independently re-checks
    # session_id against auth_sessions and refuses regardless of what gate
    # the calling route already applied. No draft/send path exists anywhere.
    if slot == 'personal_assistant' and MAIL_TRIGGER.search(matched_text) and not draft_intent:
        read_result = request_gmail_read(con, session_id, worker='personal_assistant')
        if not read_result.get('allowed'):
            prompt += f"\nGmail access refused by the permission layer: {read_result.get('error')}"
        elif read_result.get('error'):
            prompt += f"\nGmail read attempt did not complete: {read_result['error']}"
        else:
            msgs = read_result.get('messages', [])
            if msgs:
                lines = [f"- From {m['from']} -- {m['subject']} ({m['date']}): {m['snippet']}" for m in msgs]
                prompt += "\nReal inbox contents just fetched via the permission layer (read-only, do not invent beyond this):\n" + "\n".join(lines)
            else:
                prompt += "\nInbox check via the permission layer returned no messages."

    # Stage 4: preparing a NEW email, gated entirely through the permission
    # layer, same additive-only shape as Stage 3's read hook. Nothing here
    # composes an email itself -- compose_draft_content is the one brain
    # call that consumes the style profile, and request_gmail_draft is the
    # one path that can touch the Gmail API to create it.
    if draft_intent:
        draft_input = compose_draft_content(con, text)
        if draft_input.get('error'):
            prompt += f"\nCouldn't prepare that draft: {draft_input['error']}"
        else:
            draft_result = request_gmail_draft(con, session_id, worker='personal_assistant',
                                                 to=draft_input['to'], subject=draft_input['subject'],
                                                 body_text=draft_input['body'])
            if not draft_result.get('allowed'):
                prompt += f"\nDraft creation refused by the permission layer: {draft_result.get('error')}"
            elif draft_result.get('error'):
                prompt += f"\nDraft creation did not complete: {draft_result['error']}"
            else:
                prompt += (f"\nDraft prepared and awaiting Sam's confirmation "
                           f"(draft_id={draft_result['draft_id']}):\nTo: {draft_result['to']}\n"
                           f"Subject: {draft_result['subject']}\n{draft_result['body']}\n\n"
                           "Tell Sam what you prepared and ask him to confirm before anything can send.")

    if slot == 'hub':
        tools = active_tools_for_hub(con)
        if tools:
            prompt += f"\nConnected tools available to route to or mention: {json.dumps(tools)[:1200]}"

    # Stage 3: Sonnet wake -- wired to Sam's own spoken/typed word only, and
    # only for nova_voice itself (never for a worker the router delegated
    # to). No heuristic, no auto-wake: these two regexes are the only things
    # that ever flip brain_mode, and the face model never decides this for
    # itself -- it just gets told which brain to run on below.
    if slot == 'nova_voice':
        if WAKE_TRIGGER.search(matched_text):
            set_brain_mode(con, session_id, 'claude', trigger=text[:120])
        elif SLEEP_TRIGGER.search(matched_text):
            set_brain_mode(con, session_id, 'ollama', trigger=text[:120])

    # A spawned instance's template may pin a specific model; static slots
    # never set 'model' in slots_config.json, so run_kwargs stays empty for
    # them and this is a no-op for every existing call path (incl. tests that
    # monkeypatch orch.run with a (slot, prompt, messages, tools=None) stub).
    run_kwargs = {}
    if cfg.get('model'):
        run_kwargs['model'] = cfg['model']
    if cfg.get('provider'):
        run_kwargs['provider'] = cfg['provider']
    # Sam's switch overrides nova_voice's own config-driven Ollama default
    # for as long as brain_mode stays 'claude' -- persists across turns
    # until he says the sleep phrase, exactly like a switch rather than a
    # one-turn boost.
    if slot == 'nova_voice' and get_brain_mode(con, session_id) == 'claude':
        run_kwargs['model'] = 'claude-sonnet-5'
        run_kwargs['provider'] = 'claude'
    raw = run(slot, prompt, [{'role':'user','content':text}], **run_kwargs)
    content = raw.get('content') if isinstance(raw, dict) else str(raw)
    source = raw.get('source') if isinstance(raw, dict) else None
    if isinstance(content, list):
        content = ' '.join(getattr(x,'text',str(x)) for x in content)
    if captures:
        content = ' | '.join(captures) + '\n' + content
    if slot == 'mind' and any(w in text.lower() for w in ['audit','idea','plan','what if']):
        content += '\n\nAudit: strongest risk -- check the assumption, test the smallest version, and do not scale until the failure mode is known.'
    write_turn(con, session_id, slot, 'assistant', content)
    update_state(con, session_id, compact_summary(text), f'continue in {slot} with the next concrete action')
    if slot == 'hub':
        # Hub states its own intent inline when delegating/acting (see its
        # system prompt); this only extracts and stores what it already said
        # -- Hub never reads this back, and nothing here judges it. Only the
        # Checker, later, after the session closes, compares it to outcome.
        # Must run AFTER update_state(): that call overwrites the whole
        # state blob, so writing intent first would get silently clobbered.
        intent_match = re.search(r'^INTENT:\s*(.+)$', content, re.I | re.M)
        if intent_match:
            write_intent(con, session_id, intent_match.group(1).strip(), text)
    audit(con, slot, 'handle_turn', text, 'ok', content)
    return {'slot':slot,'session_id':session_id,'reply':content,'resume':resume_line(con),'nudges':pending(con),'source':source}


def _member_label(con, member_id):
    if member_id == 'user':
        return 'User'
    return _resolve_cfg(member_id, con).get('name', member_id)


def _build_group_messages(con, group_id, responder_id):
    """Turn a group's transcript into Claude-shaped messages from responder_id's
    point of view: its own past turns are 'assistant', everyone else's
    (human or other agents) are 'user', prefixed with who actually said it so
    the model can tell speakers apart in a two-role transcript."""
    rows = get_group_transcript(con, group_id)
    out = []
    for r in rows:
        role = 'assistant' if r['member_id'] == responder_id else 'user'
        prefix = '' if role == 'assistant' else f"[{_member_label(con, r['member_id'])}]: "
        out.append({'role': role, 'content': prefix + r['content']})
    # Claude requires alternating roles -- merge consecutive same-role turns
    # (e.g. two other members speaking back-to-back both read as 'user').
    merged = []
    for m in out:
        if merged and merged[-1]['role'] == m['role']:
            merged[-1]['content'] += '\n' + m['content']
        else:
            merged.append(dict(m))
    if merged and merged[0]['role'] != 'user':
        merged.insert(0, {'role': 'user', 'content': '(group conversation begins)'})
    return merged


def _append_user_msg(messages, text):
    # Keeps role alternation valid regardless of who spoke last -- merges into
    # the trailing 'user' turn instead of adding a second consecutive one.
    if messages and messages[-1]['role'] == 'user':
        messages[-1]['content'] += '\n' + text
    else:
        messages.append({'role': 'user', 'content': text})
    return messages


def handle_group_message(con, group_id: str, text: str, speaker: str | None = None, mention: str | None = None):
    """Post a turn into a group and get the next agent's reply. speaker is who's
    sending this turn ('user' by default, or a member id if simulating an
    agent-initiated message). mention explicitly picks the responder; falls
    back to round-robin over the group's members if omitted or invalid."""
    g = get_group(con, group_id)
    if not g:
        raise ValueError('Unknown group')
    if g['status'] == 'closed':
        raise ValueError('Group is closed')
    members = _group_members(con, group_id)
    if not members:
        raise ValueError('Group has no members')
    speaker = speaker or 'user'
    if speaker != 'user' and speaker not in members:
        raise ValueError(f'{speaker} is not a member of this group')
    write_group_turn(con, group_id, speaker, text)

    responder = mention if (mention and mention in members) else next_round_robin_member(con, group_id, members)
    cfg = _resolve_cfg(responder, con)
    system_prompt = load_prompt(responder, con)
    messages = _build_group_messages(con, group_id, responder)
    run_kwargs = {}
    if cfg.get('model'):
        run_kwargs['model'] = cfg['model']
    if cfg.get('provider'):
        run_kwargs['provider'] = cfg['provider']
    raw = run(responder, system_prompt, messages, **run_kwargs)
    content = raw.get('content') if isinstance(raw, dict) else str(raw)
    write_group_turn(con, group_id, responder, content)
    audit(con, responder, 'handle_group_message', text, 'ok', content)
    return {'group_id': group_id, 'responder': responder, 'reply': content, 'transcript': get_group_transcript(con, group_id)}


def handle_group_close(con, group_id: str, shared_with_hub: bool = False):
    """Explicit-only close (no auto-close/timeout): the group's started_by
    agent reads the full transcript and produces a wrap-up summary, using the
    same transcript-to-messages path as a live group turn. If shared_with_hub,
    the summary is written into hub's normal contextual memory pool -- same
    memory_add() mechanism regular hub captures use -- so it becomes part of
    what hub can recall later; otherwise it lives only on the closed group
    record and nowhere else."""
    g = get_group(con, group_id)
    if not g:
        raise ValueError('Unknown group')
    if g['status'] == 'closed':
        raise ValueError('Group is already closed')
    members = _group_members(con, group_id)
    started_by = g.get('started_by') or (members[0] if members else None)
    if not started_by:
        raise ValueError('Group has no members to generate a summary')

    cfg = _resolve_cfg(started_by, con)
    system_prompt = load_prompt(started_by, con)
    messages = _build_group_messages(con, group_id, started_by)
    _append_user_msg(messages, 'The conversation is closing. Write a concise wrap-up summary of what this group discussed and any decisions made.')
    run_kwargs = {}
    if cfg.get('model'):
        run_kwargs['model'] = cfg['model']
    if cfg.get('provider'):
        run_kwargs['provider'] = cfg['provider']
    raw = run(started_by, system_prompt, messages, **run_kwargs)
    summary = raw.get('content') if isinstance(raw, dict) else str(raw)

    close_group(con, group_id, summary)
    if shared_with_hub:
        memory_add(con, summary, {'type': 'group_summary', 'slot': 'hub', 'group_id': group_id, 'started_by': started_by})
    audit(con, started_by, 'handle_group_close', f'close group {group_id}', 'ok', summary)
    return {'group_id': group_id, 'started_by': started_by, 'summary': summary, 'shared_with_hub': shared_with_hub, 'status': 'closed'}
