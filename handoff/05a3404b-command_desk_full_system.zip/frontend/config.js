window.COMMAND_DESK_CONFIG = {
  backendBaseUrl: "/commanddesk",
  demoMode: false,
  endpoints: { agents: "/agents" },
  speechLanguage: "en-AU"
};
