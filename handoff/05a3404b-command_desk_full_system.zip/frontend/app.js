/* Command Desk -- Home Screen Redesign, merged onto the CURRENT WORKING
   backend contract:
   GET  /commanddesk/auth/whoami
   POST /commanddesk/auth/login  {username,password} -> Set-Cookie session_id (HttpOnly)
   POST /commanddesk/nova/turn   {text} -> {reply, session_id}   <-- the ONLY chat path
   GET  /commanddesk/agents      -> real roster, no fakes

   Whole page is behind the login gate -- nothing below boot() runs until an
   authenticated session is confirmed. Home and every room's input both go
   through /nova/turn, so email read/draft/send, the router, the Sonnet
   wake, and the state machine all work exactly as already proven,
   regardless of which room's input box Sam typed in.

   HONEST LIMITATION: the backend's only gated conversational endpoint
   (/nova/turn) always decides the real worker itself -- it has no slot
   override, and this frontend does not add one (the backend is off-limits
   for this merge). A room is still built from the real /agents roster and
   keeps its own local transcript, but the actual reply comes from
   whichever worker Nova's real router picks for that message, same as it
   would from Home.

   STATIC ONLY, per Sam's explicit instruction ("don't put on any other
   motion or anything in the background, I don't like it"): the avatar
   engine's blink/mouth/breathing animation from the original build has
   been removed entirely. Nova is one still image. Nothing moves on its
   own -- not even the "agent is working" indicator, which is now a static
   dot rather than a spinner. */

const C = window.COMMAND_DESK_CONFIG || {};
const avatars = { nova:"Nova", halo:"Halo", gaia:"Gaia" };
const themes = {
  gunmetal:{name:"Gunmetal",a:"#1a1c20",b:"#050607",c:"#b9c0c7"},
  volcano:{name:"Volcano",a:"#251006",b:"#050201",c:"#ff7a22"},
  platinum:{name:"Platinum",a:"#24272b",b:"#050607",c:"#e8ebef"}
};
// Curated quick-launch shortcuts for a room's "+ App" picker. These open a
// REAL external URL in a new tab -- an honest bookmark, not a claim that
// Command Desk is acting on Sam's behalf inside them. Entries with no URL
// (Calendar, Notes, Browser) are placeholders and are skipped at render
// time rather than shown as dead buttons.
const curatedApps=[
  {id:"gmail",name:"Gmail",glyph:"G",url:"https://mail.google.com"},
  {id:"icloud",name:"iCloud",glyph:"☁",url:"https://www.icloud.com/mail"},
  {id:"outlook",name:"Outlook",glyph:"O",url:"https://outlook.live.com"},
  {id:"drive",name:"Drive",glyph:"△",url:"https://drive.google.com"},
  {id:"docs",name:"Docs",glyph:"▤",url:"https://docs.google.com"}
];

const $ = s => document.querySelector(s);
const el = {
  loginView:$("#loginView"), loginForm:$("#loginForm"), loginUsername:$("#loginUsername"),
  loginPassword:$("#loginPassword"), loginError:$("#loginError"),
  app:$("#app"),
  clock:$("#clock"), date:$("#date"),
  avatarBase:$("#avatarBase"), avatarAccessibleName:$("#avatarAccessibleName"), avatarBtn:$("#avatarBtn"),
  state:$("#stateLabel"),
  appearance:$("#appearance"), dialog:$("#appearanceDialog"), grid:$("#appearanceGrid"), apply:$("#apply"),
  homeView:$("#homeView"), roomView:$("#roomView"), tiles:$("#agentTiles"),
  homeInput:$("#homeInput"), homeMic:$("#homeMic"), homeSend:$("#homeSend"),
  roomBack:$("#roomBack"), roomTitle:$("#roomTitle"), roomStatus:$("#roomStatus"),
  roomTranscript:$("#roomTranscript"), roomInput:$("#roomInput"), roomMic:$("#roomMic"), roomSend:$("#roomSend"),
  roomSwitch:$("#roomSwitch"), roomSwitchBtn:$("#roomSwitchBtn"), roomSwitchMenu:$("#roomSwitchMenu"),
  roomAddApp:$("#roomAddApp"), appPicker:$("#appPicker"), roomApps:$("#roomApps"),
  appOpenView:$("#appOpenView"), appOpenBack:$("#appOpenBack"), appOpenName:$("#appOpenName"),
  appOpenExternal:$("#appOpenExternal"), appFrame:$("#appFrame"), appFallback:$("#appFallback"),
  appFallbackOpen:$("#appFallbackOpen")
};

const store = {
  get(k, d){ try { const v = localStorage.getItem(k); return v==null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};

// Storage schema versioning -- bumped for this merge. The original redesign
// never had a login gate and stored a per-room "session_id" that the real
// backend's /nova/turn never accepts as input (session comes from the
// cookie only); both are gone now, so stale cd.* state is wiped rather
// than left around half-meaningful.
const SCHEMA_VERSION = "20260802-homeredesign-merged";
(function ensureSchema(){
  try{
    if(localStorage.getItem("cd.schemaVersion")!==SCHEMA_VERSION){
      Object.keys(localStorage).filter(k=>k.startsWith("cd.")).forEach(k=>localStorage.removeItem(k));
      localStorage.setItem("cd.schemaVersion",SCHEMA_VERSION);
    }
  }catch{}
})();

let S = {
  avatar: store.get("cd.avatar","nova"),
  theme: store.get("cd.theme","platinum"),
  agents: [],
  visibleAgentIds: store.get("cd.visibleAgentIds", []),
  messages: store.get("cd.messages", {}),
  apps: store.get("cd.roomApps", {}),
  pending: store.get("cd.pending", {}),
  activeAgent: null,
  mode: "idle",
  recognition: null, recTarget: "home",
  sa: null, st: null
};

function base(){ return String(C.backendBaseUrl||"").replace(/\/$/,""); }

/* ---------- clock ---------- */
function clock(){
  const n = new Date();
  if(el.clock) el.clock.textContent = n.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",hour12:false});
  if(el.date) el.date.textContent = n.toLocaleDateString("en-AU",{weekday:"short",day:"numeric",month:"short"}).toUpperCase();
}
clock(); setInterval(clock,1000);

/* ---------- avatar: STATIC ONLY -- see file header. One still image, no
   blink timer, no mouth timer, no breathing animation. ---------- */
function appearance(a,t,save=true){
  S.avatar=a; S.theme=t;
  document.body.dataset.avatar=a; document.body.dataset.theme=t;
  if(el.avatarBase) el.avatarBase.src=`assets/avatars/${a}.png`;
  if(el.avatarAccessibleName) el.avatarAccessibleName.textContent=avatars[a]||a;
  if(save){ store.set("cd.avatar",a); store.set("cd.theme",t); }
}
function mode(m,label){
  S.mode=m; document.body.dataset.state=m;
  const text=label||{idle:"READY",listening:"LISTENING",thinking:"THINKING",speaking:"SPEAKING",working:"WORKING"}[m]||"READY";
  if(el.state) el.state.textContent=text;
  if(el.roomStatus) el.roomStatus.textContent=text;
  [el.homeMic, el.roomMic].forEach(b=>{
    if(!b) return;
    b.classList.toggle("active", m==="listening");
    b.textContent = m==="listening" ? "■" : "●";
  });
  // No mouth/blink animation on any state change -- the avatar image never
  // changes on its own, only the READY/LISTENING/etc label does.
}

/* ---------- dialogs ---------- */
function openDialog(d){ if(!d) return; if(typeof d.showModal==="function") d.showModal(); else d.setAttribute("open",""); }
function closeDialog(d){ if(!d) return; if(typeof d.close==="function") d.close(); else d.removeAttribute("open"); }
function renderGrid(){
  if(!el.grid) return;
  el.grid.innerHTML="";
  Object.keys(avatars).forEach(a=>Object.keys(themes).forEach(t=>{
    const x=themes[t], b=document.createElement("button");
    b.type="button"; b.className="option"+(S.sa===a&&S.st===t?" selected":"");
    b.style.setProperty("--pa",x.a); b.style.setProperty("--pb",x.b); b.style.setProperty("--pc",x.c);
    b.innerHTML=`<img src="assets/avatars/${a}.png" alt="${avatars[a]}"><strong>${avatars[a]}</strong><small>${x.name}</small>`;
    b.onclick=()=>{ S.sa=a; S.st=t; renderGrid(); };
    el.grid.appendChild(b);
  }));
}
if(el.appearance) el.appearance.onclick=()=>{ S.sa=S.avatar; S.st=S.theme; renderGrid(); openDialog(el.dialog); };
if(el.apply) el.apply.onclick=e=>{ e.preventDefault(); appearance(S.sa,S.st); closeDialog(el.dialog); };
if(el.avatarBtn) el.avatarBtn.onclick=()=>startVoice("home");

/* ---------- agents + rooms (real roster, no fakes) ---------- */
function titleCase(id){ return String(id).replace(/[_-]+/g," ").replace(/\b\w/g,m=>m.toUpperCase()); }

async function loadAgents(){
  const ep=String((C.endpoints&&C.endpoints.agents)||"/agents");
  try{
    const r=await fetch(base()+(ep.startsWith("/")?ep:"/"+ep),{credentials:"same-origin"});
    if(!r.ok) throw new Error("HTTP "+r.status);
    const d=await r.json();
    const list=Array.isArray(d)?d:(d.agents||[]);
    S.agents=list.map(x=>typeof x==="string"?{id:x}:{id:x.id||x.name}).filter(x=>x.id&&x.id!=="hub");
  }catch{
    S.agents=[]; // no fakes -- show offline
  }
  if(!S.visibleAgentIds.length){
    S.visibleAgentIds=S.agents.slice(0,4).map(a=>a.id);
    store.set("cd.visibleAgentIds",S.visibleAgentIds);
  }
  S.visibleAgentIds=S.visibleAgentIds.filter(id=>S.agents.some(a=>a.id===id));
  renderTiles();
  renderRoomSwitch();
}
function availableToAdd(){ return S.agents.filter(a=>!S.visibleAgentIds.includes(a.id)); }
function makeAgentTile(id){
  const b=document.createElement("button");
  b.className="agent-tile"+(S.pending[id]?" working":"");
  b.dataset.agent=id;
  b.setAttribute("aria-label",`Open ${titleCase(id)} room`);
  b.innerHTML='<span class="tile-core"></span>'+(S.pending[id]?'<span class="tile-dot"></span>':'');
  b.onclick=()=>enterRoom(id);
  return b;
}
function renderTiles(){
  if(!el.tiles) return;
  el.tiles.innerHTML="";
  const first=S.visibleAgentIds.slice(0,4), extra=S.visibleAgentIds.slice(4);
  first.forEach(id=>el.tiles.appendChild(makeAgentTile(id)));
  const add=document.createElement("button");
  add.className="agent-tile add"; add.setAttribute("aria-label","Add agent tile");
  add.innerHTML='<span class="tile-core">＋</span>';
  add.onclick=addAgentTile;
  el.tiles.appendChild(add);
  extra.forEach(id=>el.tiles.appendChild(makeAgentTile(id)));
}
function addAgentTile(){
  const next=availableToAdd()[0];
  if(!next){ mode("idle","ALL ADDED"); setTimeout(()=>mode("idle"),1000); return; }
  S.visibleAgentIds.push(next.id); store.set("cd.visibleAgentIds",S.visibleAgentIds);
  renderTiles(); renderRoomSwitch();
}
function renderRoomSwitch(){
  if(!el.roomSwitchMenu) return;
  el.roomSwitchMenu.innerHTML="";
  S.visibleAgentIds.filter(id=>id!==S.activeAgent).forEach(id=>{
    const b=document.createElement("button");
    b.textContent=titleCase(id);
    b.onclick=()=>{ closeRoomSwitch(); enterRoom(id); };
    el.roomSwitchMenu.appendChild(b);
  });
  const h=document.createElement("button");
  h.textContent="‹ Home";
  h.onclick=()=>{ closeRoomSwitch(); goHome(); };
  el.roomSwitchMenu.appendChild(h);
}
function closeRoomSwitch(){ if(el.roomSwitchMenu){ el.roomSwitchMenu.hidden=true; } if(el.roomSwitchBtn) el.roomSwitchBtn.setAttribute("aria-expanded","false"); }
if(el.roomSwitchBtn) el.roomSwitchBtn.onclick=e=>{
  e.stopPropagation();
  if(!el.roomSwitchMenu) return;
  renderRoomSwitch();
  el.roomSwitchMenu.hidden=!el.roomSwitchMenu.hidden;
  el.roomSwitchBtn.setAttribute("aria-expanded",String(!el.roomSwitchMenu.hidden));
};
document.addEventListener("click",e=>{ if(el.roomSwitch && !el.roomSwitch.contains(e.target)) closeRoomSwitch(); });

/* ---------- navigation: home <-> room ---------- */
function goHome(){
  S.activeAgent=null;
  document.body.dataset.view="home";
  el.homeView&&el.homeView.classList.add("active");
  el.roomView&&el.roomView.classList.remove("active");
  el.appOpenView&&el.appOpenView.classList.remove("active");
  el.roomSwitch&&(el.roomSwitch.hidden=true);
  el.appPicker&&(el.appPicker.hidden=true);
  mode("idle");
  renderTiles();
}
function enterRoom(agentId){
  if(!S.agents.some(a=>a.id===agentId)) return;
  S.activeAgent=agentId;
  document.body.dataset.view="room";
  el.homeView&&el.homeView.classList.remove("active");
  el.roomView&&el.roomView.classList.add("active");
  el.roomSwitch&&(el.roomSwitch.hidden=false);
  if(el.roomTitle) el.roomTitle.textContent=titleCase(agentId);
  if(el.roomInput) el.roomInput.value="";
  renderTranscript(); renderApps(); renderRoomSwitch();
  mode("idle");
}
if(el.roomBack) el.roomBack.onclick=goHome;

/* ---------- transcript / messages ---------- */
function msgs(){ return S.messages[S.activeAgent] || (S.messages[S.activeAgent]=[]); }
function pushMsg(role,text){ msgs().push({role,text}); store.set("cd.messages",S.messages); }
function escapeHtml(s){ return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function renderTranscript(){
  if(!el.roomTranscript) return;
  el.roomTranscript.innerHTML="";
  const list=msgs();
  if(!list.length){
    const e=document.createElement("div"); e.className="room-empty"; e.textContent="This room is ready.";
    el.roomTranscript.appendChild(e);
  }
  list.forEach(m=>{
    const row=document.createElement("div");
    row.className="msg "+(m.role==="you"?"msg-you":"msg-agent");
    row.innerHTML=`<span class="msg-who">${escapeHtml(m.role==="you"?"You":titleCase(S.activeAgent))}</span><span>${escapeHtml(m.text)}</span>`;
    el.roomTranscript.appendChild(row);
  });
  el.roomTranscript.scrollTop=el.roomTranscript.scrollHeight;
}

/* ---------- backend chat: the ONE real, gated contract --------------------
   POST /nova/turn {text} -> {reply, session_id}. The cookie IS the session
   -- JS never reads or sends a session_id, and there is no agent/avatar/
   theme field the backend accepts; Nova's own router decides who answers.
   A 401 means the cookie is gone/invalid -- drop straight back to login. */
async function requestReply(message){
  const r=await fetch(base()+"/nova/turn",{
    method:"POST", credentials:"same-origin",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({text:message})
  });
  if(r.status===401){ showLogin(); throw new Error("Not authenticated"); }
  if(!r.ok) throw new Error("HTTP "+r.status);
  const d=await r.json();
  return { text:String(d.reply ?? d.message ?? d.response ?? "") };
}

async function sendRoom(){
  if(!el.roomInput || !S.activeAgent) return;
  const text=el.roomInput.value.trim();
  if(!text) return;
  el.roomInput.value="";
  pushMsg("you",text); renderTranscript();
  S.pending[S.activeAgent]=1; store.set("cd.pending",S.pending); renderTiles();
  mode("thinking");
  try{
    const result=await requestReply(text);
    pushMsg("agent",result.text);
    S.pending[S.activeAgent]=0; store.set("cd.pending",S.pending); renderTiles();
    renderTranscript();
    speak(result.text);
  }catch{
    pushMsg("agent","Not authenticated, or not connected to the backend right now.");
    S.pending[S.activeAgent]=0; store.set("cd.pending",S.pending); renderTiles();
    renderTranscript(); mode("idle");
  }
}
if(el.roomSend) el.roomSend.onclick=sendRoom;
if(el.roomInput) el.roomInput.addEventListener("keydown",e=>{ if(e.key==="Enter") sendRoom(); });
if(el.roomMic) el.roomMic.onclick=()=>startVoice("room");

async function sendHome(){
  if(!el.homeInput) return;
  const text=el.homeInput.value.trim();
  if(!text) return;
  el.homeInput.value="";
  mode("thinking");
  try{
    const result=await requestReply(text);
    speak(result.text);
  }catch{
    mode("idle");
  }
}
if(el.homeSend) el.homeSend.onclick=sendHome;
if(el.homeInput) el.homeInput.addEventListener("keydown",e=>{ if(e.key==="Enter") sendHome(); });
if(el.homeMic) el.homeMic.onclick=()=>startVoice("home");

function speak(txt){
  if(!txt||!("speechSynthesis" in window)){ mode("idle"); return; }
  try{ speechSynthesis.cancel(); }catch{}
  const u=new SpeechSynthesisUtterance(txt);
  u.lang=C.speechLanguage||"en-AU"; u.rate=.95; u.pitch=S.avatar==="halo"?.86:1; u.volume=1;
  u.onstart=()=>mode("speaking"); u.onend=()=>mode("idle"); u.onerror=()=>mode("idle");
  try{ speechSynthesis.speak(u); }catch{ mode("idle"); }
}

/* one recognition, targeted at home or room */
const R=window.SpeechRecognition||window.webkitSpeechRecognition;
if(R){
  S.recognition=new R();
  S.recognition.lang=C.speechLanguage||"en-AU";
  S.recognition.interimResults=true; S.recognition.continuous=false;
  S.recognition.onstart=()=>mode("listening");
  S.recognition.onresult=e=>{
    let t=""; for(let i=e.resultIndex;i<e.results.length;i++) t+=e.results[i][0].transcript;
    if(S.recTarget==="home" && el.homeInput) el.homeInput.value=t;
    else if(el.roomInput) el.roomInput.value=t;
    if(e.results[e.results.length-1].isFinal){
      if(S.recTarget==="home") sendHome(); else sendRoom();
    }
  };
  S.recognition.onerror=()=>mode("idle");
  S.recognition.onend=()=>{ if(S.mode==="listening") mode("idle"); };
}
function startVoice(target){
  S.recTarget=target;
  if(S.mode==="speaking"){ try{speechSynthesis.cancel();}catch{} mode("idle"); return; }
  if(!S.recognition) return;
  if(S.mode==="listening"){ S.recognition.stop(); mode("idle"); }
  else S.recognition.start();
}

/* ---------- room apps: real iframe-embed attempt first, honest fallback,
   never a bare window.open "ejector" pretending something is integrated
   when it's really just leaving the app. ---------- */
function renderAppPicker(){
  if(!el.appPicker) return;
  el.appPicker.innerHTML="";
  curatedApps.filter(app=>app.url).forEach(app=>{
    const b=document.createElement("button");
    b.className="app-choice";
    b.innerHTML=`<strong>${app.glyph}</strong><small>${escapeHtml(app.name)}</small>`;
    b.onclick=()=>addApp(app);
    el.appPicker.appendChild(b);
  });
}
if(el.roomAddApp) el.roomAddApp.onclick=()=>{ renderAppPicker(); if(el.appPicker) el.appPicker.hidden=!el.appPicker.hidden; };
function addApp(app){
  const list=S.apps[S.activeAgent]||(S.apps[S.activeAgent]=[]);
  if(!list.some(x=>x.id===app.id)) list.push(app);
  store.set("cd.roomApps",S.apps);
  if(el.appPicker) el.appPicker.hidden=true;
  renderApps();
}
function renderApps(){
  if(!el.roomApps) return;
  const list=S.apps[S.activeAgent]||[];
  el.roomApps.innerHTML="";
  el.roomApps.hidden=!list.length;
  list.forEach(app=>{
    const b=document.createElement("button");
    b.className="room-app-chip";
    b.textContent=`${app.glyph} ${app.name}`;
    b.onclick=()=>openApp(app);
    el.roomApps.appendChild(b);
  });
}
function openApp(app){
  if(!app.url || !el.appOpenView) return;
  if(el.appOpenName) el.appOpenName.textContent=app.name;
  document.body.dataset.view="app";
  el.homeView&&el.homeView.classList.remove("active");
  el.roomView&&el.roomView.classList.remove("active");
  el.appOpenView.classList.add("active");
  if(el.appFrame){ el.appFrame.hidden=false; el.appFrame.src=app.url; }
  if(el.appFallback) el.appFallback.hidden=true;
  // If the target blocks framing, the iframe fails to signal load in a way
  // we can detect directly (cross-origin), so this is a time-based honest
  // fallback: if nothing has rendered after a few seconds, offer the real
  // "open in a new tab" escape hatch rather than leaving a blank frame.
  clearTimeout(openApp._fallbackTimer);
  openApp._fallbackTimer=setTimeout(()=>{
    if(el.appFrame) el.appFrame.hidden=true;
    if(el.appFallback) el.appFallback.hidden=false;
  },4000);
  if(el.appFrame) el.appFrame.onload=()=>{ clearTimeout(openApp._fallbackTimer); };
  if(el.appFallbackOpen) el.appFallbackOpen.onclick=()=>window.open(app.url,"_blank","noopener");
  if(el.appOpenExternal) el.appOpenExternal.onclick=()=>window.open(app.url,"_blank","noopener");
}
if(el.appOpenBack) el.appOpenBack.onclick=()=>{
  clearTimeout(openApp._fallbackTimer);
  if(el.appFrame){ el.appFrame.src="about:blank"; el.appFrame.hidden=true; }
  el.appOpenView&&el.appOpenView.classList.remove("active");
  if(S.activeAgent){ document.body.dataset.view="room"; el.roomView&&el.roomView.classList.add("active"); }
  else { document.body.dataset.view="home"; el.homeView&&el.homeView.classList.add("active"); }
};

/* ---------- Stage 1 identity gate ----------
   whoami is the honest client-side convenience check (decides whether to
   show the login form or the app) -- it is NOT the security boundary. The
   real boundary is that /nova/turn independently refuses with 401 if the
   cookie doesn't match an active auth_sessions row, regardless of what
   this page happens to be showing. The whole app is behind this: nothing
   below boot() runs until an authenticated session is confirmed. */
async function checkAuth(){
  try{
    const r=await fetch(base()+"/auth/whoami",{credentials:"same-origin"});
    return r.ok;
  }catch{
    return false;
  }
}
function showLogin(){
  if(el.loginView) el.loginView.hidden=false;
  if(el.app) el.app.hidden=true;
}
function showApp(){
  if(el.loginView) el.loginView.hidden=true;
  if(el.app) el.app.hidden=false;
  appearance(S.avatar,S.theme,false);
  mode("idle");
  goHome();
  loadAgents();
}
if(el.loginForm) el.loginForm.addEventListener("submit", async e=>{
  e.preventDefault();
  if(el.loginError){ el.loginError.hidden=true; el.loginError.textContent=""; }
  const username=el.loginUsername?el.loginUsername.value.trim():"";
  const password=el.loginPassword?el.loginPassword.value:"";
  try{
    const r=await fetch(base()+"/auth/login",{
      method:"POST", credentials:"same-origin",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})
    });
    if(!r.ok){
      const d=await r.json().catch(()=>({}));
      if(el.loginError){ el.loginError.textContent=d.detail||"Login failed."; el.loginError.hidden=false; }
      return;
    }
    if(el.loginPassword) el.loginPassword.value="";
    showApp();
  }catch{
    if(el.loginError){ el.loginError.textContent="Could not reach the server."; el.loginError.hidden=false; }
  }
});

/* ---------- boot: gate first, everything else waits on it ---------- */
(async function boot(){
  const authed = await checkAuth();
  if(authed) showApp(); else showLogin();
})();
