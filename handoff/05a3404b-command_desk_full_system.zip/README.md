# Command Desk — Full System Snapshot

This is a complete snapshot of Command Desk exactly as it stands live, taken 2026-08-02.
It documents everything built through Stage 4.

Live at: `https://airexploit.com/commanddesk/`
Server: `ubuntu@15.135.122.156` (AWS EC2, ap-southeast-2), hostname `ip-172-31-24-73`

---

## 1. Architecture

```
Browser
  │
  ▼
nginx (airexploit.com, TLS via Certbot)
  │
  ├── /commanddesk/auth/   ──▶ core :8765  /api/auth/     (proxied straight to core)
  ├── /commanddesk/oauth/  ──▶ core :8765  /api/oauth/     (Google OAuth callback)
  ├── /commanddesk/nova/   ──▶ core :8765  /api/nova/      (the authenticated chat path)
  └── /commanddesk/        ──▶ adapter :8000               (everything else — static
                                                             agents list, health)
                                    │
                                    ▼
                              core :8765 (FastAPI "Hub")
                                    │
                              orchestrator.handle_turn()
                                    │
                        ┌───────────┴───────────┐
                        ▼                       ▼
                  Claude (Sonnet/Haiku)     Ollama (llama3.2, local)
```

Three nginx locations (`/commanddesk/auth/`, `/commanddesk/oauth/`, `/commanddesk/nova/`) are
more specific prefixes than the catch-all `/commanddesk/`, so nginx matches them first
regardless of file order. These three proxy **directly to core on :8765**, bypassing the
adapter entirely — the adapter has no cookie-forwarding logic of its own, and the session
cookie has to survive the round trip untouched. Everything else (`/commanddesk/agents`,
`/commanddesk/health`) goes through the **adapter** on :8000, a small separate FastAPI app
(`backend/adapter/main.py`) that reads `slots_config.json` directly off disk for `/agents`
and proxies `/chat` to core's legacy `/api/chat` route (not used by the current frontend,
which talks to `/nova/turn` instead — see §2).

Two processes, both under pm2:
- **commanddesk-backend** — core, `core/main.py`, port 8765 (bound to `COMMAND_DESK_PORT`,
  default 8765, host defaults to `127.0.0.1`)
- **commanddesk-adapter** — `adapter/main.py`, port 8000

A third pm2 process, **aire-admin**, is a separate, older system on the same box (predates
Command Desk) and is unrelated to this stack.

nginx also serves `/commanddesk-preview/` as a second, independent static root
(`/var/www/commanddesk_preview/`) — a staging copy used to verify a build before it's
promoted to `/commanddesk/`. Both paths share the same origin, so the session cookie and
`localStorage` are shared between preview and live.

## 2. The login / identity gate

Login **is** session creation — there is no separate "session" concept layered on top.

- `POST /commanddesk/auth/login {username, password}` (`core/auth.py`, `core/main.py`)
- Password is **bcrypt-hashed** in `auth_users`, checked with `bcrypt.checkpw` — never
  compared in plaintext.
- A successful login opens/resumes a real `sessions` row (`slot='nova_voice'`) via
  `continuity.open_session` and marks that same `session_id` as authenticated in a
  separate `auth_sessions` table.
- The cookie: `session_id`, `httponly=True`, `secure=True`, `samesite='lax'`, `path='/'`.
  `lax` (not `strict`) is deliberate — Google's OAuth redirect back to the callback is a
  cross-site top-level GET navigation, and a `Strict` cookie is withheld on exactly that
  kind of request, which would silently break the whole consent flow. `Lax` still blocks
  the cookie on cross-site POST/state-changing requests, so CSRF protection holds.
- **Every gated route depends on `require_auth`**, which re-checks the incoming cookie
  against `auth_sessions` server-side — not anything the frontend claims about its own
  state. This includes the permission layer itself (§6), which independently re-validates
  the session regardless of what gate the calling route already applied.
- **Lockout**: 5+ failed attempts for a username within a 15-minute rolling window blocks
  further attempts (429) until the window clears (`is_locked_out`, `login_attempts` table).
- The seed default account is created once, idempotently, on first boot
  (`seed_default_user` — safe to call on every startup, only inserts if missing so it
  never resets a since-rotated password).

  > **Heads-up for Sam**: `core/auth.py` contains the original seed default credential in
  > cleartext as source constants (`DEFAULT_USERNAME`/`DEFAULT_PASSWORD`), used only to
  > compute the initial bcrypt hash on first boot. If the password hasn't been changed
  > since, it's worth rotating — this file is now sitting in a zip.

## 3. Agents / slots

Slots are config-driven, not hardcoded — the single source of truth is
`backend/core/slots_config.json`. Adding or removing a slot is an edit to that file plus
a restart (or `POST /api/slots/reload` to pick it up live); no Python changes needed.
`orchestrator.py` loads it at import time and exposes `SLOTS` / `SLOT_CONFIG` / `DEFAULT_SLOT`.

The 7 slots actually wired into the live roster (`/commanddesk/agents`, filtered to exclude
`consolidator` from the router menu — see §4):

| id | name | brain | model | isolated? | notes |
|---|---|---|---|---|---|
| `hub` | Hub | Claude | **claude-sonnet-5** | no | default slot, continuity/general panel |
| `research` | Research | Claude | claude-haiku-4-5-20251001 | no | web research + citations |
| `builder` | Builder | Claude | claude-haiku-4-5-20251001 | **yes** (`build_test` group) | architecture/code/ship |
| `tester` | Tester | Claude | claude-haiku-4-5-20251001 | **yes** (`build_test` group) | writes/runs tests, reports bugs |
| `personal_assistant` | Personal Assistant | Claude | claude-haiku-4-5-20251001 | no | day plan, email (the mail worker) |
| `consolidator` | Consolidator | **Ollama** | llama3.2 | no | internal vault agent only — Sam never talks to it directly (§8) |
| `nova_voice` | Nova | **Ollama** | llama3.2 (default) | no | the voice/face; promotable to Sonnet on request (§5) |

Only **Hub** runs Sonnet by default; the other Claude slots run the cheap Haiku tier.
Consolidator and the resting state of Nova run **locally on Ollama** (free). Builder and
Tester are `isolated: true` in the same `isolated_group: "build_test"` — they only ever see
each other's transcript (`peer_transcript`), never the shared contextual memory pool, and
vice versa (`orchestrator.handle_turn`'s isolated/contextual split).

Two extra slot folders exist under `core/slots/` (`memory/`, `mind/`, `writing/`) but are
**not** present in `slots_config.json` — leftover/experimental, not part of the live roster.

Beyond the static 7, the backend also supports **spawned agent instances** from
user-created templates (`core/agents.py`, `/api/agents/templates`, `/api/agents/instances` —
unlimited, no hard cap) and ad-hoc **conversation groups** (`core/groups.py`,
`/api/groups`) for multi-agent round-robin discussions. Neither is exposed in the current
frontend build.

## 4. The router

A genuinely separate module (`core/router.py`) — not inside Nova, not inside any worker.
Takes one message, returns which worker should handle it and how confident (0-100) that
call is.

- Pinned to **Claude's cheap tier** (Haiku), not Ollama — llama3.2 was tried first and
  confidently misrouted a plain "what's come in" to Builder with a fabricated
  justification. A small real cost per routing call buys instruction-following reliable
  enough that "never guess" is actually true.
- Deliberately **model-judged, not a numeric cutoff**: the model is instructed to reply
  `"worker": null` when it's genuinely unclear between two or more specific workers,
  rather than picking whichever score is highest against a threshold.
- `nova_voice` is one of the router's own menu choices, representing plain conversation
  that isn't a request for any other worker — so ordinary chat resolves cleanly and
  confidently; "ambiguous" is reserved for genuine either-this-or-that cases between two
  *other* real workers.
- `consolidator` is excluded from the menu entirely (Sam never talks to it directly).
- Each slot gets a purpose-written routing description (`_ROUTER_DESCRIPTIONS`), separate
  from that slot's own `prompt.txt` — reusing the prompt verbatim caused a real misroute
  ("what's come in" → hub, because hub's own opening line reads as a semantic match too).
- When the router genuinely can't tell, the reply becomes:
  *"I'm not sure which of your agents should take that one — who do you want on it?"*
  — surfaced to Sam rather than guessed.
- Every routing decision (clean route, ambiguous refusal, or parse failure) is written to
  `audit_log`.
- Directly inspectable on its own via `POST /api/router/route`, independent of a full turn.

## 5. Sonnet wake (on Nova/voice)

`brain_mode` is a second, independent axis on the `voice_state` row — `'ollama'` (default,
free, everyday) or `'claude'` — flipped **only** by two regexes in `voice_state.py`, and
**only** ever checked for `slot == 'nova_voice'` in `orchestrator.handle_turn`:

- **Wake**: "go deep(er) on/into this", "switch to sonnet", "wake up sonnet",
  "think harder/deeper on/about this", "use claude (for this)"
- **Sleep**: "back to normal/ollama", "that's enough", "switch back", "go back to ollama",
  "sonnet off", "stand down sonnet"

Checked in `core/main.py`'s `nova_turn` route **before** the router even runs — a wake/sleep
phrase is a control word directed at Nova itself, never a task to delegate (otherwise
"go deep on this: <a real research question>" would get happily routed to Research just
because the question half looks like a research request). Once woken, `claude-sonnet-5`
persists across turns like a real switch, until the sleep phrase — not a one-turn boost.

## 6. Permission layer + Gmail tools

The tool lives in exactly one place, `core/permission_layer.py` — no other path in the
codebase touches the Gmail API. Workers (`personal_assistant`) can only *request*; this
module holds the tool and the gate, and independently re-validates the session on every
call regardless of what gate the calling route already applied.

**Read** (live, Stage 3):
- Trigger: a broad noun-based regex (`inbox|gmail|junk|spam|come in|e-?mail\w*`) —
  deliberately generous. Narrowed-down phrase lists missed real phrasing twice during live
  testing ("is there a rob in my junk mail", "anything new come in"); an occasional
  unnecessary read is the accepted trade-off since reads are cheap/safe/idempotent, and the
  alternative (Sam thinks the tool is broken) is worse.
- `messages().list` + a **metadata-only** `get()` per message (From/Subject/Date + snippet)
  — never the full message body.
- 30s timeout enforced via a background thread pool; a late result that arrives after
  timeout is discarded, never applied.

**Draft** (built, Stage 4):
- Narrower trigger, specifically about *composing* something new ("draft an email",
  "write a reply to", "compose an email", "reply to that email") — checked, and takes
  precedence over the read trigger, so "draft an email to X" can't spuriously also fire a
  read (both share the word "email").
- `compose_draft_content` calls the brain (Sonnet, pinned) to turn Sam's instruction into a
  real to/subject/body, consuming the style profile (§9) — it never infers style itself.
- Creates a **real Gmail draft** via `drafts().create()`. Requires the `gmail.compose`
  scope — a stage-3-only token (readonly) will fail here with an auth-scope error until Sam
  completes the broader consent grant; that's the named hard gate, not a bug.
- Lands in `awaiting_confirmation` — nothing sends without Sam's explicit reply.

**Send** (built, behind the locked yes-gate, Stage 4):
- The gate is a **short, explicit exact-match list only**: `yes, yep, yeah, send it,
  send that, confirm, confirmed, go ahead, do it`. No fuzzy/partial matching — "yes but
  wait", "yeah maybe", "send it later" do **not** match, by design: a near-miss re-asks,
  never sends.
- The confirmation is bound server-side to the session's own `pending_draft_id`
  (`voice_state`) — there is no code path anywhere that lets a caller name an arbitrary
  `draft_id` to confirm.
- Sends an **existing** Gmail draft by id (`drafts().send()`) — never composes fresh
  content at send time. What gets sent is exactly what was shown to Sam for confirmation.
- **Exactly-once guard**: before sending, checks for any existing `in_flight` or `executed`
  action against the same `draft_id`, in the same DB connection, immediately before writing
  the new in_flight row — no window for a duplicate concurrent send.
- On a timeout (30s), the action is left **`in_flight`** — deliberately not marked failed,
  never auto-resent. The only way to clear it is Sam's own explicit recovery phrase
  ("it didn't send" / "that didn't go through/arrive" / "confirming it failed/didn't
  send") — never a timeout, never an automatic retry.
- A clean, *definite* Gmail-side rejection (not a timeout) is marked `failed` instead,
  since that case is actually known not to have sent — a fresh attempt is allowed.
- `"change it"` mid-confirmation supersedes the old draft and redrafts via the brain,
  re-entering the same confirm flow with a new `draft_id`.
- The `awaiting_confirmation` state expires **lazily**, on the next real interaction, after
  120s — there is no background scheduler anywhere in this codebase (confirmed: no
  APScheduler/Celery/crontab/systemd timer). The safety property (send gate stays closed
  except in exactly this state, bound to exactly this draft) holds regardless of when the
  check actually runs.

OAuth (`core/google_oauth.py`, Stage 2): registered redirect URI is exactly
`https://airexploit.com/commanddesk/oauth/callback`. The callback does **not** require the
session cookie (an in-app webview redirect can land without it — this broke Sam's first
real attempt); the actual security property is the single-use, ~178-bit `state` value,
minted only because an authenticated session called `/api/oauth/start`, and bound to that
session in an `oauth_states` table read back on completion. Current scopes:
`gmail.readonly`, `gmail.compose`, `gmail.send` (requested together so read keeps working
across the re-consent that added compose/send).

## 7. State machine, timeouts, audit log

`core/voice_state.py` holds one row per session: `idle → listening → processing →
(reading|drafting|sending) → ... → idle`, each transition additionally written to
`audit_log` (timestamp, slot, tool, input summary, outcome, details) — so history is
inspectable independent of current state. Key states: `awaiting_confirmation` (send gate
open, bound to one `draft_id`), `in_flight` (a send whose result is unconfirmed).

Timeouts, all in `permission_layer.py`: read/draft/send = 30s each (`ThreadPoolExecutor`,
enforced from the caller side via `future.result(timeout=...)`); send-confirmation window
= 120s (lazy-checked, see §6).

`core/audit_log.py` is a flat, append-only table (`ts, slot, tool, input_summary, outcome,
details`) — every router decision, every permission-layer call, every state transition
writes here.

**Oversight** (`core/oversight/`) runs after a session, in the background
(`run_oversight_pipeline`, scheduled via FastAPI `BackgroundTasks` so it never adds chat
latency):
- **Clerk** (`clerk.py`) records the raw session facts.
- **Checker** (`checker.py`) compares Hub's stated intent (written inline via an
  `INTENT: ...` line, extracted and stored right after the turn) against what actually
  happened.
- **Angel** (`angel.py`) is a **read-only judge** — no action tools, no path to the Hub or
  any agent, its only write lands in a `review_queue` that only Sam's UI reads. It stays
  silent unless the Checker's status is one of: `intent_fabricated`, `mismatch`,
  `no_intent_recorded`, `intent_too_vague`, `unverified` — the last three deliberately
  treated as seriously as an outright mismatch, since "the system couldn't tell whether it
  did something wrong" is exactly the kind of hole worth Sam's attention. A clean "checked"
  produces no case, no noise.

## 8. Two-tier memory (`core/vault.py`)

- **Worker rolling window** (`worker_daily`): each slot's own last `MEMORY_WINDOW_DAYS`
  (env-tunable, default 4, Sam's locked 3-5 day spec) daily summaries — the *only* context
  a worker carries by default. Summaries are generated lazily, opportunistically, the first
  time a slot is used after its previous day went unsummarised (as a `BackgroundTask`, no
  scheduler exists) — cheap Claude tier (Haiku).
- **Vault** (`vault_entries`): the permanent long-term store. The moment a slot's rolling
  window overflows past its day limit, the oldest entries age out into the vault
  (`_age_overflow`) — insert-only, nothing is ever deleted or overwritten once archived.
- The vault agent is **consolidator**, pinned to Ollama/llama3.2 regardless of the global
  provider (free, per Sam's cost requirement) — and it never reasons or free-browses:
  `vault_search` is a plain deterministic keyword scan (same shape as the general
  `memory.recall()`) that narrows candidates; the model's only job is to confirm/report on
  what was actually found, or say a clean "No."
- Trigger-based, not polling: fires on phrasing like "have we/has anyone/did we already/
  has this come up/seen this before/any history on/before I reply-send-call-act" — and only
  once per subject per session (its own `vault_queries` table, since `update_state()`
  overwrites the shared session-state blob every turn).

## 9. Style profile (`core/style_profile.py`)

Reads Sam's own past **sent** mail — **once**, on first connect or on demand, never on a
schedule — and writes a persistent per-context communication profile (`mates` vs `work`,
bucketed by recipient domain) that the drafting step (§6) *consumes*; this module never
drafts and the drafting step never infers style itself.

- Fetches up to 50 recent sent messages, filters noise (out-of-office/auto-reply/forwards,
  anything under ~15 chars of real content after stripping a signature).
- Analysis runs on the **brain** (Sonnet, pinned) — Sam's explicit requirement, since this
  shapes every drafted email going forward.
- If there's no usable history at all, writes flagged placeholder defaults (`is_temporary:
  true`) so the drafting step and Sam both know it's not learned yet.
- Only needs the `gmail.readonly` scope already granted in Stage 2 — provable independent
  of the draft/send scopes.

## 10. Frontend

Static build served from `/var/www/commanddesk/` (live) / `/var/www/commanddesk_preview/`
(staging) — `index.html`, `app.js`, `styles.css`, `config.js`, `sw.js` (PWA service
worker), `manifest.webmanifest`, `404.html`, `assets/avatars/{nova,halo,gaia}.png`.

- **Whole page behind the login gate** — nothing renders until `/commanddesk/auth/whoami`
  confirms an authenticated session.
- **Rooms**: one per agent (Research/Builder/Tester/Personal Assistant + any added tile),
  each with its own chat transcript, talking to `/commanddesk/nova/turn` — the one
  authenticated path (cookie-derived session only; no client-supplied `session_id` is
  accepted). This is what makes email read/draft/send, the router, and Sonnet wake all
  actually reachable from the UI.
- **App launcher**: iframe-first. A "+ App" picker adds a room-scoped app tile (Gmail,
  iCloud, Outlook, Drive, Docs); opening one attempts a real `<iframe>` embed first, with a
  4-second honest fallback ("this app can't be shown here — some sites block being opened
  inside another page") offering a genuine "open in a new tab" escape hatch — never a bare
  `window.open` masquerading as integration.
- Real `/commanddesk/agents` (adapter-served, straight off `slots_config.json`) drives the
  visible roster — no hardcoded agent list, no demo mode.
- **Motion stripped, static only** — per Sam's explicit instruction. No background motion,
  no video, no breathing/blinking avatar animation, no spinning indicators. Nova renders as
  a still image; state changes are textual/label only ("READY" / "SPEAKING" / etc.).
  Verified via a `getComputedStyle().animationName` sweep returning zero animated elements,
  both at rest and during an active state.
- `localStorage` keys are versioned (`cd.schemaVersion` + `ensureSchema()`), wiping and
  rewriting on a version bump rather than accumulating stale shape across iterations.

## 11. Known gaps / not wired

- **A second model (GPT)** is not integrated anywhere in this codebase — `llm_router.py`
  only has Claude and Ollama paths.
- **Builder/Tester cheap-tier split**: both currently run the same Haiku tier
  (`claude-haiku-4-5-20251001`) — no cheaper/more-expensive split between them exists yet.
- **A Gemini photo pipeline** is not present — no Gemini/Google-AI-Studio integration
  anywhere in `core/` or `adapter/`.
- **Spawned agent instances and conversation groups** (`core/agents.py`, `core/groups.py`)
  are fully implemented backend-side (`/api/agents/*`, `/api/groups/*`) but **not exposed**
  in the current frontend build.
- `/api/groups` and most of the legacy `/api/*` routes (chat, capture, decision, nudge,
  tools) are **not** behind `require_auth` — only the Stage-1-and-later identity-gated
  routes (`/api/auth/*`, `/api/nova/*`, `/api/oauth/*`, `/api/style_profile/*`) are. They're
  reached only via the adapter/legacy path in practice, not by the current frontend, but
  they are live and ungated on the box.
- Legacy avatar frame images (`nova_blink.png`, `nova_mouth_1-4.png`) are still present
  under `/var/www/commanddesk/assets/avatars/` from an earlier animated build; unreferenced
  by the current static-only frontend, harmless, just not cleaned up.

## 12. How to run it

Everything runs under **pm2** on the box:

| pm2 name | what | port |
|---|---|---|
| `commanddesk-backend` | core (`core/main.py`, FastAPI/uvicorn) | 8765 |
| `commanddesk-adapter` | adapter (`adapter/main.py`, FastAPI/uvicorn) | 8000 |
| `aire-admin` | unrelated, older system on the same box | — |

```
pm2 list                       # check status/PIDs
pm2 restart commanddesk-backend
pm2 restart commanddesk-adapter
pm2 logs commanddesk-backend
```

Backend lives at `/home/ubuntu/commanddesk/` on the box, run inside its own venv
(`/home/ubuntu/commanddesk/venv/`, Python 3.14). Dependencies: `backend/requirements.txt`
(fastapi, uvicorn[standard], anthropic, pydantic, requests, bcrypt,
google-auth-oauthlib, google-api-python-client) and `backend/adapter/requirements.txt`.

**Config/secrets** (none of these are in this bundle — see below):
- `/home/ubuntu/commanddesk/.env` — loaded by `core/dotenv_loader.py` (a minimal loader,
  no `python-dotenv` dependency; `KEY=VALUE` lines, `os.environ.setdefault` so a real env
  var set outside the file always wins). This is where the Anthropic API key and any other
  provider config live.
- `/home/ubuntu/commanddesk/google_client_secret.json` — Google OAuth app credentials.
- `/home/ubuntu/commanddesk/google_token.json` — the live user's Gmail OAuth token
  (created/refreshed by `core/google_oauth.py`), root permissions `0600`.
- `/home/ubuntu/commanddesk/data/aire.db` — the live SQLite database (sessions,
  transcript, memory, vault, drafts, actions, audit_log, auth, oversight tables, etc.).

Frontend is plain static files — no build step. Deploy by copying the 8 files + 3 avatar
PNGs into `/var/www/commanddesk/` (or `_preview/` to stage first); nginx serves them
directly, no restart needed for a frontend-only change.

nginx: `/etc/nginx/sites-available/aire` (symlinked from `sites-enabled/`), reload with
`sudo systemctl reload nginx` after any edit. TLS via Certbot
(`/etc/letsencrypt/live/airexploit.com/`).

---

## What's excluded from this bundle, and why

Per instruction, this snapshot strictly excludes anything that would let someone else
impersonate Sam's account or spend his API budget:

- `.env` (Anthropic API key + other provider config)
- `google_client_secret.json`, `google_token.json` (Google OAuth app + live user token)
- `venv/` (reproducible from `requirements.txt`)
- `data/` / `*.db` (the live database — contains real inbox/session content, not code)
- `__pycache__/`, `*.pyc`
- Every historical `commanddesk*_backup*` / `*_pre_*` directory on the box, and every
  nginx `.bak*` file — only the currently active config is included
- The `aire-deploy-key.pem` / `aire-key (1).pem` SSH keys used to reach this box

The finished bundle was grepped for `sk-ant`, `GOCSPX`, `BEGIN...PRIVATE KEY`, and other
key-shaped strings before being handed over — see the delivery message for the result.
